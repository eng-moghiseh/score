# Scorent 🦂

پلتفرم دوزبانه (فارسی/انگلیسی) فروش و اجاره‌ی بازی با پنل مدیریت کامل (CMS اختصاصی)، دستیار گفتگوی هوشمند، سیستم XP و کاربران، پشتیبانی تیکتی و فروشگاه با فیلترهای پویا.

---

## استک فنی

| لایه | فناوری |
| --- | --- |
| فریم‌ورک | Next.js 16 (App Router) + React 19 + TypeScript 5 |
| استایل | Tailwind CSS 4 + shadcn/ui + فونت متغیر Vazirmatn |
| دیتابیس | Prisma 6 — SQLite (پیش‌فرض، همراه سورس) یا PostgreSQL (سرورلس) |
| اعتبارسنجی | Zod 4 |
| آزمون | Vitest 5 — ۱۵۵ تست در ۱۲ فایل |
| کیفیت | ESLint 9 + tsc |

## ساختار پروژه

```
src/
  app/            مسیرهای App Router — صفحات عمومی، auth، admin، api
  components/     کامپوننت‌های UI (عمومی / admin / shop / chat / pages)
  lib/
    server/       منطق سمت سرور: نشست، رمزنگاری (scrypt)، rate-limit، کاتالوگ، seed
    cms/          موتور CMS: بلوک‌ها، درخت رده‌ها، فیلترها، ناوبری، تنظیمات
    i18n/         دوزبانگی fa/en
    data/         دیتاست seed بازی‌ها
  middleware…    هدرهای امنیتی + CSP در next.config.ts
prisma/           schema.prisma (SQLite) + schema.postgres.prisma + migrations نسخه‌بندی‌شده (0_init + 1_cms_catalog_tables)
db/               فقط محلی — در بسته‌ی انتشار نیست (production: DATABASE_URL از env)
tests/            تست‌های Vitest (قیمت‌گذاری، اجاره، XP، امنیت، مجوزها، CMS، …)
scripts/          ابزارهای عملیاتی: rotate-admin.mjs، check-env.mjs، e2e-ها
DEPLOY.md         راهنمای کامل استقرار (Netlify+PG و VPS+SQLite)
.env.example      قالب متغیرهای محیطی با توضیح فارسی
```

## شروع سریع

```bash
npm install            # یا bun install
npx prisma generate
npm run dev            # توسعه روی http://localhost:3000

npm run build          # بیلد production (خروجی standalone + کپی static/public)
NODE_ENV=production PORT=3000 node .next/standalone/server.js
```

دیتابیس SQLite همراه سورس (`db/custom.db`) آماده است — نیازی به seed اولیه نیست؛ روی دیتابیس خالی `npx prisma db push` را اجرا کن.

## تست و کیفیت

```bash
npm run lint           # ESLint — صفر خطا
npx tsc --noEmit       # تایپ‌ها — صفر خطا
npm test               # ۱۵۵/۱۵۵ پاس
```

## متغیرهای محیطی

تمام متغیرها با توضیح در `.env.example` هستند. خلاصه:

| متغیر | ضروری | شرح |
| --- | --- | --- |
| `DATABASE_URL` | ✔ | `postgresql://…` (Netlify/serverless) یا `file:…` (سرور واحد) |
| `AUTH_SECRET` | ✔ سرورلس | کلید امضای نشست‌ها — تصادفی و ≥۳۲ کاراکتر |
| `SITE_URL` | ✔ | دامنه‌ی عمومی نهایی — برای CSRF، کوکی‌ها، canonical و sitemap |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | استقرار تازه | ساخت اولین مدیر ارشد روی دیتابیس خالی (فقط تا اولین ورود؛ سپس حذف کن) |
| `GOOGLE_CLIENT_ID/SECRET` | — | ورود با گوگل |
| `SMTP_*` / `SMS_*` | — | ارسال کد ورود/بازیابی (در نبودشان کد در لاگ سرور می‌افتد) |
| `GOOGLE_SITE_VERIFICATION` | — | تأیید مالکیت Google Search Console |
| `NEXT_PUBLIC_GA4_ID` | — | Google Analytics 4 (G-…) |
| `FRAME_GUARD=false` | — | فقط برای پیش‌نمایش داخل iframe |

## حساب ادمین

- **استقرار تازه (دیتابیس خالی):** `ADMIN_EMAIL` + `ADMIN_PASSWORD` را در env ست کن — در اولین اجرا (اولین بازدید سایت) مدیر ارشد به‌صورت خودکار ساخته می‌شود؛ رمز هرگز در لاگ نمی‌آید و رمزهای عمومی/پیش‌فرض رد می‌شوند. بعد از اولین ورود، این دو متغیر را از env حذف کن.
- **روی دیتابیس موجود:** رمز را از پنل (پروفایل → کارت حساب) یا با اسکریپت عوض کن:

> ⚠️ **بعد از استقرار بلافاصله رمز را عوض کن** — از پنل (پروفایل → کارت حساب) یا از ترمینال:
> ```bash
> ROTATE_ADMIN_EMAIL="admin@scorent.space" ROTATE_ADMIN_PASSWORD="رمز_جدید_حداقل_۱۲_کاراکتر" node scripts/rotate-admin.mjs
> ```
> این اسکریپت همه‌ی نشست‌های فعال آن حساب را ابطال و عمل را در لاگ حسابرسی ثبت می‌کند.

## امنیت

- هدرهای امنیتی + CSP با `frame-ancestors` در `next.config.ts` (production)
- کوکی نشست: `httpOnly` + `Secure` + `SameSite=None; Partitioned` (CHIPS) در بستر HTTPS
- rate-limit دولایه روی ورود (IP و شناسه) و مسیرهای حساس auth
- CSRF: بررسی same-origin با پشتیبانی `x-forwarded-host`/`Referer` پشت proxy
- رمزها با scrypt (N=16384) ذخیره می‌شوند — `src/lib/server/password.ts`
- چک‌لیست کامل پیش از انتشار عمومی: بخش «چک‌لیست امنیت» در `DEPLOY.md`

## استقرار

راهنمای گام‌به‌گام در [DEPLOY.md](./DEPLOY.md) + گزارش کامل تغییرات فنی در [PRODUCTION-REPORT.md](./PRODUCTION-REPORT.md):

- **گزینه‌ی الف** — Netlify + PostgreSQL: ریپو را به GitHub push کن → Netlify → Import → envها را ست کن → Deploy. `build:netlify` خودش `check-env` + `prisma migrate deploy` + `generate` + `next build` را اجرا می‌کند؛ seed و bootstrap ادمین روی اولین بازدید خودکار است.
- **گزینه‌ی ب** — سرور سنتی (VPS) + SQLite یا PostgreSQL با pm2 و reverse-proxy.
- **دیتابیس PG موجود که قبلاً با `db push` ساخته شده:** یک‌بار `prisma migrate resolve --applied 0_init` و `prisma migrate resolve --applied 1_cms_catalog_tables` اجرا کن.

### اتصال Google Search Console و Analytics

1. Search Console → Add property → دامنه یا URL پیشوندی.
2. روش «تگ HTML» را انتخاب کن؛ محتوای `content` تگ را در env با نام `GOOGLE_SITE_VERIFICATION` بگذار و redeploy کن → Verify.
3. بخش Sitemaps → آدرس `https://دامنه‌ات/sitemap.xml` را ثبت کن (این URL به‌صورت پویا با بازی‌ها و صفحات CMS ساخته می‌شود).
4. Analytics: `NEXT_PUBLIC_GA4_ID` را با شناسه‌ی `G-…` در env ست کن — اسکریپت فقط وقتی این متغیر موجود باشد بارگذاری می‌شود.
5. بعد از انتشار، «URL inspection» را روی چند صفحه‌ی اصلی بزن و درخواست ایندکس بده — هیچ تضمین رتبه‌ای وجود ندارد، اما زیرساخت فنی استاندارد است.

## مرکز کنترل (پنل ادمین) — `/#/admin`

مدیریت کامل با ذخیره‌ی واقعی در دیتابیس و لاگ حسابرسی: بازی‌ها (CRUD + زباله‌دان + عملیات گروهی)، رده‌های دوزبانه، فیلترهای پویا، ناوبری، صفحه‌ساز drag-drop با نسخه‌بندی، رسانه، تنظیمات (نگه‌داری، تماس، سئو، فروشگاه/اجاره)، اعلان‌ها، تیکت‌های پشتیبانی، کاربران و حساب‌های کارمندی، لاگ حسابرسی.
