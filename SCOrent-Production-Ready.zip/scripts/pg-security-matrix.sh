#!/usr/bin/env bash
# ————— ماتریس تست امنیتی روی PostgreSQL در حالت production (شبیه‌سازی Netlify) —————
set -u
B="http://localhost:3112"
H="Origin: http://localhost:3112"
J() { python3 -c "import sys,json;d=json.load(sys.stdin);print(json.dumps(d,ensure_ascii=False)[:200])" 2>/dev/null || echo "(empty/invalid)"; }
P() { echo "== $1"; }

cd /home/z/my-project

# ۱) اجرای سرور standalone با PG + production env
setsid env NODE_ENV=production PORT=3112 \
  DATABASE_URL="postgresql://scorent@localhost:5432/scorent?host=/tmp" \
  AUTH_SECRET="test-secret-0123456789abcdef0123456789abcdef" \
  ADMIN_EMAIL="test-admin@scorent.ir" \
  ADMIN_PASSWORD="Str0ng!TestPass2026" \
  DEMO_MODE="true" \
  node .next/standalone/server.js > /tmp/pg-prod.log 2>&1 &
SRV=$!
sleep 6

P "HOME"; curl -s -o /dev/null -w "%{http_code}\n" $B/

P "REG1 (demo mode → demoCode expected)"
curl -s -c /tmp/c1.txt -X POST $B/api/auth/register -H "Content-Type: application/json" -H "$H" \
  -d '{"name":"کاربر اول","identifier":"sec-a@scorent.ir","password":"Str0ng!Pass2026"}' > /tmp/r1.json
J < /tmp/r1.json
CODE1=$(python3 -c "import json;print(json.load(open('/tmp/r1.json')).get('verify',{}).get('demoCode',''))")
echo "extracted code: $CODE1"

P "REG2 (second user, fresh session)"
curl -s -c /tmp/c2.txt -X POST $B/api/auth/register -H "Content-Type: application/json" -H "$H" \
  -d '{"name":"کاربر دوم","identifier":"sec-b@scorent.ir","password":"Str0ng!Pass2026"}' > /tmp/r2.json
CODE2=$(python3 -c "import json;print(json.load(open('/tmp/r2.json')).get('verify',{}).get('demoCode',''))")
echo "extracted code: $CODE2"

P "VERIFY2 wrong x5 → attempts ramp"
for i in 1 2 3 4 5; do
  curl -s -b /tmp/c2.txt -X POST $B/api/auth/verify -H "Content-Type: application/json" -H "$H" \
    -d '{"kind":"EMAIL_VERIFY","code":"000000"}' | J
done
P "VERIFY2 6th attempt → TOO_MANY_ATTEMPTS expected"
curl -s -b /tmp/c2.txt -X POST $B/api/auth/verify -H "Content-Type: application/json" -H "$H" \
  -d '{"kind":"EMAIL_VERIFY","code":"000000"}' | J

P "VERIFY2 correct code AFTER lockout → still locked (تک‌کد قفل شده)"
curl -s -b /tmp/c2.txt -X POST $B/api/auth/verify -H "Content-Type: application/json" -H "$H" \
  -d "{\"kind\":\"EMAIL_VERIFY\",\"code\":\"$CODE2\"}" | J

P "VERIFY1 correct code → ok:true + emailVerified"
curl -s -b /tmp/c1.txt -X POST $B/api/auth/verify -H "Content-Type: application/json" -H "$H" \
  -d "{\"kind\":\"EMAIL_VERIFY\",\"code\":\"$CODE1\"}" | J

P "REUSE verify1 code again → single-use"
curl -s -b /tmp/c1.txt -X POST $B/api/auth/verify -H "Content-Type: application/json" -H "$H" \
  -d "{\"kind\":\"EMAIL_VERIFY\",\"code\":\"$CODE1\"}" | J

P "ADMIN stats as regular user → 403"
curl -s -b /tmp/c1.txt $B/api/admin/stats -o /dev/null -w "%{http_code}\n"

P "ADMIN stats unauthenticated → 401"
curl -s $B/api/admin/stats -o /dev/null -w "%{http_code}\n"

P "ADMIN login + stats → 200"
curl -s -c /tmp/ca.txt -X POST $B/api/auth/login -H "Content-Type: application/json" -H "$H" \
  -d '{"identifier":"test-admin@scorent.ir","password":"Str0ng!TestPass2026"}' -o /dev/null -w "login=%{http_code}\n"
curl -s -b /tmp/ca.txt $B/api/admin/stats -o /dev/null -w "stats=%{http_code}\n"

P "AUDIT as admin → rows"
curl -s -b /tmp/ca.txt "$B/api/admin/audit?take=10" | python3 -c "
import sys,json
d=json.load(sys.stdin)
rows=d.get('audit',[])
print('audit rows:', len(rows))
for r in rows[:8]: print(' -', r['action'], '→', r.get('target') or '-', r.get('meta') or '')"

P "AUDIT as regular user → 403"
curl -s -b /tmp/c1.txt "$B/api/admin/audit" -o /dev/null -w "%{http_code}\n"

P "CROSS-SITE origin → 400 BAD_ORIGIN"
curl -s -X POST $B/api/auth/login -H "Content-Type: application/json" -H "Origin: https://evil.example" \
  -H "Sec-Fetch-Site: cross-site" -d '{"identifier":"x@y.z","password":"whatever1"}' | J

P "BIG payload (>256KB) → rejected"
python3 -c "print('{\"a\":\"'+('x'*300000)+'\"}')" > /tmp/big.json
curl -s -X POST $B/api/auth/login -H "Content-Type: application/json" -H "$H" --data-binary @/tmp/big.json -o /dev/null -w "%{http_code}\n"

P "LOGIN wrong password → 401 INVALID_CREDENTIALS"
curl -s -X POST $B/api/auth/login -H "Content-Type: application/json" -H "$H" \
  -d '{"identifier":"sec-a@scorent.ir","password":"WrongPass123"}' | J

P "PASSWORD CHANGE (user2) → ok, then old session of another tab revoked"
# کاربر دوم یک نشست دیگر (بدون کوکی فعلی) — فقط کوکی فعلی می‌ماند
curl -s -b /tmp/c2.txt -X POST $B/api/auth/password -H "Content-Type: application/json" -H "$H" \
  -d '{"current":"Str0ng!Pass2026","next":"NewStr0ng!Pass456"}' | J

P "FORGOT (user1) → demo code (DEMO_MODE=true)"
curl -s -X POST $B/api/auth/forgot -H "Content-Type: application/json" -H "$H" \
  -d '{"identifier":"sec-a@scorent.ir"}' > /tmp/f.json
J < /tmp/f.json
FCODE=$(python3 -c "import json;print(json.load(open('/tmp/f.json')).get('demoCode',''))")

P "RESET with code → ok:true (همه نشست‌های user1 ابطال می‌شود)"
curl -s -X POST $B/api/auth/reset -H "Content-Type: application/json" -H "$H" \
  -d "{\"identifier\":\"sec-a@scorent.ir\",\"code\":\"$FCODE\",\"next\":\"BrandNew!Pass789\"}" | J

P "OLD session of user1 after reset → 401 (revoked)"
curl -s -b /tmp/c1.txt $B/api/auth/me | J

P "LOGIN with new password → ok"
curl -s -X POST $B/api/auth/login -H "Content-Type: application/json" -H "$H" \
  -d '{"identifier":"sec-a@scorent.ir","password":"BrandNew!Pass789"}' -o /dev/null -w "%{http_code}\n"

P "PROBE → configured:false"
curl -s "$B/api/auth/google?mode=probe"

echo
echo "== DONE — killing server =="
kill $SRV 2>/dev/null
pkill -f ".next/standalone/server.js" 2>/dev/null
echo "matrix finished"
