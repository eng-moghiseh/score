/* E2E API test for custom-games admin feature — runs against localhost:3113 */
const BASE = "http://127.0.0.1:3113";
let cookie = "";

async function call(method, path, body) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(cookie ? { Cookie: cookie } : {}),
      Origin: BASE,
      Referer: BASE + "/",
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const setCookie = res.headers.getSetCookie?.() ?? [];
  for (const c of setCookie) {
    if (c.startsWith("scorent_session") || c.includes("session")) {
      cookie = c.split(";")[0];
    }
  }
  let json = null;
  try { json = await res.json(); } catch {}
  return { status: res.status, json };
}

const results = [];
const check = (name, cond, extra) => {
  results.push({ name, pass: Boolean(cond), extra: extra ?? "" });
  console.log(`${cond ? "PASS" : "FAIL"} — ${name}${extra ? " · " + extra : ""}`);
};

(async () => {
  // 1. login as admin — اعتبارنامه‌ی تعبیه‌شده در سورس (admin-init.ts)
  if (!process.env.E2E_ADMIN_PASSWORD) { console.error("Set E2E_ADMIN_EMAIL/E2E_ADMIN_PASSWORD env to run this E2E script."); process.exit(1); }
const login = await call("POST", "/api/auth/login", { identifier: process.env.E2E_ADMIN_EMAIL ?? "admin@scorent.space", password: process.env.E2E_ADMIN_PASSWORD ?? "" });
  check("login admin", login.status === 200 && login.json?.ok, `status=${login.status} code=${login.json?.error ?? ""}`);

  const game = {
    id: "e2e-test-game",
    title: "E2E Test Game",
    developer: "QA Studio",
    year: 2025,
    tagline: "بازی آزمایشی اتوماسیون",
    description: "این بازی فقط برای آزمایش خودکار ایجاد شده و پس از آزمایش حذف می‌شود.",
    genres: ["اکشن"],
    playstyles: ["چالشی"],
    structure: "خطی",
    modes: ["تک‌نفره"],
    price: 3_000_000,
    originalPrice: 4_000_000,
    rentalAvailable: true,
    featured: true,
    highlights: ["آزمایش یک", "آزمایش دو"],
  };

  // 2. unauthenticated create must fail
  const saved = cookie;
  cookie = "";
  const anon = await call("POST", "/api/admin/games", { id: game.id, game });
  check("anonymous create rejected", anon.status === 401, `status=${anon.status}`);
  cookie = saved;

  // 3. create
  const create = await call("POST", "/api/admin/games", { id: game.id, game });
  check("create custom game", create.status === 200 && create.json?.ok, `status=${create.status} code=${JSON.stringify(create.json?.error ?? "")} ${JSON.stringify(create.json?.errors ?? [])}`);
  check("discount derived 25%", create.json?.game?.game?.discountPercent === 25, `pct=${create.json?.game?.game?.discountPercent}`);
  check("rental auto-filled", Number(create.json?.game?.game?.rental?.d1) === 375_000, `d1=${create.json?.game?.game?.rental?.d1}`);
  check("palette auto hex", /^#[0-9a-f]{6}$/i.test(create.json?.game?.game?.palette?.[0] ?? ""), `p0=${create.json?.game?.game?.palette?.[0]}`);

  // 4. duplicate id rejected
  const dup = await call("POST", "/api/admin/games", { id: game.id, game });
  check("duplicate id rejected 409", dup.status === 409, `status=${dup.status}`);

  // 5. dataset id rejected
  const ds = await call("POST", "/api/admin/games", { id: "elden-ring", game: { ...game, id: "elden-ring" } });
  check("dataset id collision rejected 409", ds.status === 409, `status=${ds.status}`);

  // 6. invalid payload rejected with error list
  const bad = await call("POST", "/api/admin/games", { id: "bad-game", game: { ...game, id: "bad-game", title: "", genres: [] } });
  check("invalid payload 400 + errors", bad.status === 400 && Array.isArray(bad.json?.errors) && bad.json.errors.length >= 2, `errors=${JSON.stringify(bad.json?.errors)}`);

  // 7. visible in public overrides endpoint
  const pub = await call("GET", "/api/overrides");
  const found = (pub.json?.customGames ?? []).find((g) => g.id === game.id);
  check("public /api/overrides includes new game", Boolean(found), `count=${pub.json?.customGames?.length}`);
  check("custom game passes shape", found?.title === "E2E Test Game" && Array.isArray(found?.genres), "");

  // 8. admin list
  const list = await call("GET", "/api/admin/games");
  check("admin GET games lists it", (list.json?.games ?? []).some((g) => g.id === game.id), `count=${list.json?.games?.length} datasetSize=${list.json?.datasetSize}`);

  // 9. stats include catalog counts
  const stats = await call("GET", "/api/admin/stats");
  check("stats.gamesTotal includes custom", stats.json?.stats?.gamesTotal >= 28, `total=${stats.json?.stats?.gamesTotal} custom=${stats.json?.stats?.gamesCustom}`);
  check("stats.gamesCustom >= 1", stats.json?.stats?.gamesCustom >= 1, "");

  // 10. patch update — قیمت ۲M با قیمت اولیه ۴M → تخفیف ۵۰٪ استخراج می‌شود
  const patch = await call("PATCH", `/api/admin/games/${game.id}`, { game: { ...game, title: "E2E Renamed", price: 2_000_000, originalPrice: 4_000_000, featured: false } });
  check("patch renames + reprices", patch.json?.game?.game?.title === "E2E Renamed" && patch.json?.game?.game?.discountPercent === 50, `title=${patch.json?.game?.game?.title} pct=${patch.json?.game?.game?.discountPercent}`);

  // 11. rename attempt on PATCH keeps path id (id mismatch impossible)
  const patch2 = await call("PATCH", `/api/admin/games/${game.id}`, { game: { ...game, id: "hack-attempt" } });
  check("patch forces path id", patch2.json?.game?.game?.id === game.id, `id=${patch2.json?.game?.game?.id}`);

  // 12. non-staff forbidden — register a user then try
  const email = `e2e${Date.now()}@test.local`;
  const reg = await call("POST", "/api/auth/register", { name: "E2E User", identifier: email, password: "Xk9$mP2vLq8!", lang: "fa" });
  check("register plain user", reg.status === 200 || reg.status === 201, `status=${reg.status} code=${reg.json?.error ?? ""}`);
  // anonymous again: plain user session cookie replaced; try create
  const userTry = await call("POST", "/api/admin/games", { id: "nope-game", game });
  check("non-staff forbidden 403", userTry.status === 403, `status=${userTry.status}`);

  // 13. delete
  cookie = saved;
  const del = await call("DELETE", `/api/admin/games/${game.id}`);
  check("delete custom game", del.status === 200 && del.json?.ok, `status=${del.status}`);
  const pub2 = await call("GET", "/api/overrides");
  check("gone from public endpoint", !(pub2.json?.customGames ?? []).some((g) => g.id === game.id), `count=${pub2.json?.customGames?.length}`);
  const delAgain = await call("DELETE", `/api/admin/games/${game.id}`);
  check("deleting missing game 404", delAgain.status === 404, `status=${delAgain.status}`);

  // 14. audit log has GAME_CREATED / GAME_UPDATED / GAME_DELETED
  const audit = await call("GET", "/api/admin/audit?take=50");
  const actions = (audit.json?.audit ?? []).map((a) => a.action);
  check("audit GAME_CREATED", actions.includes("GAME_CREATED"), "");
  check("audit GAME_UPDATED", actions.includes("GAME_UPDATED"), "");
  check("audit GAME_DELETED", actions.includes("GAME_DELETED"), "");

  const failed = results.filter((r) => !r.pass);
  console.log(`\n==== ${results.length - failed.length}/${results.length} passed ====`);
  if (failed.length > 0) process.exit(1);
})().catch((e) => {
  console.error("E2E crashed:", e);
  process.exit(1);
});
