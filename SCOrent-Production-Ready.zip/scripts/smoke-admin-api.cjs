/* تست دود پنل ادمین: ورود + همه‌ی اندپوینت‌های جدید */
const { PrismaClient } = require("@prisma/client");
const { scrypt } = require("node:crypto");
const { promisify } = require("node:util");
const scryptAsync = promisify(scrypt);

/* همان الگوریتم src/lib/server/password.ts — $scrypt$N$r$p$salt$hash */
async function scryptVerify(password, stored) {
  const parts = String(stored).split("$");
  if (parts.length !== 6 || parts[1] !== "scrypt") return false;
  const [, , N, r, p, saltB64, hashB64] = parts;
  const expected = Buffer.from(hashB64, "base64");
  const derived = await scryptAsync(password, Buffer.from(saltB64, "base64"), expected.length, {
    N: Number(N), r: Number(r), p: Number(p), maxmem: 64 * 1024 * 1024,
  });
  return derived.length === expected.length && derived.equals(expected);
}

const db = new PrismaClient();
if (!PASS) { console.error("Set E2E_ADMIN_PASSWORD env to run this script."); process.exit(1); }
const EMAIL = "admin@scorent.space";
const PASS = process.env.E2E_ADMIN_PASSWORD ?? "";

(async () => {
  const u = await db.user.findUnique({ where: { email: EMAIL } });
  if (!u) throw new Error("admin not found");
  console.log("[1] scrypt local check:", scryptVerify(PASS, u.passwordHash), "| role:", u.role, "| status:", u.status);
  await db.$disconnect();

  const base = "http://localhost:3000";
  const login = await fetch(base + "/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json", Origin: base },
    body: JSON.stringify({ identifier: EMAIL, password: PASS }),
  });
  const cookie = login.headers.getSetCookie()[0]?.split(";")[0] ?? "";
  const loginBody = await login.json();
  console.log("[2] API login:", login.status, JSON.stringify(loginBody).slice(0, 120));

  const get = async (p) => {
    const r = await fetch(base + p, { headers: { cookie } });
    const ct = r.headers.get("content-type") ?? "";
    if (ct.includes("json")) {
      const j = await r.json();
      return { status: r.status, keys: Object.keys(j), size: JSON.stringify(j).length };
    }
    const txt = await r.text();
    return { status: r.status, ct, preview: txt.slice(0, 120), lines: txt.split("\n").length };
  };

  console.log("[3] stats:", JSON.stringify(await get("/api/admin/stats")));
  console.log("[4] audit:", JSON.stringify(await get("/api/admin/audit?take=25")));
  console.log("[5] users export CSV:", JSON.stringify(await get("/api/admin/users/export")));
  console.log("[6] tickets+prio:", JSON.stringify(await get("/api/admin/tickets?priority=HIGH&page=1")));
  const testEmail = await fetch(base + "/api/admin/providers/test-email", {
    method: "POST",
    headers: { cookie, Origin: base },
  });
  console.log("[7] test-email:", testEmail.status, JSON.stringify(await testEmail.json()));

  /* کاربر عادی بدون دسترسی → باید ۴۰۱/۴۰۳ بگیرد */
  const noAuth = await fetch(base + "/api/admin/users/export");
  console.log("[8] export without session:", noAuth.status, JSON.stringify(await noAuth.json()));
})().catch((e) => {
  console.error("SMOKE FAILED:", e.message);
  process.exit(1);
});
