#!/usr/bin/env node
/* Operator script: rotate a staff account's password + revoke all its sessions.
 * Usage: ROTATE_ADMIN_EMAIL=... ROTATE_ADMIN_PASSWORD=... node scripts/rotate-admin.mjs
 * Never embeds credentials; writes an audit-log row.
 */
import { scrypt, randomBytes, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { PrismaClient } from "@prisma/client";

const scryptAsync = promisify(scrypt);
const db = new PrismaClient();

const EMAIL = (process.env.ROTATE_ADMIN_EMAIL || "admin@scorent.space").trim().toLowerCase();
const PASSWORD = process.env.ROTATE_ADMIN_PASSWORD;

if (!PASSWORD || PASSWORD.length < 12) {
  console.error("ROTATE_ADMIN_PASSWORD must be set and >= 12 chars");
  process.exit(2);
}

async function hashPassword(pw) {
  const salt = randomBytes(16);
  const derived = await scryptAsync(pw.normalize("NFKC"), salt, 64, { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
  return `scrypt$16384$8$1$${salt.toString("hex")}$${derived.toString("hex")}`;
}

const user = await db.user.findUnique({ where: { email: EMAIL } });
if (!user) {
  console.error(`No user found with email ${EMAIL}`);
  process.exit(1);
}
if (user.role === "USER") {
  console.error(`Refusing: ${EMAIL} is a regular USER, not staff.`);
  process.exit(1);
}

const oldHash = user.passwordHash;
const newHash = await hashPassword(PASSWORD);
if (oldHash) {
  const parts = oldHash.split("$");
  const [, N, r, p, saltHex, keyHex] = parts;
  const derived = await scryptAsync(PASSWORD.normalize("NFKC"), Buffer.from(saltHex, "hex"), Buffer.from(keyHex, "hex").length, { N: +N, r: +r, p: +p, maxmem: 64 * 1024 * 1024 });
  if (derived.equals(Buffer.from(keyHex, "hex"))) {
    console.log("NOTE: provided password equals the current one — nothing changed.");
    process.exit(0);
  }
}

await db.$transaction([
  db.user.update({ where: { id: user.id }, data: { passwordHash: newHash } }),
  db.session.updateMany({ where: { userId: user.id, revokedAt: null }, data: { revokedAt: new Date() } }),
]);
await db.auditLog.create({
  data: {
    action: "PASSWORD_ROTATED",
    actorId: null,
    target: EMAIL,
    meta: "operator rotation via scripts/rotate-admin.mjs — all sessions revoked",
    ip: null,
  },
}).catch((e) => console.error("audit log write failed:", e.message));

console.log(`OK: password rotated for ${EMAIL} (${user.role}); ${await db.session.count({ where: { userId: user.id } })} session records total, all revoked.`);
await db.$disconnect();
