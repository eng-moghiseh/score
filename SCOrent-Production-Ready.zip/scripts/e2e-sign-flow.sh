#!/usr/bin/env bash
# تست E2E قطعی: سرور production + مرورگر واقعی — ثبت‌نام → مرحله تأیید → بعدها → خروج → ورود
set -u
cd /home/z/my-project

export PORT=3113
node .next/standalone/server.js > /tmp/e2e-server.log 2>&1 &
SPID=$!
for i in $(seq 1 30); do curl -sf -o /dev/null http://localhost:3113/ && break; sleep 0.5; done
echo "SERVER_UP=$(curl -s -o /dev/null -w '%{http_code}' http://localhost:3113/)"

AB() { agent-browser "$@" 2>&1; }
TS=$(date +%s)
EMAIL="e2e-$TS@scorent.dev"

# 1) صفحه auth → تب ثبت‌نام (با ref دقیق)
AB open "http://localhost:3113/#/auth" >/dev/null
AB wait --load networkidle >/dev/null
TABREF=$(AB snapshot -i -c | grep -oE 'tab "ثبتنام" \[ref=([a-z0-9]+)' | grep -oE '[a-z0-9]+$' | head -1)
AB click "@$TABREF" >/dev/null
sleep 1
SNAP=$(AB snapshot -i -c)
echo "--- register textboxes ---"
echo "$SNAP" | grep -E 'textbox "(نام نمایشی|ایمیل یا شماره موبایل|رمز عبور)"' | head -4
NAME_REF=$(echo "$SNAP" | grep -oE 'textbox "نام نمایشی" \[ref=([a-z0-9]+)' | grep -oE '[a-z0-9]+$' | head -1)
ID_REF=$(echo "$SNAP" | grep -oE 'textbox "ایمیل یا شماره موبایل" \[ref=([a-z0-9]+)' | grep -oE '[a-z0-9]+$' | head -1)
PASS_REF=$(echo "$SNAP" | grep -oE 'textbox "رمز عبور" \[ref=([a-z0-9]+)' | grep -oE '[a-z0-9]+$' | head -1)
echo "REFS name=$NAME_REF id=$ID_REF pass=$PASS_REF"

# 2) ثبت‌نام
AB fill "@$NAME_REF" "کاربر تست E2E" >/dev/null
AB fill "@$ID_REF" "$EMAIL" >/dev/null
AB fill "@$PASS_REF" "E2ePass123!" >/dev/null
BTNREF=$(AB snapshot -i -c | grep -oE 'button "ساخت حساب" \[ref=([a-z0-9]+)' | grep -oE '[a-z0-9]+$' | head -1)
echo "SUBMIT_BTN=$BTNREF"
AB click "@$BTNREF" >/dev/null
sleep 3

# 3) مرحله تأیید — یادداشت صادقانه (production بدون سرویس)
echo "--- verify step ---"
VSNAP=$(AB snapshot -i -c)
echo "$VSNAP" | grep -E 'کد تأیید|سرویس ایمیل|بعداً|InputOTP|textbox "کد' | head -6
echo "$VSNAP" | grep -c "سرویس ایمیل/پیامک روی سرور تنظیم نشده" | sed 's/^/NO_PROVIDER_NOTE_COUNT=/'

# 4) «بعداً» → ورود به سایت
AB find role button click --name "بعداً" >/dev/null
sleep 2
echo "--- header after verify-later ---"
HSNAP=$(AB snapshot -i -c)
echo "$HSNAP" | grep -E "کاربر تست E2E|ورود / ثبتنام" | head -4
echo "$HSNAP" | grep -c "ورود / ثبتنام" | sed 's/^/LOGGED_OUT_LINK_COUNT=/'

# 5) خروج → ورود مجدد با همان اعتبارنامه (مسیر اصلی «ساین»)
AB cookies clear >/dev/null
AB open "http://localhost:3113/#/auth" >/dev/null
AB wait --load networkidle >/dev/null
SNAP2=$(AB snapshot -i -c)
ID_REF2=$(echo "$SNAP2" | grep -oE 'textbox "ایمیل یا شماره موبایل" \[ref=([a-z0-9]+)' | grep -oE '[a-z0-9]+$' | head -1)
PASS_REF2=$(echo "$SNAP2" | grep -oE 'textbox "رمز عبور" \[ref=([a-z0-9]+)' | grep -oE '[a-z0-9]+$' | head -1)
AB fill "@$ID_REF2" "$EMAIL" >/dev/null
AB fill "@$PASS_REF2" "E2ePass123!" >/dev/null
AB find role button click --name "ورود به حساب" >/dev/null
sleep 3
echo "--- header after login ---"
LSNAP=$(AB snapshot -i -c)
echo "$LSNAP" | grep -E "کاربر تست E2E|ورود / ثبتنام|پروفایل" | head -5
echo "$LSNAP" | grep -c "ورود / ثبتنام" | sed 's/^/LOGGED_OUT_LINK_AFTER_LOGIN=/'
echo "--- page errors ---"
AB errors | grep -v "^\[" | head -4
echo "EMAIL=$EMAIL"
kill $SPID 2>/dev/null
echo "E2E_DONE"
