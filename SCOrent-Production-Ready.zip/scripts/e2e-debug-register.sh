#!/usr/bin/env bash
set -u
cd /home/z/my-project
export PORT=3113
node .next/standalone/server.js > /tmp/e2e-server.log 2>&1 &
SPID=$!
for i in $(seq 1 30); do curl -sf -o /dev/null http://localhost:3113/ && break; sleep 0.5; done
AB() { agent-browser "$@" 2>&1; }
TS=$(date +%s)
EMAIL="e2e-$TS@scorent.dev"

# ثبت‌نام مستقیم با API (بدون Origin — کنترل سلامت endpoint)
echo "=== API register check ==="
curl -s -m 10 -X POST "http://localhost:3113/api/auth/register" -H "Content-Type: application/json" -d "{\"name\":\"API Test\",\"identifier\":\"api-$TS@scorent.dev\",\"password\":\"E2ePass123!\",\"uiLang\":\"fa\"}" | head -c 300
echo

# UI: تب ثبت‌نام → پر کردن → ارسال → رصد شبکه
AB open "http://localhost:3113/#/auth" >/dev/null
AB wait --load networkidle >/dev/null
TABREF=$(AB snapshot -i -c | grep -oE 'tab "ثبتنام" \[ref=([a-z0-9]+)' | grep -oE '[a-z0-9]+$' | head -1)
AB click "@$TABREF" >/dev/null
sleep 1
SNAP=$(AB snapshot -i -c)
NAME_REF=$(echo "$SNAP" | grep -oE 'textbox "نام نمایشی" \[ref=([a-z0-9]+)' | grep -oE '[a-z0-9]+$' | head -1)
ID_REF=$(echo "$SNAP" | grep -oE 'textbox "ایمیل یا شماره موبایل" \[ref=([a-z0-9]+)' | grep -oE '[a-z0-9]+$' | head -1)
PASS_REF=$(echo "$SNAP" | grep -oE 'textbox "رمز عبور" \[ref=([a-z0-9]+)' | grep -oE '[a-z0-9]+$' | head -1)
echo "REFS name=$NAME_REF id=$ID_REF pass=$PASS_REF"
AB fill "@$NAME_REF" "کاربر UI" >/dev/null
AB fill "@$ID_REF" "$EMAIL" >/dev/null
AB fill "@$PASS_REF" "E2ePass123!" >/dev/null
sleep 1
BTNREF=$(AB snapshot -i -c | grep -oE 'button "ثبتنام کن" \[ref=([a-z0-9]+)' | grep -oE '[a-z0-9]+$' | head -1)
echo "BTNREF=$BTNREF"
AB click "@$BTNREF"
sleep 4
echo "=== network api calls ==="
AB network requests --filter "auth" | tail -8
echo "=== page state after submit ==="
AB snapshot -i -c | grep -E 'heading "حسابت|heading "خوش|textbox "نام نمایشی"|textbox "کد|Character' | head -8
echo "=== toasts ==="
AB snapshot -c | grep -iE "toast|alert|خطا|موفق|ارسال شد|تنظیم نشده" | head -8
kill $SPID 2>/dev/null
echo DONE
