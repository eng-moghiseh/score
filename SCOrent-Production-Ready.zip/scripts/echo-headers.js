// ابزار تشخیصی موقت: هدرهایی که پروکسی پیش‌نمایش به اپ می‌فرستد را نشان می‌دهد
import http from "node:http";

const server = http.createServer((req, res) => {
  const headers = { ...req.headers };
  res.writeHead(200, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ method: req.method, url: req.url, headers }, null, 2));
});
server.listen(3113, "0.0.0.0", () => console.log("echo on 3113"));
