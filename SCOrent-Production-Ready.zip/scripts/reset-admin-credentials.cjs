/* هم‌ترازسازی ادمین DB با اعتبارنامه‌ی تعبیه‌شده در سورس (admin-init.ts)
 * هش دقیقاً با همان پارامترهای lib/server/password.ts ساخته می‌شود.
 */
const { randomBytes, scrypt } = require("node:crypto");
const { promisify } = require("node:util");
const { PrismaClient } = require("@prisma/client");

const scryptAsync = promisify(scrypt);
const N = 16384, r = 8, p = 1, KEYLEN = 64;

async function hashPassword(password) {
  const salt = randomBytes(16);
  const derived = await scryptAsync(password.normalize("NFKC"), salt, KEYLEN, { N, r, p, maxmem: 64 * 1024 * 1024 });
  return `scrypt$${N}$${r}$${p}$${salt.toString("hex")}$${derived.toString("hex")}`;
}

async function verify(password, stored) {
  const [algo, n, rr, pp, saltHex, hashHex] = stored.split("$");
  const expected = Buffer.from(hashHex, "hex");
  const derived = await scryptAsync(password.normalize("NFKC"), Buffer.from(saltHex, "hex"), expected.length, { N: Number(n), r: Number(rr), p: Number(pp), maxmem: 64 * 1024 * 1024 });
  return derived.length === expected.length && derived.equals(expected);
}

(async () => {
  const EMAIL = "admin@scorent.space";
  const PASSWORD = process.env.E2E_ADMIN_PASSWORD ?? "";
  const db = new PrismaClient();
  const admin = await db.user.findFirst({ where: { role: "SUPER_ADMIN" } });
  if (!admin) {
    console.error("no SUPER_ADMIN found");
    process.exit(1);
  }
  const ok = admin.passwordHash ? await verify(PASSWORD, admin.passwordHash) : false;
  if (ok && admin.email === EMAIL) {
    console.log("already aligned:", admin.email);
  } else {
    const updated = await db.user.update({
      where: { id: admin.id },
      data: { email: EMAIL, passwordHash: await hashPassword(PASSWORD), emailVerified: true, status: "ACTIVE", role: "SUPER_ADMIN" },
    });
    console.log("reset admin:", updated.email, "->", EMAIL);
  }
  const check = await db.user.findUnique({ where: { email: EMAIL } });
  console.log("final verify:", check ? await verify(PASSWORD, check.passwordHash) : "NO USER");
  await db.$disconnect();
})().catch((e) => { console.error(e); process.exit(1); });
