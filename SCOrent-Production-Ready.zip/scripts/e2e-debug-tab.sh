#!/usr/bin/env bash
set -u
cd /home/z/my-project
export PORT=3113
node .next/standalone/server.js > /tmp/e2e-server.log 2>&1 &
SPID=$!
for i in $(seq 1 30); do curl -sf -o /dev/null http://localhost:3113/ && break; sleep 0.5; done
AB() { agent-browser "$@" 2>&1; }
AB open "http://localhost:3113/#/auth" >/dev/null
AB wait --load networkidle >/dev/null
echo "--- tabs ---"
AB snapshot -i -c | grep -E 'tab "' 
TABREF=$(AB snapshot -i -c | grep -oE 'tab "ثبتنام" \[ref=([a-z0-9]+)' | grep -oE '[a-z0-9]+$' | head -1)
echo "TABREF=$TABREF"
echo "--- click result ---"
AB click "@$TABREF" | head -2
sleep 1
echo "--- after click: textboxes+buttons ---"
AB snapshot -i -c | grep -E 'textbox|button "ثبتنام کن"|heading' | head -10
echo "--- register tab selected? ---"
AB snapshot -i -c | grep -E 'tab "' 
kill $SPID 2>/dev/null
echo DONE
