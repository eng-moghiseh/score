#!/usr/bin/env node
/* Comprehensive admin API sweep v2: login → exercise every admin section endpoint.
 * Payloads mirror what the real admin UI sends (validated against each route's contract).
 * Credentials come from env ADMIN_TEST_EMAIL / ADMIN_TEST_PASSWORD (never hardcoded).
 */
const BASE = process.env.BASE || "http://localhost:3000";
const EMAIL = process.env.ADMIN_TEST_EMAIL;
const PASSWORD = process.env.ADMIN_TEST_PASSWORD;

if (!EMAIL || !PASSWORD) {
  console.error("Set ADMIN_TEST_EMAIL and ADMIN_TEST_PASSWORD env");
  process.exit(2);
}

const H = {
  "Content-Type": "application/json",
  Origin: BASE,
  Referer: `${BASE}/`,
  "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/126 Safari/537.36",
  "Sec-Fetch-Site": "same-origin",
};

const results = [];
let cookieJar = {};

function jarSet(res) {
  const setCookies = typeof res.headers.getSetCookie === "function" ? res.headers.getSetCookie() : [];
  for (const c of setCookies) {
    const [pair] = c.split(";");
    const [name, ...rest] = pair.split("=");
    if (rest.length) cookieJar[name.trim()] = rest.join("=");
  }
}
function cookieHeader() {
  return Object.entries(cookieJar).map(([k, v]) => `${k}=${v}`).join("; ");
}

async function call(method, path, body, opts = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: { ...H, Cookie: cookieHeader(), ...(opts.headers || {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
    redirect: "manual",
  });
  jarSet(res);
  let data = null;
  const text = await res.text();
  try { data = JSON.parse(text); } catch { data = { raw: text.slice(0, 200) }; }
  return { status: res.status, data };
}

function record(name, ok, detail = "") {
  results.push({ name, ok, detail });
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}${detail ? "  — " + detail : ""}`);
}

/* ---------- 1. Login ---------- */
{
  const r = await call("POST", "/api/auth/login", { identifier: EMAIL, password: PASSWORD });
  const ok = r.status === 200 && r.data?.ok === true && cookieJar["scorent_session"];
  record("login", ok, `status=${r.status} ok=${r.data?.ok} err=${r.data?.error ?? ""}`);
  if (!ok) { console.log("Cannot proceed without session."); printSummary(); process.exit(1); }
}

/* ---------- 2. Who am I ---------- */
{
  const r = await call("GET", "/api/auth/me");
  const role = r.data?.user?.role;
  record("auth/me shows staff role", r.status === 200 && ["SUPER_ADMIN", "ADMIN", "CONTENT_EDITOR", "SUPPORT_AGENT"].includes(role), `role=${role}`);
}

/* ---------- 3. Dashboard stats ---------- */
{
  const r = await call("GET", "/api/admin/stats");
  record("GET admin/stats", r.status === 200 && r.data?.ok === true && typeof r.data?.stats?.users === "number", `status=${r.status} err=${r.data?.error ?? ""}`);
}

/* ---------- 4. Games CRUD (full valid payload per game-schema) ---------- */
let gameId = null;
{
  const stamp = Date.now().toString(36);
  let r = await call("GET", "/api/admin/games?q=&page=1");
  record("GET admin/games (list)", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""} total=${r.data?.total ?? "?"}`);

  const game = {
    id: `sweep-test-${stamp}`,
    title: "بازی تستی اسکریپت ارزیابی",
    tagline: "بررسی سلامت کامل CRUD پنل مدیریت",
    description: "این بازی فقط برای آزمودن چرخه‌ی کامل ساخت/ویرایش/حذف در پنل مدیریت ساخته می‌شود و پس از پایان آزمون حذف می‌شود.",
    developer: "Scorent QA",
    year: 2026,
    genres: ["اکشن"],
    playstyles: ["داستان‌محور"],
    modes: ["تک‌نفره"],
    structure: "خطی",
    price: 1_500_000,
    originalPrice: 2_000_000,
    discount: 10,
    status: "PUBLISHED",
  };
  r = await call("POST", "/api/admin/games", { id: game.id, game, status: "PUBLISHED" });
  const created = r.status === 200 || r.status === 201;
  gameId = r.data?.game?.id ?? r.data?.id ?? null;
  record("POST admin/games (create)", created, `status=${r.status} id=${gameId} err=${JSON.stringify(r.data?.error ?? r.data?.fieldErrors ?? r.data?.errors ?? "").slice(0, 150)}`);

  if (gameId) {
    r = await call("PATCH", `/api/admin/games/${gameId}`, { game: { ...game, id: gameId, price: 990_000 } });
    record("PATCH admin/games/:id (edit price)", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""} errors=${JSON.stringify(r.data?.errors ?? []).slice(0, 100)}`);
    r = await call("GET", `/api/admin/games?q=sweep-test`);
    const found = (r.data?.games ?? []).some((g) => g.id === gameId);
    record("GET admin/games finds new game (persistence)", found, `matches=${(r.data?.games ?? []).length}`);
    r = await call("POST", `/api/admin/games/${gameId}/duplicate`);
    const dupId = r.data?.game?.id ?? r.data?.id ?? null;
    record("POST admin/games/:id/duplicate", r.status === 200 && r.data?.ok === true, `status=${r.status} dupId=${dupId} err=${r.data?.error ?? ""}`);
    if (dupId) {
      await call("DELETE", `/api/admin/games/${dupId}`);
      r = await call("GET", "/api/admin/games?deleted=1");
      const inTrash = (r.data?.games ?? []).some((g) => g.id === dupId);
      record("deleted game appears with deleted=1", inTrash);
      const rr = await call("POST", `/api/admin/games/${dupId}/restore`);
      record("POST restore deleted game", rr.status === 200 && rr.data?.ok === true, `status=${rr.status} err=${rr.data?.error ?? ""}`);
      await call("DELETE", `/api/admin/games/${dupId}`);
    }
    r = await call("POST", "/api/admin/games/bulk", { ids: [gameId], action: "draft" });
    record("POST admin/games/bulk (draft)", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
    const pubDraft = await call("GET", "/api/catalog");
    record("draft game hidden from public catalog", !(pubDraft.data?.games ?? []).some((g) => g.id === gameId));
    r = await call("POST", "/api/admin/games/bulk", { ids: [gameId], action: "publish" });
    record("POST admin/games/bulk (publish back)", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
    const pubRepublished = await call("GET", "/api/catalog");
    record("republished game visible again", (pubRepublished.data?.games ?? []).some((g) => g.id === gameId));
    const pub = await call("GET", "/api/catalog");
    const pubGame = (pub.data?.games ?? []).find((g) => g.id === gameId);
    record("public catalog shows created game with updated price", Boolean(pubGame), `price=${pubGame?.price ?? "?"}`);
    await call("DELETE", `/api/admin/games/${gameId}`);
    const pub2 = await call("GET", "/api/catalog");
    const gone = !(pub2.data?.games ?? []).some((g) => g.id === gameId);
    record("deleted game hidden from public catalog", gone);
  }
}

/* ---------- 5. Categories ---------- */
{
  let r = await call("GET", "/api/admin/cms/categories");
  record("GET admin/cms/categories", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
  const before = (r.data?.categories ?? []).length;
  const stamp = Date.now().toString(36);
  r = await call("POST", "/api/admin/cms/categories", { slug: `sweep-cat-${stamp}`, nameFa: "دسته تستی اسکریپت", nameEn: "Sweep Category" });
  const catId = r.data?.category?.id ?? r.data?.id ?? null;
  record("POST categories (create)", (r.status === 200 || r.status === 201) && r.data?.ok !== false, `status=${r.status} id=${catId} err=${JSON.stringify(r.data?.error ?? r.data?.errors ?? "").slice(0, 120)}`);
  if (catId) {
    r = await call("PATCH", `/api/admin/cms/categories/${catId}`, { nameFa: "دسته تستی ویرایش‌شده" });
    record("PATCH categories/:id", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
    const pubCat = await call("GET", "/api/categories");
    const visible = JSON.stringify(pubCat.data).includes("دسته تستی ویرایش‌شده") || JSON.stringify(pubCat.data).includes("دسته تستی اسکریپت");
    record("public categories reflect CMS change", visible, `status=${pubCat.status}`);
    r = await call("DELETE", `/api/admin/cms/categories/${catId}`);
    record("DELETE categories/:id", r.status === 200 || r.status === 204, `status=${r.status} err=${r.data?.error ?? ""}`);
    r = await call("GET", "/api/admin/cms/categories");
    record("categories count back to original", (r.data?.categories ?? []).length === before);
  }
}

/* ---------- 6. Filters ---------- */
{
  let r = await call("GET", "/api/admin/cms/filters");
  record("GET admin/cms/filters", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
  const stamp = Date.now().toString(36);
  r = await call("POST", "/api/admin/cms/filters", {
    key: `sweep_${stamp}`,
    labelFa: "فیلتر تستی اسکریپت",
    labelEn: "Sweep filter",
    type: "boolean",
    enabled: true,
    order: 99,
  });
  const fid = r.data?.filter?.id ?? r.data?.id ?? null;
  record("POST filters (create)", (r.status === 200 || r.status === 201) && r.data?.ok !== false, `status=${r.status} id=${fid} err=${JSON.stringify(r.data?.error ?? r.data?.errors ?? "").slice(0, 150)}`);
  if (fid) {
    r = await call("PATCH", `/api/admin/cms/filters/${fid}`, { labelFa: "فیلتر تستی ۲", enabled: false });
    record("PATCH filters/:id", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
    const fpub = await call("GET", "/api/filters");
    const disabledGone = !JSON.stringify(fpub.data).includes(`sweep_${stamp}`);
    record("disabled filter hidden from public /api/filters", disabledGone, `status=${fpub.status}`);
    r = await call("PATCH", `/api/admin/cms/filters/${fid}`, { enabled: true });
    const fpub2 = await call("GET", "/api/filters");
    record("enabled filter appears in public /api/filters", JSON.stringify(fpub2.data).includes(`sweep_${stamp}`), `status=${fpub2.status}`);
    r = await call("DELETE", `/api/admin/cms/filters/${fid}`);
    record("DELETE filters/:id", r.status === 200 || r.status === 204, `status=${r.status} err=${r.data?.error ?? ""}`);
  }
}

/* ---------- 7. Navigation ---------- */
{
  let r = await call("GET", "/api/admin/cms/nav");
  record("GET admin/cms/nav", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
  const before = JSON.stringify(r.data?.items ?? r.data?.nav ?? []).length;
  r = await call("POST", "/api/admin/cms/nav", { location: "footer", labelFa: "تست ناوبری اسکریپت", labelEn: "Sweep nav", href: "/store", enabled: true, order: 999 });
  const navId = r.data?.item?.id ?? r.data?.id ?? null;
  record("POST nav (create item)", (r.status === 200 || r.status === 201) && r.data?.ok !== false, `status=${r.status} id=${navId} err=${JSON.stringify(r.data?.error ?? r.data?.errors ?? "").slice(0, 120)}`);
  if (navId) {
    const pubNav = await call("GET", "/api/navigation");
    record("public navigation reflects CMS change", JSON.stringify(pubNav.data).includes("تست ناوبری اسکریپت"), `status=${pubNav.status}`);
    r = await call("PATCH", `/api/admin/cms/nav/${navId}`, { labelFa: "تست ویرایش‌شده" });
    record("PATCH nav/:id", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
    r = await call("DELETE", `/api/admin/cms/nav/${navId}`);
    record("DELETE nav/:id", r.status === 200 || r.status === 204, `status=${r.status} err=${r.data?.error ?? ""}`);
    const pubNav2 = await call("GET", "/api/navigation");
    record("nav deletion reflected publicly", !JSON.stringify(pubNav2.data).includes("تست ویرایش‌شده"));
  }
}

/* ---------- 8. Pages (builder) ---------- */
{
  let r = await call("GET", "/api/admin/cms/pages");
  record("GET admin pages list", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
  const stamp = Date.now().toString(36);
  const blocks = [
    { id: `sweep-hero-${stamp.slice(0, 6)}`, type: "hero", props: { titleFa: "تست صفحه‌ساز", titleEn: "Builder test", kicker: "sweep" } },
    { id: `sweep-rt-${stamp.slice(0, 6)}`, type: "richText", props: { bodyFa: "<p>متن تستی</p>", bodyEn: "<p>test text</p>" } },
  ];
  r = await call("POST", "/api/admin/cms/pages", { slug: `sweep-${stamp}`, titleFa: "صفحه تستی اسکریپت", titleEn: "Sweep page", blocks });
  const pageSlug = r.data?.page?.slug ?? null;
  const pageId = r.data?.page?.id ?? null;
  record("POST pages (create draft)", (r.status === 200 || r.status === 201) && r.data?.ok !== false, `status=${r.status} slug=${pageSlug} id=${pageId} err=${JSON.stringify(r.data?.error ?? r.data?.errors ?? "").slice(0, 200)}`);
  if (pageId) {
    r = await call("POST", `/api/admin/cms/pages/${pageId}/publish`);
    record("POST pages/:id/publish", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
    const pub = await call("GET", `/api/pages/${pageSlug}`);
    record("public /api/pages/:slug returns published page", pub.status === 200 && Array.isArray(pub.data?.page?.blocks) && pub.data.page.blocks.length === 2, `status=${pub.status} blocks=${pub.data?.page?.blocks?.length ?? 0}`);
    r = await call("GET", `/api/admin/cms/pages/${pageId}`);
    record("GET admin page detail (by id)", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
    r = await call("GET", `/api/admin/cms/pages/${pageId}/revisions`);
    record("GET page revisions", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
    r = await call("DELETE", `/api/admin/cms/pages/${pageId}`);
    record("DELETE page", r.status === 200 || r.status === 204, `status=${r.status} err=${r.data?.error ?? ""}`);
  }
  const home = await call("GET", "/api/pages/home");
  record("home endpoint sane (404=classic home fallback / 200=builder home)", home.status === 404 || (home.status === 200 && home.data?.ok === true), `status=${home.status} err=${home.data?.error ?? ""} blocks=${home.data?.page?.blocks?.length ?? 0}`);
}

/* ---------- 9. Media ---------- */
{
  const r = await call("GET", "/api/admin/cms/media");
  record("GET admin/cms/media", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""} items=${(r.data?.media ?? []).length}`);
}

/* ---------- 10. Content & settings ---------- */
{
  let r = await call("GET", "/api/admin/content");
  record("GET admin/content", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
  r = await call("GET", "/api/admin/cms/settings");
  if (r.status === 404) r = await call("GET", "/api/admin/settings");
  record("GET admin settings", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
  const orig = await call("GET", "/api/content");
  const origSlogan = (orig.data?.content ?? []).find((c) => c.key === "brand.slogan");
  r = await call("POST", "/api/admin/content", { key: "brand.slogan", valueFa: "شعار تستی اسکریپت — sweep", valueEn: "sweep slogan test" });
  record("POST admin/content (update)", (r.status === 200 || r.status === 201) && r.data?.ok !== false, `status=${r.status} err=${r.data?.error ?? ""}`);
  const pubContent = await call("GET", "/api/content");
  record("public content reflects change", JSON.stringify(pubContent.data).includes("sweep slogan test"), `status=${pubContent.status}`);
  // restore original
  if (origSlogan) {
    await call("POST", "/api/admin/content", { key: "brand.slogan", valueFa: origSlogan.valueFa, valueEn: origSlogan.valueEn });
    record("content restored to original", true);
  }
}

/* ---------- 11. Users / admins ---------- */
{
  let r = await call("GET", "/api/admin/users?page=1");
  record("GET admin/users", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""} total=${r.data?.total ?? "?"}`);
  r = await call("GET", "/api/admin/admins");
  record("GET admin/admins", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
  const suffix = Date.now().toString(36);
  r = await call("POST", "/api/admin/admins", { name: "Sweep Admin", email: `sweep-admin-${suffix}@example.com`, password: "Sweep!Admin#2026x", role: "ADMIN" });
  const admId = r.data?.admin?.id ?? r.data?.id ?? null;
  record("POST admins (create)", (r.status === 200 || r.status === 201) && r.data?.ok !== false, `status=${r.status} id=${admId} err=${JSON.stringify(r.data?.error ?? r.data?.errors ?? "").slice(0, 150)}`);
  if (admId) {
    r = await call("PATCH", `/api/admin/admins/${admId}`, { role: "CONTENT_EDITOR" });
    record("PATCH admins/:id (role change)", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
    r = await call("DELETE", `/api/admin/admins/${admId}`);
    record("DELETE admins/:id", r.status === 200 || r.status === 204, `status=${r.status} err=${r.data?.error ?? ""}`);
  }
}

/* ---------- 12. Tickets, notifications, audit ---------- */
{
  let r = await call("GET", "/api/admin/tickets?page=1");
  record("GET admin/tickets", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
  r = await call("GET", "/api/admin/notifications?page=1");
  record("GET admin/notifications", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
  r = await call("GET", "/api/admin/audit?take=5");
  record("GET admin/audit", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
  r = await call("GET", "/api/admin/providers");
  record("GET admin/providers", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
  r = await call("GET", "/api/admin/announcements");
  record("GET admin/announcements", r.status === 200 && r.data?.ok === true, `status=${r.status} err=${r.data?.error ?? ""}`);
}

/* ---------- summary ---------- */
function printSummary() {
  const fail = results.filter((r) => !r.ok);
  console.log(`\n===== SUMMARY: ${results.length - fail.length}/${results.length} passed, ${fail.length} failed =====`);
  for (const f of fail) console.log(`  FAIL: ${f.name} ${f.detail}`);
}
printSummary();
process.exit(results.every((r) => r.ok) ? 0 : 1);
