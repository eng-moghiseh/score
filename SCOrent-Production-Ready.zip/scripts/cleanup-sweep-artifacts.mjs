#!/usr/bin/env node
/* پاک‌سازی نهایی دیتابیس برای انتشار production:
 * - حذف کاربران تستی (همه به‌جز admin@scorent.space) با داده‌های وابسته
 * - حذف نهایی بازی‌های تستی زباله‌دان
 * - خالی‌کردن جدول گذرای rate-limit
 * حساب ادمین واقعی و داده‌های سایت دست‌نخورده می‌ماند. */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();
const ADMIN_EMAIL = "admin@scorent.space";
const TEST_GAME_IDS = ["sweep-test-mwjoazma", "copy", "sweep-test-mwm6eu4s", "copy-2"];

const testUsers = await db.user.findMany({ where: { email: { not: ADMIN_EMAIL } }, select: { id: true, email: true } });
const ids = testUsers.map((u) => u.id);
console.log("test users to remove:", testUsers.length);

if (process.argv.includes("--purge")) {
  const tickets = await db.supportTicket.findMany({ where: { userId: { in: ids } }, select: { id: true } });
  const ticketIds = tickets.map((t) => t.id);
  if (ticketIds.length) {
    const msgs = await db.ticketMessage.deleteMany({ where: { ticketId: { in: ticketIds } } });
    console.log("ticket messages removed:", msgs.count);
    const tk = await db.supportTicket.deleteMany({ where: { id: { in: ticketIds } } });
    console.log("tickets removed:", tk.count);
  }
  const chat = await db.chatLog.deleteMany({ where: { userId: { in: ids } } });
  console.log("chat logs removed:", chat.count);
  const reviews = await db.review.deleteMany({ where: { userId: { in: ids } } });
  console.log("reviews removed:", reviews.count);
  const rentals = await db.rentalRecord.deleteMany({ where: { userId: { in: ids } } });
  console.log("rentals removed:", rentals.count);
  const notifs = await db.notification.deleteMany({ where: { userId: { in: ids } } });
  console.log("notifications removed:", notifs.count);
  const audits = await db.auditLog.deleteMany({ where: { actorId: { in: ids } } });
  console.log("test audit rows removed:", audits.count);
  const games = await db.gameRecord.deleteMany({ where: { id: { in: TEST_GAME_IDS } } });
  console.log("test games purged:", games.count);
  const rl = await db.rateLimit.deleteMany({});
  console.log("rate-limit rows cleared:", rl.count);
  const users = await db.user.deleteMany({ where: { id: { in: ids } } });
  console.log("users removed:", users.count, "(sessions/tokens cascade)");

  console.log("— final state —");
  console.log({
    users: await db.user.count(),
    staff: await db.user.count({ where: { role: { in: ["ADMIN", "SUPER_ADMIN", "MODERATOR", "SUPPORT", "ANALYST"] } } }),
    gameRecords: await db.gameRecord.count(),
    trash: await db.gameRecord.count({ where: { deletedAt: { not: null } } }),
    sessions: await db.session.count(),
    tickets: await db.supportTicket.count(),
    categories: await db.category.count(),
    filters: await db.filterDefinition.count(),
    audit: await db.auditLog.count(),
    media: await db.media.count(),
  });
} else {
  const tickets = await db.supportTicket.count({ where: { userId: { in: ids } } });
  console.log("their tickets:", tickets, "| audit rows:", await db.auditLog.count({ where: { actorId: { in: ids } } }));
}
await db.$disconnect();
