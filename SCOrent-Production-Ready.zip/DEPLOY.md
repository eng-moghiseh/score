# استقرار Scorent روی هاست 🦂

Scorent یک اپلیکیشن **Next.js 16 (Node.js)** است با دو حالت دیتابیس:
- **Netlify / serverless → PostgreSQL مدیریت‌شده** (الزامی — فایل SQLite روی توابع serverless پایدار نمی‌ماند)
- **سرور سنتی (VPS) → SQLite** (پیش‌فرض پروژه)

> ⚠ اگر سایت را قبلاً به‌صورت استاتیک روی Netlify آپلود کرده‌ای، همه‌ی مسیرهای `/api/*` (ورود، ثبت‌نام، پنل ادمین، AI) کار نمی‌کنند؛ این راهنما هر دو مسیر درست را می‌دهد.

---

## گزینه‌ی الف — استقرار روی Netlify با PostgreSQL (پیشنهادی برای دامنه‌ی فعلی)

### ۱) ساخت دیتابیس PostgreSQL
یک سرویس provider-independent بساز (هرکدام پلن رایگان دارد):
- [Neon](https://neon.tech) → Copy connection string
- [Supabase](https://supabase.com) → Project Settings → Database → Connection string (URI)
- [Railway](https://railway.app) → PostgreSQL → Variables → `DATABASE_URL`

رشته‌ی اتصال چیزی شبیه این است:
```
postgresql://USER:PASSWORD@HOST/DBNAME?sslmode=require
```

### ۲) اتصال ریپو به Netlify
- zip سورس را به یک ریپوی Git (GitHub/GitLab) push کن.
- Netlify → «Add new site» → «Import an existing project» → ریپو را انتخاب کن.
- `netlify.toml` داخل پروژه همه‌چیز را تنظیم می‌کند (Build command: `npm run build:netlify`، پلاگین رسمی `@netlify/plugin-nextjs`).
- در **Site configuration → Environment variables** این‌ها را تنظیم کن:

| متغیر | مقدار | الزامی؟ |
| --- | --- | --- |
| `DATABASE_URL` | رشته‌ی PostgreSQL مرحله‌ی ۱ | ✅ |
| `AUTH_SECRET` | خروجی `openssl rand -hex 32` | ✅ |
| `ADMIN_EMAIL` | ایمیل ادمین خودت — **بدون آن روی دیتابیس خالی هیچ ادمینی ساخته نمی‌شود** (اعتبارنامه‌ی تعبیه‌شده از نسخه‌ی CMS حذف شده است) | ✅ برای استقرار تازه |
| `ADMIN_PASSWORD` | رمز قوی و منحصربه‌فرد — حداقل ۱۲ نویسه (رمزهای عمومی/پیش‌فرض رد می‌شوند) | ✅ برای استقرار تازه |
| `DEMO_MODE` | `false` (در production کد تأیید هرگز در پاسخ API نمی‌آید) | اختیاری |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` | از Google Cloud Console | اختیاری |
| `SMTP_HOST/PORT/USER/PASS/SECURE/FROM` | سرویس ایمیل واقعی | اختیاری |
| `SMS_PROVIDER=kavenegar` + `SMS_API_KEY` (+`SMS_FROM`) یا `SMS_WEBHOOK_URL` | سرویس پیامک واقعی | اختیاری |
| `SITE_URL` | دامنه‌ی عمومی سایت (برای sameOrigin پشت reverse-proxy، sitemap و canonical) | پیشنهادی |
| `GOOGLE_SITE_VERIFICATION` | تأیید مالکیت در Google Search Console | اختیاری |
| `NEXT_PUBLIC_GA4_ID` | شناسه‌ی Google Analytics 4 (G-…) | اختیاری |
| `ZAI_API_KEY` | کلید دستیار هوشمند (اگر env حساب سرویس نیست) | اختیاری |
| `CLOUDINARY_URL` یا `CLOUDINARY_CLOUD_NAME/API_KEY/API_SECRET` | ذخیره‌سازی رسانه روی object storage (پیش‌فرض: دیتابیس) | اختیاری |

- Deploy را بزن. اسکریپت `check-env` پیش از build، پیکربندی را اعتبارسنجی می‌کند و خطای واضح می‌دهد اگر چیزی کم باشد.

### ۳) ساخت جداول دیتابیس
**مسیر استاندارد (دیتابیس خالی جدید):** نیازی به کار دستی نیست — `build:netlify` در هر deploy خودش `prisma migrate deploy` را اجرا می‌کند و Migrationهای نسخه‌بندی‌شده (`0_init` + `1_cms_catalog_tables`) همه‌ی ۲۴ جدول را می‌سازند. Seed محتوا و ساخت ادمین هم روی اولین بازدید به‌صورت خودکار انجام می‌شود (idempotent).

**اگر دیتابیس PG قبلاً با `db push` ساخته شده (استقرار قدیمی):** یک‌بار وضعیت Migrationها را ثبت کن تا deploy سعی در ساخت مجدد نکند:

```bash
DATABASE_URL="postgresql://…" npx prisma migrate resolve --applied 0_init --schema prisma/schema.postgres.prisma
DATABASE_URL="postgresql://…" npx prisma migrate resolve --applied 1_cms_catalog_tables --schema prisma/schema.postgres.prisma
```

هیچ دستور مخرب داده‌ای لازم نیست؛ `db push` فقط ابزار توسعه‌ی SQLite است و در production استفاده نمی‌شود.

### ۴) ورود واقعی گوگل
- Google Cloud Console → Credentials → OAuth Client ID → Web application
- **Authorized redirect URI:** `https://scorent1.netlify.app/api/auth/google/callback`
- `GOOGLE_CLIENT_ID` و `GOOGLE_CLIENT_SECRET` را در Netlify env ست کن و redeploy.

### ۵) نکته‌های Netlify
- توابع serverless بی‌حالت‌اند؛ همه‌ی stateها (نشست‌ها، OTP، rate limit، حسابرسی) در PostgreSQL مشترک‌اند.
- کوکی نشست در production با `SameSite=None; Secure; Partitioned` ست می‌شود — در iframe هم کار می‌کند.
- هدرهای امنیتی (CSP، X-Frame-Options و…) فقط در production فعال‌اند؛ اگر جایی سایت باید داخل iframe باز شود `FRAME_GUARD=false`.

---

## گزینه‌ی ب — سرور سنتی (VPS) با SQLite

```bash
npm install
npx prisma generate
npx prisma db push          # فقط برای دیتابیس تازه؛ db/custom.db همراه سورس آماده است
npm run build
NODE_ENV=production PORT=3000 node .next/standalone/server.js
```

با pm2 پایدارش کن:

```bash
npm i -g pm2
pm2 start ".next/standalone/server.js" --name scorent --env NODE_ENV=production
pm2 save && pm2 startup
```

دامنه را با nginx/Caddy به پورت ۳۰۰۰ reverse-proxy کن. حساب ادمین (SUPER_ADMIN) از قبل درون `db/custom.db` که همراه سورس منتشر می‌شود ساخته شده است (ایمیل: `admin@scorent.space`) — **بلافاصله بعد از اولین ورود رمز را از پروفایل → کارت حساب عوض کن.** برای چرخش رمز از ترمینال سرور (با ابطال همه‌ی نشست‌ها و ثبت در لاگ حسابرسی):

```bash
ROTATE_ADMIN_EMAIL="admin@scorent.space" ROTATE_ADMIN_PASSWORD="رمز_جدید_حداقل_۱۲_کاراکتر" node scripts/rotate-admin.mjs
```

---

## چک‌لیست امنیت پیش از انتشار عمومی

- [ ] `AUTH_SECRET` تصادفی و ≥۳۲ کاراکتر
- [ ] `ADMIN_PASSWORD` منحصربه‌فرد (بدون رمزهای عمومی)
- [ ] HTTPS فعال (کوکی‌ها در production با `Secure` ست می‌شوند)
- [ ] `DEMO_MODE` در production غیرفعال (کد تأیید در پاسخ API نمی‌آید)
- [ ] Redirect URI گوگل دقیقاً دامنه‌ی نهایی است
- [ ] پوشه‌ی `db/` و فایل `.env` از web root بیرون‌اند
- [ ] اگر سایت پشت reverse-proxy با بازنویسی Host است، `SITE_URL` را با دامنه‌ی عمومی ست کن (بررسی CSRF خودکار از `x-forwarded-host` و `Referer` هم پشتیبانی می‌کند)
- [ ] بعد از اولین ورود، رمز ادمین را عوض کردی (از پنل یا با `scripts/rotate-admin.mjs`)

## عیب‌یابی سریع

| نشانه | علت احتمالی |
| --- | --- |
| `AUTH_SECRET_MISSING` در لاگ توابع | `AUTH_SECRET` در Netlify env تنظیم نشده |
| `the URL must start with the protocol file:` | باندل با کلاینت SQLite ساخته شده ولی URL به Postgres اشاره دارد → `npm run build:netlify` را کامل اجرا کن |
| APIها ۵۰۰ ولی صفحه باز می‌شود | استقرار استاتیک (بدون ران‌تایم Next) → از مسیر «اتصال ریپو» استفاده کن |
| ورود گوگل «پروتکل امنیتی» | جریان داخل iframe اجرا شده → دکمه‌ی گوگل به‌صورت خودکار تب جدید باز می‌کند؛ Redirect URI را هم چک کن |
| صفحات API خطای ۵۰۰ | `npx prisma generate` اجرا نشده یا `DATABASE_URL` نامعتبر است |
| هر فرمی «BAD_ORIGIN» می‌دهد | درخواست پشت reverse-proxy با Host بازنویسی‌شده می‌آید → `SITE_URL` را با دامنه‌ی عمومی ست کن یا مطمئن شو پروکسی `x-forwarded-host` را ارسال می‌کند |

---

## مرکز کنترل Scorent (CMS) — نسخه‌ی حاکم

از پنل مدیریت (`/#/admin`) این ماژول‌ها در دسترس است — همه با ذخیره‌ی واقعی در دیتابیس و ثبت در لاگ حسابرسی:

| ماژول | شرح |
| --- | --- |
| بازی‌ها | CRUD کامل روی همه‌ی بازی‌ها (دیتاست seed + سفارشی)، وضعیت منتشرشده/پیش‌نویس/آرشیو، کپی، حذف نرم + زباله‌دان و بازیابی، عملیات گروهی، فیلدهای CMS (کاور/گالری/پلتفرم/سئو) |
| رده‌ها | درخت دوزبانه با ترتیب، حذف امن (فرزندان بالا می‌روند) |
| فیلترها | فیلترهای پویای فروشگاه — ۹ نوع — بدون تغییر سورس در فروشگاه عمومی اعمال می‌شوند |
| ناوبری | منوهای هدر/موبایل/فوتر/سفارشی با زیرمنو؛ تغییرات بلافاصله در سایت |
| صفحه‌ساز | صفحات بلوکی با drag-drop، پیش‌نمایش سه‌اندازه، پیش‌نویس/انتشار و نسخه‌های قابل بازیابی؛ صفحه‌ی عمومی: `/#/p/:slug`؛ اگر صفحه‌ی منتشرشده‌ی slug=`home` وجود داشته باشد جایگزین صفحه اصلی می‌شود |
| رسانه | بارگذاری تصویر (پیش‌فرض: ذخیره در دیتابیس — سازگار با serverless) + متادیتای alt دوزبانه؛ URL سرو: `/api/media/:id` |
| تنظیمات | حالت نگه‌داری، حالت نمایشی، زبان/ارز پیش‌فرض، تماس و شبکه‌ها، سئوی پیش‌فرض، تنظیمات فروشگاه و اجاره |

### امنیت اعتبارنامه‌ها (مهم)
- **هیچ رمز یا کلیدی در سورس وجود ندارد.** `admin-init.ts` حذف شده است.
- نشست‌ها با `AUTH_SECRET` (env) یا `db/.auth-secret` (محلی) امضا می‌شوند.
- برای چرخش رمز ادمین روی محلی: `node scripts/rotate-admin.mjs` (رمز جدید یک‌بار چاپ می‌شود).
- اگر رمز ادمین در گفتگو/ایمیل فاش شده، آن را از «پروفایل ← حساب» عوض کن.

### مهاجرت داده‌ها
اولین اجرا (seed idempotent):
1. بازی‌های دیتاست مرکزی → جدول `GameRecord` (شناسه‌ها حفظ می‌شوند؛ رکورد موجود بازنویسی نمی‌شود).
2. اورراید‌ها و بازی‌های سفارشی قدیمی (جداول `GameOverride` و `CustomGame`) یک‌بار به `GameRecord` ادغام می‌شوند (مارکر `SiteSetting.catalog.legacyMerged.v1`) — هیچ داده‌ای گم نمی‌شود و جداول قدیمی دست‌نخورده باقی می‌مانند.
