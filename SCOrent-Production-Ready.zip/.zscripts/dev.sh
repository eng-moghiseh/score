#!/bin/bash

set -euo pipefail

# 获取脚本所在目录（.zscripts）
# 使用 $0 获取脚本路径（与 build.sh 保持一致）
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

log_step_start() {
        local step_name="$1"
        echo "=========================================="
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Starting: $step_name"
        echo "=========================================="
        export STEP_START_TIME
        STEP_START_TIME=$(date +%s)
}

log_step_end() {
        local step_name="${1:-Unknown step}"
        local end_time
        end_time=$(date +%s)
        local duration=$((end_time - STEP_START_TIME))
        echo "=========================================="
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Completed: $step_name"
        echo "[LOG] Step: $step_name | Duration: ${duration}s"
        echo "=========================================="
        echo ""
}

start_mini_services() {
        local mini_services_dir="$PROJECT_DIR/mini-services"
        local started_count=0

        log_step_start "Starting mini-services"
        if [ ! -d "$mini_services_dir" ]; then
                echo "Mini-services directory not found, skipping..."
                log_step_end "Starting mini-services"
                return 0
        fi

        echo "Found mini-services directory, scanning for sub-services..."

        for service_dir in "$mini_services_dir"/*; do
                if [ ! -d "$service_dir" ]; then
                        continue
                fi

                local service_name
                service_name=$(basename "$service_dir")
                echo "Checking service: $service_name"

                if [ ! -f "$service_dir/package.json" ]; then
                        echo "[$service_name] No package.json found, skipping..."
                        continue
                fi

                if ! grep -q '"dev"' "$service_dir/package.json"; then
                        echo "[$service_name] No dev script found, skipping..."
                        continue
                fi

                echo "Starting $service_name in background..."
                (
                        cd "$service_dir"
                        echo "[$service_name] Installing dependencies..."
                        bun install
                        echo "[$service_name] Running bun run dev..."
                        exec bun run dev
                ) >"$PROJECT_DIR/.zscripts/mini-service-${service_name}.log" 2>&1 &

                local service_pid=$!
                echo "[$service_name] Started in background (PID: $service_pid)"
                echo "[$service_name] Log: $PROJECT_DIR/.zscripts/mini-service-${service_name}.log"
                disown "$service_pid" 2>/dev/null || true
                started_count=$((started_count + 1))
        done

        echo "Mini-services startup completed. Started $started_count service(s)."
        log_step_end "Starting mini-services"
}

wait_for_service() {
        local host="$1"
        local port="$2"
        local service_name="$3"
        local max_attempts="${4:-60}"
        local attempt=1

        echo "Waiting for $service_name to be ready on $host:$port..."

        while [ "$attempt" -le "$max_attempts" ]; do
                if curl -s --connect-timeout 2 --max-time 5 "http://$host:$port" >/dev/null 2>&1; then
                        echo "$service_name is ready!"
                        return 0
                fi

                echo "Attempt $attempt/$max_attempts: $service_name not ready yet, waiting..."
                sleep 1
                attempt=$((attempt + 1))
        done

        echo "ERROR: $service_name failed to start within $max_attempts seconds"
        return 1
}

cleanup() {
        if [ -n "${DEV_PID:-}" ] && kill -0 "$DEV_PID" >/dev/null 2>&1; then
                echo "Stopping Next.js dev server (PID: $DEV_PID)..."
                kill "$DEV_PID" >/dev/null 2>&1 || true
        fi
}

trap cleanup EXIT INT TERM

cd "$PROJECT_DIR"

if ! command -v bun >/dev/null 2>&1; then
        echo "ERROR: bun is not installed or not in PATH"
        exit 1
fi

log_step_start "bun install"
echo "[BUN] Installing dependencies..."
bun install
log_step_end "bun install"

log_step_start "bun run db:push"
echo "[BUN] Setting up database..."
bun run db:push
log_step_end "bun run db:push"

log_step_start "Starting Next.js server"
# حالت تولید اگر standalone build موجود باشد (روشن‌شدن سریع و پایدار — بدون compile سرد)
# در غیر این صورت fallback به حالت توسعه (next dev)
STANDALONE_SERVER="$PROJECT_DIR/.next/standalone/server.js"
STANDALONE_STATIC="$PROJECT_DIR/.next/standalone/.next/static/chunks"
if [ -f "$STANDALONE_SERVER" ] && [ -d "$STANDALONE_STATIC" ]; then
        echo "[PROD] Standalone build found — starting production server on port 3000..."
        # SITE_URL: whitelist دامنه‌ی عمومی برای sameOrigin (پشت پراکسی معکوس لازم است)
        NODE_ENV=production PORT=3000 DATABASE_URL="file:$PROJECT_DIR/db/custom.db" \
                SITE_URL="${SITE_URL:-https://scorent.space-z.ai}" \
                node "$STANDALONE_SERVER" >"$PROJECT_DIR/prod.log" 2>&1 &
        DEV_PID=$!
else
        echo "[DEV] No standalone build — starting development server..."
        bun run dev &
        DEV_PID=$!
        # ————— خودترمیمی همیشگی بوت —————
        # هر recycle پوشه‌ی .next را پاک می‌کند؛ تا پیش از این یعنی همیشه dev سرد.
        # حالا: بوت سریع با dev + ساخت standalone در پس‌زمینه؛ به‌محض کامل‌شدن،
        # سرویس به حالت تولید سوییچ می‌شود تا گیت‌وی/دیپلوی هرگز سرور سرد یا مرده نبیند
        # (ریشه‌ی «Sorry, there was a problem deploying the code» دقیقاً همین بود).
        (
                cd "$PROJECT_DIR"
                LOCK="$PROJECT_DIR/.zscripts/boot-build.lock"
                if [ -e "$LOCK" ]; then exit 0; fi
                touch "$LOCK" 2>/dev/null || exit 0
                echo "[BOOT-BUILD] $(date '+%F %T') building production standalone in background..."
                if bun run build >"$PROJECT_DIR/boot-build.log" 2>&1 \
                        && [ -f "$PROJECT_DIR/.next/standalone/server.js" ] \
                        && [ -d "$PROJECT_DIR/.next/standalone/.next/static/chunks" ]; then
                        rm -f "$LOCK"
                        echo "[BOOT-BUILD] $(date '+%F %T') build OK — switching dev → production..."
                        kill "$DEV_PID" >/dev/null 2>&1 || true
                        pkill -f "next dev" >/dev/null 2>&1 || true
                        sleep 2
                        pkill -f "next-server" >/dev/null 2>&1 || true
                        sleep 1
                        NODE_ENV=production PORT=3000 DATABASE_URL="file:$PROJECT_DIR/db/custom.db" \
                                SITE_URL="${SITE_URL:-https://scorent.space-z.ai}" \
                                node "$PROJECT_DIR/.next/standalone/server.js" >>"$PROJECT_DIR/prod.log" 2>&1 &
                        PROD_PID=$!
                        disown "$PROD_PID" 2>/dev/null || true
                        for i in $(seq 1 15); do
                                if curl -s --connect-timeout 2 --max-time 5 http://localhost:3000/ >/dev/null 2>&1; then
                                        echo "[BOOT-BUILD] production server is up (PID: $PROD_PID)"
                                        exit 0
                                fi
                                sleep 2
                        done
                        echo "[BOOT-BUILD] WARNING: production server did not answer within 30s — see prod.log"
                else
                        rm -f "$LOCK"
                        echo "[BOOT-BUILD] build FAILED — dev server keeps serving (see boot-build.log)"
                fi
        ) >"$PROJECT_DIR/.zscripts/boot-build.log" 2>&1 &
        disown "$!" 2>/dev/null || true
fi
log_step_end "Starting Next.js server"

log_step_start "Waiting for Next.js dev server"
wait_for_service "localhost" "3000" "Next.js dev server"
log_step_end "Waiting for Next.js dev server"

log_step_start "Health check"
echo "[BUN] Performing health check..."
curl -fsS localhost:3000 >/dev/null
echo "[BUN] Health check passed"
log_step_end "Health check"

start_mini_services

echo "Next.js dev server is running in background (PID: $DEV_PID)."
echo "Use 'kill $DEV_PID' to stop it."
disown "$DEV_PID" 2>/dev/null || true
unset DEV_PID
