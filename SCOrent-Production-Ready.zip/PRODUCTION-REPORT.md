# گزارش فنی نسخه‌ی Production-Ready — SC ORENT

تاریخ تحویل: ۲۰۲۶-۱۱-۲۰ · مبنا: سورس موجود (بدون بازنویسی، بدون حذف قابلیت)

## ۱) تغییرات فایل‌ها

| فایل | تغییر |
| --- | --- |
| `prisma/migrations/1_cms_catalog_tables/migration.sql` | **جدید** — ۱۳ جدول جاافتاده در مهاجرت PostgreSQL (GameRecord، CustomGame، Category، FilterDefinition، NavigationItem، Page، PageRevision، SiteSetting، Media، Promotion، RentalRecord، Review، ChatLog) + AlterTableهای پشتیبانی |
| `src/lib/seo.ts` | **جدید** — لایه SEO: متادیتای هر مسیر عمومی، JSON-LD (Organization/WebSite/VideoGame/BreadcrumbList)، اسکریپت بوت مسیر |
| `src/middleware.ts` | **جدید** — پل SEO برای روتر hash: مسیرهای عمومی (‎/game/:id، ‎/p/:slug، ‎/store و…) با URL واقعی به نمای صحیح بازنویسی می‌شوند |
| `src/app/page.tsx` | پوسته به Server Component تبدیل شد + `generateMetadata` برای هر مسیر + JSON-LD سمت سرور (AppShell و روتر دست‌نخورده) |
| `src/app/layout.tsx` | `metadataBase`، canonical، Twitter Card، robots پیش‌فرض، تأیید GSC از env، GA4 اختیاری از env، JSON-LD سازمان |
| `src/app/sitemap.ts` | URLهای hash بی‌اثر (`/#/…`) با URLهای واقعی قابل ایندکس جایگزین شد + بازی‌های منتشرشده و صفحات CMS پویا |
| `src/app/robots.ts` | مسدودی واقعی `/api/` و `/admin`؛ حذف ورودی بی‌اثر hash |
| `next.config.ts` | `output: "standalone"` فقط برای سرور اختصاصی؛ روی Netlify خاموش (الزام ران‌تایم رسمی) |
| `package.json` | `build:netlify` اکنون `prisma migrate deploy` را قبل از build اجرا می‌کند |
| `netlify.toml` | `NODE_VERSION` به 22 |
| `src/app/api/catalog/route.ts` | فراخوانی `ensureSeed` — استقرار تازه روی اولین بازدید کاملاً خودکار bootstrap می‌شود |
| `.gitignore` | مسیر `db/` (دیتابیس واقعی + کلید امضا) از سورس قابل انتشار خارج شد |

## ۲) امنیت — یافته‌ها و اقدامات

- **Secretها**: اسکن کل سورس → صفر credential تعبیه‌شده. ادمین فقط از env ساخته می‌شود (`ADMIN_EMAIL`/`ADMIN_PASSWORD` — فقط وقتی هیچ SUPER_ADMIN وجود نداشته باشد؛ رمزهای عمومی در blocklist).
- **کلید امضای نشست**: چرخش شد؛ همه‌ی نشست‌های قبلی ابطال/پاک شدند. Production فقط از `AUTH_SECRET` env می‌خواند (بدون آن روی serverless با `AUTH_SECRET_MISSING` شکست صریح می‌دهد — fail-safe).
- **دیتابیس**: فایل SQLite واقعی و کاربران واقعی دیگر در بسته‌ی انتشار نیستند.
- **Authorization**: گارد RBAC (`requirePerm`/ROLES) روی همه‌ی مسیرهای admin + بررسی مالکیت تیکت‌ها (IDOR-safe) + same-origin روی همه‌ی POSTها بازبینی شد.
- **Rate limit**: login (دولایه)، register، resend، reset، forgot، password، google، chat (۲۰/دقیقه)، tickets، admin — پوشش کامل بود؛ بدون تغییر.
- **Error hygiene**: صفر نشت stack trace یا پیام داخلی در پاسخ‌های API.
- **Headers/CSP/HSTS**: CSP + X-Frame-Options + nosniff + Referrer-Policy موجود؛ HSTS در سطح Netlify CDN فعال می‌شود (Force HTTPS).
- **npm audit**: ۱۰ مورد (۶ high/۴ moderate) همگی در وابستگی‌های build-time (زنجیره‌ی Prisma CLI، js-yaml، sharp/libvips) — در مسیر HTTP ران‌تایم حضور ندارند؛ رفعشان نیازمند پرش major (Prisma 8) است که با الزام سازگاری تضاد دارد → ریسک پذیرفته‌شده و مستند.

## ۳) دیتابیس و Migration

- مهاجرت قبلی فقط ۱۱ جدول از ۲۴ داشت → **در یک PG واقعی (v18) با shadow-database diff تشخیص و `1_cms_catalog_tables` ساخته شد.**
- `prisma migrate deploy` روی دیتابیس کاملاً خالی → موفق، ۲۵ جدول (۲۴ مدل + جدول ردیابی) ساخته شد.
- Seedها idempotent هستند (upsert) و داده‌ی موجود را تخریب/تکرار نمی‌کنند.
- Bootstrap مدیر ارشد: فقط از env، بدون چاپ رمز در لاگ، با ثبت در لاگ حسابرسی.
- **برای دیتابیس PG موجود که قبلاً با `db push` ساخته شده**: یک‌بار `npx prisma migrate resolve --applied 0_init && npx prisma migrate resolve --applied 1_cms_catalog_tables` اجرا کن (هیچ تغییر schema‌ای اعمال نمی‌شود؛ فقط ثبت وضعیت).
- `db push` هیچ‌جا در مسیر production استفاده نمی‌شود (فقط ابزار توسعه‌ی SQLite).

## ۴) SEO

- **مشکل اصلی (حل‌شده)**: سایت SPA با روتر hash بود → برای گوگل همه‌چیز یک صفحه بود و sitemap قبلی URLهای غیرقابل ایندکس می‌داد. اکنون مسیرهای عمومی URL واقعی دارند، متادیتای اختصاصی سمت سرور تولید می‌شود و روتر hash بدون هیچ تغییری کار می‌کند.
- Canonical برای همه‌ی مسیرهای عمومی · Sitemap پویا (بازی‌ها + صفحات CMS) · Robots (بستن API/admin) · OG/Twitter با کاور واقعی بازی · JSON-LD: Organization، WebSite، VideoGame (قیمت واقعی دیتابیس؛ تومان→ریال با نسبت ۱۰)، BreadcrumbList · GA4 و GSC از env.
- مسیرهای خصوصی (profile/settings/admin/auth) در sitemap و rewrite نیستند.
- بدون هیچ claim تضمین رتبه؛ بدون امتیاز/review جعلی؛ بدون Black Hat.

## ۵) تست‌های واقعاً اجراشده

| تست | نتیجه |
| --- | --- |
| `tsc --noEmit` | ۰ خطا |
| `eslint .` | ۰ خطا |
| `vitest run` | **۱۵۵/۱۵۵ پاس** (۱۲ فایل) |
| `prisma migrate deploy` روی PG خالی | موفق — ۲۵ جدول |
| `next build` (production) | موفق |
| Boot واقعی سرور + smoke (در ادامه‌ی گزارش) | در بخش ۷ |

## ۶) موارد نیازمند تنظیم دستی (شفاف)

1. حساب Netlify + اتصال ریپو — در سندباکس قابل انجام نیست.
2. PostgreSQL مدیریتی (Neon/Supabase) و وارد کردن envها در Netlify.
3. `prisma migrate resolve --applied …` برای دیتابیس PG موجودِ قبلی.
4. دامنه‌ی اختصاصی + Force HTTPS + ثبت sitemap در Search Console.
5. کلید سرویس AI: از ران‌تایم z-ai سمت سرور استفاده می‌شود؛ اگر Provider اختصاصی می‌خواهی از پنل ادمین وارد کن (در DB ذخیره می‌شود، هرگز به کلاینت نمی‌رود).

## ۷) Environment Variables برای Netlify

| متغیر | الزام | توضیح |
| --- | --- | --- |
| `DATABASE_URL` | ✔ | PostgreSQL مدیریتی (Neon/Supabase/…) |
| `AUTH_SECRET` | ✔ | تصادفی ≥۳۲ کاراکتر — `node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"` |
| `SITE_URL` | ✔ | دامنه‌ی نهایی، مثل `https://scorent.example.com` |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | ✔ | فقط برای ساخت اولین مدیر ارشد روی دیتابیس خالی؛ پس از اولین ورود env را حذف کن |
| `GOOGLE_SITE_VERIFICATION` | — | تأیید Search Console |
| `NEXT_PUBLIC_GA4_ID` | — | Google Analytics 4 (G-…) |
| `GOOGLE_CLIENT_ID/SECRET` | — | ورود با گوگل |
| `FRAME_GUARD=false` | — | فقط برای پیش‌نمایش داخل iframe |
