import { describe, expect, it } from "vitest";
import { countPerDay, csvField, dayLabels, toCsv } from "../src/lib/server/stats";

describe("countPerDay", () => {
  const now = new Date("2026-11-14T12:00:00Z");

  it("برمی‌گرداند N صفر وقتی هیچ رخدادی نیست", () => {
    expect(countPerDay([], 7, now)).toEqual([0, 0, 0, 0, 0, 0, 0]);
  });

  it("رخداد امروز را در آخرین سبد می‌گذارد", () => {
    const out = countPerDay(["2026-11-14T10:30:00Z"], 7, now);
    expect(out).toEqual([0, 0, 0, 0, 0, 0, 1]);
  });

  it("رخداد ۶ روز قبل را در اولین سبد می‌گذارد (۷ روزه)", () => {
    const out = countPerDay(["2026-11-08T09:00:00Z"], 7, now);
    expect(out).toEqual([1, 0, 0, 0, 0, 0, 0]);
  });

  it("رخداد خارج از بازه را نادیده می‌گیرد", () => {
    const out = countPerDay(["2026-11-01T09:00:00Z", "2027-01-01T09:00:00Z", "باطل"], 7, now);
    expect(out).toEqual([0, 0, 0, 0, 0, 0, 0]);
  });

  it("چند رخداد در یک روز جمع می‌شوند", () => {
    /* بازه‌ی ۳ روزه: [۱۳-۱۱، ۱۲-۱۱، ۱۴-۱۱] — دو رخداد ۱۳ نوامبر و یکی ۱۴ نوامبر */
    const out = countPerDay(["2026-11-13T05:00:00Z", "2026-11-13T18:00:00Z", "2026-11-14T01:00:00Z"], 3, now);
    expect(out).toEqual([0, 2, 1]);
  });

  it("شیء Date هم می‌پذیرد", () => {
    const out = countPerDay([new Date("2026-11-14T08:00:00Z")], 2, now);
    expect(out).toEqual([0, 1]);
  });

  it("روزها را محدود و معتبر می‌کند", () => {
    expect(countPerDay([], 0, now)).toHaveLength(1);
    expect(countPerDay([], 500, now)).toHaveLength(90);
  });
});

describe("dayLabels", () => {
  const now = new Date("2026-11-14T12:00:00Z");

  it("موازی با countPerDay و با فرمت MM-DD است", () => {
    const labels = dayLabels(3, now);
    expect(labels).toEqual(["11-12", "11-13", "11-14"]);
    expect(labels).toHaveLength(countPerDay([], 3, now).length);
  });
});

describe("toCsv", () => {
  it("ردیف ساده را با کاما می‌سازد", () => {
    expect(toCsv([["a", "b", 1]])).toBe("a,b,1");
  });

  it("فیلد دارای کاما/نقل‌قول/خط جدید را نقل‌قول و دوبل می‌کند", () => {
    expect(toCsv([['has,comma']])).toBe('"has,comma"');
    expect(toCsv([['say "hi"']])).toBe('"say ""hi"""');
    expect(toCsv([["line1\nline2"]])).toBe('"line1\nline2"');
  });

  it("null و undefined را خالی می‌گذارد", () => {
    expect(toCsv([[null, undefined, "x"]])).toBe(",,x");
  });

  it("چند ردیف با CRLF جدا می‌شوند", () => {
    expect(toCsv([["h1", "h2"], ["v1", "v2"]])).toBe("h1,h2\r\nv1,v2");
  });
});
