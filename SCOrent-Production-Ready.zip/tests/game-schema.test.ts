import { describe, expect, it } from "vitest";
import { autoPalette, lenientGame, MOTIFS, sanitizeGameInput, slugify, slugOk, suggestRental } from "../src/lib/game-schema";

const validInput = () => ({
  id: "test-game",
  title: "Test Game",
  developer: "Test Studio",
  year: 2024,
  tagline: "یک شعار آزمایشی برای بازی",
  description: "این توضیح آزمایشی است و از ده نویسه بیشتر دارد تا اعتبارسنجی پاس شود.",
  genres: ["اکشن", "نقش‌آفرینی"],
  playstyles: ["چالشی"],
  structure: "دنیای آزاد",
  modes: ["تک‌نفره"],
  sessionMinutes: [30, 90],
  price: 2_000_000,
  originalPrice: 2_500_000,
  rentalAvailable: true,
  rental: { d1: 250_000, d3: 625_000, d7: 1_000_000 },
  rating: 4.5,
  popularity: 70,
  highlights: ["مورد اول آزمایشی", "مورد دوم آزمایشی"],
});

describe("slugify / slugOk", () => {
  it("عنوان لاتین به اسلاگ تمیز تبدیل می‌شود", () => {
    expect(slugify("Elden Ring: Shadow")).toBe("elden-ring-shadow");
    expect(slugify("  Hades  II! ")).toBe("hades-ii");
    expect(slugify("آنالمالیا")).toBe("");
  });

  it("اسلاگ نامعتبر رد می‌شود", () => {
    expect(slugOk("ok-id")).toBe(true);
    expect(slugOk("Bad ID")).toBe(false);
    expect(slugOk("a")).toBe(false);
    expect(slugOk("سلام")).toBe(false);
  });
});

describe("autoPalette / suggestRental", () => {
  it("پالت همیشه سه رنگ هگز معتبر و پایدار است", () => {
    const a = autoPalette("elden-ring");
    const b = autoPalette("elden-ring");
    expect(a).toEqual(b);
    expect(a).toHaveLength(3);
    for (const c of a) expect(c).toMatch(/^#[0-9a-f]{6}$/);
  });

  it("پالت دو بازی متفاوت معمولاً متفاوت است", () => {
    expect(autoPalette("a-unique-id")).not.toEqual(autoPalette("another-id"));
  });

  it("نسبت‌های اجاره پیشنهادی همان الگوی دیتاست است", () => {
    const r = suggestRental(1_920_000);
    expect(r.d1).toBe(240_000);
    expect(r.d3).toBe(600_000);
    expect(r.d7).toBe(960_000);
  });
});

describe("sanitizeGameInput — خروجی معتبر", () => {
  it("ورودی کامل بدون تغییر معنایی پاس می‌شود", () => {
    const r = sanitizeGameInput(validInput());
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.game.id).toBe("test-game");
    expect(r.game.title).toBe("Test Game");
    expect(r.game.discountPercent).toBe(20); // (1 - 2M/2.5M) → 20٪
    expect(r.game.rental?.d1).toBe(250_000);
    expect(r.game.available).toBe(true);
    expect(r.game.featured).toBe(false);
    expect(r.game.highlights).toHaveLength(2);
  });

  it("فیلدهای اختیاری با پیش‌فرض پر می‌شوند", () => {
    const r = sanitizeGameInput({
      id: "minimal-game",
      title: "Minimal",
      developer: "Studio",
      tagline: "شعار کوتاه",
      description: "توضیح حداقلی کافی برای گذراندن پالایه.",
      genres: ["ماجرایی"],
      playstyles: ["داستان‌محور"],
      structure: "خطی",
      modes: ["تک‌نفره"],
      price: 1_500_000,
    });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.game.originalPrice).toBe(1_500_000);
    expect(r.game.discountPercent).toBe(0);
    expect(r.game.rentalAvailable).toBe(false);
    expect(r.game.rental).toBeNull();
    expect(r.game.campaignHours).toBeNull();
    expect(r.game.trial.kind).toBe("none");
    expect(r.game.ratingSource).toContain("ادمین");
    expect(r.game.popularity).toBe(50);
    expect(MOTIFS).toContain(r.game.motif);
  });

  it("تخفیف از رابطه‌ی قیمت‌ها استخراج و کلمپ می‌شود", () => {
    const r = sanitizeGameInput({ ...validInput(), price: 1_000_000, originalPrice: 10_000_000 });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.game.discountPercent).toBe(90); // سقف ۹۰٪
  });

  it("اگر اجاره فعال ولی خالی باشد، نرخ‌ها از قیمت پیشنهاد می‌شوند", () => {
    const r = sanitizeGameInput({ ...validInput(), rental: undefined });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.game.rental?.d1).toBe(250_000);
    expect(r.game.rental?.d7).toBe(1_000_000);
  });

  it("پالت نامعتبر با پالت خودکار جایگزین می‌شود", () => {
    const r = sanitizeGameInput({ ...validInput(), palette: ["red", "#GGGGGG", 42] });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    for (const c of r.game.palette) expect(c).toMatch(/^#[0-9a-f]{6}$/);
  });

  it("ژانر/حالت‌های نامعتبر فیلتر می‌شوند", () => {
    const r = sanitizeGameInput({ ...validInput(), genres: ["اکشن", "ژانر جعلی"], modes: ["تک‌نفره", "آنلاین جعلی"] });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.game.genres).toEqual(["اکشن"]);
    expect(r.game.modes).toEqual(["تک‌نفره"]);
  });

  it("مدت جلسه‌ی نامعتبر با پیش‌فرض جایگزین می‌شود", () => {
    const r = sanitizeGameInput({ ...validInput(), sessionMinutes: [99999, "x"] });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.game.sessionMinutes).toEqual([60, 180]);
  });
});

describe("sanitizeGameInput — رد ورودی نامعتبر", () => {
  const expectErrors = (raw: unknown, codes: string[]) => {
    const r = sanitizeGameInput(raw);
    expect(r.ok).toBe(false);
    if (r.ok) return;
    for (const c of codes) expect(r.errors).toContain(c);
  };

  it("شناسه نامعتبر", () => {
    expectErrors({ ...validInput(), id: "BAD ID" }, ["ERR_ID"]);
    expectErrors({ ...validInput(), id: "" }, ["ERR_ID"]);
  });

  it("فیلدهای اجباری خالی", () => {
    expectErrors({ ...validInput(), title: "" }, ["ERR_TITLE"]);
    expectErrors({ ...validInput(), tagline: "کم" }, ["ERR_TAGLINE"]);
    expectErrors({ ...validInput(), description: "کوتاه" }, ["ERR_DESCRIPTION"]);
    expectErrors({ ...validInput(), developer: "x" }, ["ERR_DEVELOPER"]);
    expectErrors({ ...validInput(), year: 1950 }, ["ERR_YEAR"]);
    expectErrors({ ...validInput(), genres: [] }, ["ERR_GENRES"]);
    expectErrors({ ...validInput(), playstyles: [] }, ["ERR_PLAYSTYLES"]);
    expectErrors({ ...validInput(), modes: [] }, ["ERR_MODES"]);
    expectErrors({ ...validInput(), structure: "ساختار جعلی" }, ["ERR_STRUCTURE"]);
    expectErrors({ ...validInput(), price: 500 }, ["ERR_PRICE"]);
    expectErrors({ ...validInput(), originalPrice: 1_000_000 }, ["ERR_ORIGINAL_PRICE"]);
    expectErrors({ ...validInput(), rentalAvailable: true, rental: { d1: -5, d3: 1, d7: 1 } }, ["ERR_RENTAL"]);
    expectErrors({ ...validInput(), highlights: ["a", "ok-highlight"] }, ["ERR_HIGHLIGHTS"]);
  });

  it("ورودی خالی/هیول — فقط خطا، بدون استثنا", () => {
    expect(sanitizeGameInput(null).ok).toBe(false);
    expect(sanitizeGameInput(undefined).ok).toBe(false);
    expect(sanitizeGameInput(42).ok).toBe(false);
    expect(sanitizeGameInput("game").ok).toBe(false);
  });
});

describe("lenientGame — پیش‌نمایش زنده", () => {
  it("همیشه یک Game کامل برمی‌گرداند حتی با ورودی خالی", () => {
    const g = lenientGame({});
    expect(g.id).toBe("untitled-game");
    expect(g.title).toBe("بدون عنوان");
    expect(g.price).toBeGreaterThanOrEqual(1000);
    expect(g.palette).toHaveLength(3);
    expect(g.genres).toEqual([]);
    expect(g.motif).toBeDefined();
  });

  it("همان کلمپ‌ها و پیش‌فرض‌های پالایه را اعمال می‌کند", () => {
    const g = lenientGame({ price: 5, rating: 9, popularity: 300, available: false });
    expect(g.price).toBe(1000);
    expect(g.rating).toBe(5);
    expect(g.popularity).toBe(100);
    expect(g.available).toBe(false);
  });
});
