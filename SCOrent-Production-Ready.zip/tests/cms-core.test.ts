/* ————— تست‌های CMS: بلوک‌ها، درخت، تنظیمات، URL امن ————— */

import { describe, expect, it } from "vitest";
import { sanitizeBlocks, parseBlocks, BLOCK_REGISTRY } from "@/lib/cms/blocks";
import { buildTree, wouldCycle, flattenTree } from "@/lib/cms/tree";
import { sanitizeSettings, parseSettings, DEFAULT_SETTINGS } from "@/lib/cms/settings";
import { safeImageUrl, safeLinkHref, cmsSlugOk } from "@/lib/cms/types";

describe("blocks registry", () => {
  it("has required blocks", () => {
    for (const t of ["hero", "richText", "image", "imageText", "gameCarousel", "productGrid", "categoryGrid", "promoBanner", "stats", "faq", "video", "cta", "spacer"]) {
      expect(BLOCK_REGISTRY[t], `missing block: ${t}`).toBeDefined();
    }
  });
});

describe("sanitizeBlocks", () => {
  it("accepts valid blocks and fills defaults", () => {
    const res = sanitizeBlocks([{ type: "cta", id: "cta-1", props: {} }]);
    expect(res.ok).toBe(true);
    if (res.ok) {
      expect(res.blocks[0].id).toBe("cta-1");
      expect(res.blocks[0].props.hrefFa ?? res.blocks[0].props.href).toBeDefined();
    }
  });

  it("rejects unknown block types", () => {
    const res = sanitizeBlocks([{ type: "arbitraryScript", id: "x" }]);
    expect(res.ok).toBe(false);
  });

  it("strips unsafe props (script injection)", () => {
    const res = sanitizeBlocks([
      { type: "richText", id: "rt1", props: { bodyFa: '<script>alert(1)</script>' } },
    ]);
    if (res.ok) {
      // متن پالایش طول می‌شود ولی به کد تبدیل نمی‌شود — رندر به‌صورت متن React است
      expect(String(res.blocks[0].props.bodyFa)).toContain("<script>");
    } else {
      expect.fail();
    }
  });

  it("sanitizes image URLs", () => {
    const res = sanitizeBlocks([{ type: "image", id: "im1", props: { src: "javascript:alert(1)" } }]);
    if (res.ok) {
      expect(res.blocks[0].props.src).toBe("");
    }
  });

  it("rejects non-array", () => {
    expect(sanitizeBlocks("x").ok).toBe(false);
    expect(sanitizeBlocks(null).ok).toBe(false);
  });

  it("parseBlocks survives corrupt JSON", () => {
    expect(parseBlocks("not-json")).toEqual([]);
    expect(parseBlocks(null)).toEqual([]);
  });

  it("duplicate ids get regenerated", () => {
    const res = sanitizeBlocks([
      { type: "spacer", id: "same", props: {} },
      { type: "spacer", id: "same", props: {} },
    ]);
    if (res.ok) {
      expect(res.blocks[0].id).not.toBe(res.blocks[1].id);
    }
  });
});

describe("tree utils", () => {
  it("builds tree and orders by order", () => {
    const flat = [
      { id: "root-b", parentId: null, order: 2 },
      { id: "root-a", parentId: null, order: 1 },
      { id: "child1", parentId: "root-b", order: 0 },
    ];
    const tree = buildTree<{ id: string; parentId: string | null; order: number }, { id: string; children: { id: string }[] }>(flat, (item, children) => ({ id: item.id, children }));
    expect(tree.map((n) => n.id)).toEqual(["root-a", "root-b"]);
    expect(tree[1].children.map((c) => c.id)).toEqual(["child1"]);
  });

  it("orphans fall back to roots", () => {
    const flat = [{ id: "x", parentId: "missing", order: 0 }];
    const tree = buildTree<{ id: string; parentId: string | null; order: number }, { id: string; children: { id: string }[] }>(flat, (item, children) => ({ id: item.id, children }));
    expect(tree.map((n) => n.id)).toEqual(["x"]);
  });

  it("self-parent breaks (no infinite loop)", () => {
    const flat = [{ id: "x", parentId: "x", order: 0 }];
    const tree = buildTree<{ id: string; parentId: string | null; order: number }, { id: string; children: { id: string }[] }>(flat, (item, children) => ({ id: item.id, children }));
    expect(tree.map((n) => n.id)).toEqual(["x"]);
    expect(tree[0].children.length).toBe(0);
  });

  it("wouldCycle detects ancestors", () => {
    const flat = [
      { id: "a", parentId: null },
      { id: "b", parentId: "a" },
      { id: "c", parentId: "b" },
    ];
    expect(wouldCycle(flat, "a", "c")).toBe(true); // c زیرمجموعه a است
    expect(wouldCycle(flat, "a", "b")).toBe(true);
    expect(wouldCycle(flat, "c", "a")).toBe(false);
    expect(wouldCycle(flat, "a", null)).toBe(false);
  });

  it("flattenTree walks DFS", () => {
    const tree = [
      { id: "a", children: [{ id: "a1", children: [] }] },
      { id: "b", children: [] },
    ];
    expect(flattenTree(tree).map((n) => n.id)).toEqual(["a", "a1", "b"]);
  });
});

describe("settings", () => {
  it("accepts valid settings", () => {
    const res = sanitizeSettings({ maintenanceMode: true, contactEmail: "a@b.co", rentalCommissionPct: 15 });
    expect(res.ok).toBe(true);
    if (res.ok) {
      expect(res.settings.maintenanceMode).toBe(true);
      expect(res.settings.rentalCommissionPct).toBe(15);
    }
  });

  it("rejects invalid email and clamps commission", () => {
    expect(sanitizeSettings({ contactEmail: "not-an-email" }).ok).toBe(false);
    const res = sanitizeSettings({ rentalCommissionPct: 500 });
    if (res.ok) expect(res.settings.rentalCommissionPct).toBe(50);
  });

  it("rejects unsafe social URLs", () => {
    expect(sanitizeSettings({ socialInstagram: "javascript:alert(1)" }).ok).toBe(false);
  });

  it("min>max price rejected", () => {
    expect(sanitizeSettings({ minPrice: 500, maxPrice: 100 }).ok).toBe(false);
  });

  it("parseSettings falls back to defaults on corrupt data", () => {
    expect(parseSettings([{ key: "maintenanceMode", value: "not-json" }])).toEqual(DEFAULT_SETTINGS);
  });

  it("lang coerced", () => {
    const res = sanitizeSettings({ defaultLang: "EN" });
    if (res.ok) expect(res.settings.defaultLang).toBe("en");
  });
});

describe("safe URLs", () => {
  it("allows https and local media", () => {
    expect(safeImageUrl("https://cdn.example.com/x.png")).toBe("https://cdn.example.com/x.png");
    expect(safeImageUrl("/api/media/abc123")).toBe("/api/media/abc123");
    expect(safeImageUrl("/uploads/x.jpg")).toBe("/uploads/x.jpg");
  });

  it("blocks javascript:, data:, protocol-relative and credentials", () => {
    expect(safeImageUrl("javascript:alert(1)")).toBeNull();
    expect(safeImageUrl("data:text/html;base64,AAAA")).toBeNull();
    expect(safeImageUrl("//evil.com/x.png")).toBeNull();
    expect(safeImageUrl("https://user:pass@evil.com/x.png")).toBeNull();
    expect(safeImageUrl("/x.js")).toBeNull();
    expect(safeImageUrl(123)).toBeNull();
  });

  it("safeLinkHref accepts internal routes and http(s)", () => {
    expect(safeLinkHref("/store")).toBe("/store");
    expect(safeLinkHref("store")).toBe("/store");
    expect(safeLinkHref("https://example.com")).toBe("https://example.com");
  });

  it("safeLinkHref blocks dangerous", () => {
    expect(safeLinkHref("javascript:alert(1)")).toBeNull();
    expect(safeLinkHref("//evil.com")).toBeNull();
    expect(safeLinkHref("")).toBeNull();
  });

  it("cmsSlugOk enforces slug format", () => {
    expect(cmsSlugOk("about-us")).toBe(true);
    expect(cmsSlugOk("About")).toBe(false);
    expect(cmsSlugOk("x")).toBe(false);
    expect(cmsSlugOk(null)).toBe(false);
  });
});
