/* ————— تست‌های موتور فیلتر پویا ————— */

import { describe, expect, it } from "vitest";
import { applyFilters, matchFilter, parseFilterParams, filtersToParams, sortGames, paginate, valueLabel } from "@/lib/cms/filter-engine";
import type { FilterDef } from "@/lib/cms/types";
import type { Game } from "@/lib/types";
import { finalPrice } from "@/lib/pricing";

function mkDef(partial: Partial<FilterDef> & { key: string; type: FilterDef["type"] }): FilterDef {
  return {
    id: partial.key,
    labelFa: partial.key,
    labelEn: partial.key,
    options: [],
    meta: {},
    order: 0,
    enabled: true,
    ...partial,
  };
}

function mkGame(partial: Partial<Game> & { id: string }): Game {
  return {
    title: partial.id,
    tagline: "",
    description: "",
    developer: "Dev",
    year: 2024,
    genres: [],
    playstyles: [],
    structure: "خطی",
    modes: [],
    sessionMinutes: [60, 120],
    campaignHours: null,
    rating: 4,
    ratingSource: "",
    price: 1_000_000,
    originalPrice: 1_000_000,
    discountPercent: 0,
    rental: null,
    rentalAvailable: false,
    indie: false,
    featured: false,
    popularity: 50,
    available: true,
    trial: { kind: "none", note: "" },
    palette: ["#111111", "#222222", "#333333"],
    motif: "orb",
    ...partial,
  } as Game;
}

const GAMES = [
  mkGame({ id: "a", genres: ["اکشن"], platforms: ["PC", "PS5"], price: 500_000, originalPrice: 1_000_000, discountPercent: 50, rating: 4.5, year: 2023, available: true, popularity: 80 }),
  mkGame({ id: "b", genres: ["ماجرایی"], platforms: ["PC"], price: 2_000_000, originalPrice: 2_000_000, rating: 3.9, year: 2025, available: false, popularity: 90 }),
  mkGame({ id: "c", genres: ["اکشن", "ورزشی"], platforms: ["PS5"], price: 800_000, originalPrice: 800_000, rating: 4.2, year: 2024, available: true, popularity: 70 }),
];

describe("parseFilterParams", () => {
  it("parses multiselect from comma list", () => {
    const def = mkDef({ key: "genre", type: "multiselect", meta: { field: "genres" } });
    const v = parseFilterParams([def], new URLSearchParams("genre=اکشن,ورزشی"));
    expect(v.genre).toEqual(["اکشن", "ورزشی"]);
  });

  it("parses range as min..max", () => {
    const def = mkDef({ key: "price", type: "price", meta: { field: "price" } });
    const v = parseFilterParams([def], new URLSearchParams("price=100000..800000"));
    expect(v.price).toEqual([100_000, 800_000]);
  });

  it("parses boolean as 1", () => {
    const def = mkDef({ key: "rentalAvailable", type: "boolean" });
    const v = parseFilterParams([def], new URLSearchParams("rentalAvailable=1"));
    expect(v.rentalAvailable).toBe(true);
  });

  it("ignores invalid ranges", () => {
    const def = mkDef({ key: "price", type: "price" });
    const v = parseFilterParams([def], new URLSearchParams("price=abc"));
    expect(v.price).toBeUndefined();
  });
});

describe("filtersToParams", () => {
  it("round-trips values", () => {
    const defs = [
      mkDef({ key: "genre", type: "multiselect", meta: { field: "genres" } }),
      mkDef({ key: "price", type: "price", meta: { field: "price", max: 2_500_000 } }),
      mkDef({ key: "rentalAvailable", type: "boolean" }),
    ];
    const values = { genre: ["اکشن"], price: [100_000, 800_000] as [number, number], rentalAvailable: true };
    const params = filtersToParams(defs, values);
    expect(params.genre).toBe("اکشن");
    expect(params.price).toBe("100000..800000");
    expect(params.rentalAvailable).toBe("1");
    const back = parseFilterParams(defs, new URLSearchParams(params));
    expect(back.genre).toEqual(["اکشن"]);
    expect(back.price).toEqual([100_000, 800_000]);
  });
});

describe("applyFilters", () => {
  const defs: FilterDef[] = [
    mkDef({ key: "genre", type: "multiselect", meta: { field: "genres" } }),
    mkDef({ key: "platform", type: "multiselect", meta: { field: "platforms" } }),
    mkDef({ key: "price", type: "price", meta: { field: "price" } }),
    mkDef({ key: "rating", type: "rating", meta: { field: "rating" } }),
    mkDef({ key: "rentalAvailable", type: "boolean" }),
    mkDef({ key: "year", type: "daterange", meta: { field: "year" } }),
  ];

  it("multiselect over array field (any-of)", () => {
    expect(applyFilters(GAMES, [defs[0]], { genre: ["اکشن"] }).map((g) => g.id)).toEqual(["a", "c"]);
    expect(applyFilters(GAMES, [defs[0]], { genre: ["اکشن", "ورزشی"] }).map((g) => g.id)).toEqual(["a", "c"]);
  });

  it("platforms via meta.field", () => {
    expect(applyFilters(GAMES, [defs[1]], { platform: ["PS5"] }).map((g) => g.id)).toEqual(["a", "c"]);
    expect(applyFilters(GAMES, [defs[1]], { platform: ["PC", "PS5"] }).length).toBe(3);
  });

  it("price range uses final price (with discount)", () => {
    // finalPrice(a) = 500_000
    expect(applyFilters(GAMES, [defs[2]], { price: [100_000, 600_000] }).map((g) => g.id)).toEqual(["a"]);
    expect(applyFilters(GAMES, [defs[2]], { price: [0, 2_500_000] }).length).toBe(3);
  });

  it("rating minimum", () => {
    expect(applyFilters(GAMES, [defs[3]], { rating: 4.3 }).map((g) => g.id)).toEqual(["a"]);
  });

  it("boolean requires true", () => {
    const only = applyFilters(GAMES, [defs[4]], { rentalAvailable: false });
    expect(only.length).toBe(3); // false = بدون فیلتر
    expect(applyFilters(GAMES, [defs[4]], { rentalAvailable: true }).length).toBe(0);
  });

  it("date range on year", () => {
    expect(applyFilters(GAMES, [defs[5]], { year: [2025, 2026] }).map((g) => g.id)).toEqual(["b"]);
  });

  it("combines with AND", () => {
    const out = applyFilters(GAMES, defs.slice(0, 2), { genre: ["اکشن"], platform: ["PC"] });
    expect(out.map((g) => g.id)).toEqual(["a"]);
  });

  it("text search on developer/title", () => {
    const def = mkDef({ key: "dev", type: "text", meta: { field: "developer" } });
    expect(applyFilters(GAMES, [def], { dev: "dev" }).length).toBe(3);
  });
});

describe("matchFilter edge cases", () => {
  it("null/undefined value = no filtering", () => {
    const def = mkDef({ key: "genre", type: "multiselect", meta: { field: "genres" } });
    expect(matchFilter(GAMES[0], def, null)).toBe(true);
    expect(matchFilter(GAMES[0], def, [])).toBe(true);
  });
});

describe("sortGames", () => {
  it("popular desc", () => {
    expect(sortGames(GAMES, "popular").map((g) => g.id)).toEqual(["b", "a", "c"]);
  });
  it("price asc uses final price", () => {
    expect(sortGames(GAMES, "price-asc").map((g) => g.id)[0]).toBe("a");
  });
  it("newest by year", () => {
    expect(sortGames(GAMES, "newest").map((g) => g.id)[0]).toBe("b");
  });
});

describe("paginate", () => {
  it("basic pagination", () => {
    const p = paginate([1, 2, 3, 4, 5], 2, 2);
    expect(p.items).toEqual([3, 4]);
    expect(p.pages).toBe(3);
    expect(p.page).toBe(2);
  });
  it("clamps page", () => {
    expect(paginate([1], 99, 2).page).toBe(1);
  });
});

describe("valueLabel", () => {
  it("labels multiselect values", () => {
    const def = mkDef({ key: "genre", type: "multiselect", options: [{ value: "اکشن", labelFa: "اکشن", labelEn: "Action" }] });
    expect(valueLabel(def, ["اکشن"], "en")).toBe("Action");
    expect(valueLabel(def, ["اکشن"], "fa")).toBe("اکشن");
  });
  it("labels ranges", () => {
    const def = mkDef({ key: "price", type: "price" });
    expect(valueLabel(def, [100, 200], "en")).toBe("100 – 200");
  });
});

describe("finalPrice consistency", () => {
  it("discount applied once", () => {
    expect(finalPrice(GAMES[0])).toBe(500_000);
  });
});
