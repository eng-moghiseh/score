import { NextRequest, NextResponse } from "next/server";

/* ————— SEO bridge برای روتر hash —————
 * سایت SPA مبتنی بر hash است (تاریخچه: محیط پیش‌نمایش فقط «/» را سرو می‌کرد).
 * برای اینکه صفحات عمومی با URL واقعی و قابل ایندکس سرو شوند، مسیرهای عمومی
 * به «/» با ‎_route بازنویسی می‌شوند؛ page.tsx با generateMetadata متادیتای
 * همان نما را سمت سرور می‌سازد و اسکریپت بوت، ‎_route را به hash تبدیل می‌کند.
 * مسیرهای خصوصی (admin/profile/settings/auth/…) و API عمداً بازنویسی نمی‌شوند.
 */

const PUBLIC_EXACT = new Set(["/store", "/rent", "/ai", "/ai-chat", "/discovery", "/deals", "/trial", "/rewards", "/share", "/support"]);
const PUBLIC_PREFIXES = ["/game/", "/p/"];

export function middleware(req: NextRequest) {
  const { pathname, search } = req.nextUrl;
  const isPublic = PUBLIC_EXACT.has(pathname) || PUBLIC_PREFIXES.some((p) => pathname.startsWith(p));
  if (!isPublic) return NextResponse.next();

  const url = req.nextUrl.clone();
  url.pathname = "/";
  url.searchParams.set("_route", pathname + search);
  return NextResponse.rewrite(url);
}

export const config = {
  matcher: ["/((?!api|_next|sitemap.xml|robots.txt|.*\\.).*)"],
};
