import { AppShell } from "@/components/scorent/app-shell";
import { ROUTE_BOOT_SCRIPT, routeJsonLd, routeMetadata } from "@/lib/seo";
import type { Metadata } from "next";

/* ————— پوسته‌ی SPA + لایه SEO —————
 * در حالت عادی متادیتای ریشه سرو می‌شود؛ اگر درخواست با ‎_route آمده باشد
 * (بازنویسی middleware برای مسیرهای عمومی مثل /game/:id)، متادیتا و
 * Structured Data همان نما سمت سرور تولید می‌شود. اسکریپت بوت ‎_route را
 * قبل از hydration به hash تبدیل می‌کند تا روتر موجود بدون تغییر کار کند.
 */

export async function generateMetadata({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }): Promise<Metadata> {
  const sp = await searchParams;
  return routeMetadata(sp._route);
}

export default async function Page({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const ld = await routeJsonLd(sp._route);
  return (
    <>
      {ld ? <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} /> : null}
      <script dangerouslySetInnerHTML={{ __html: ROUTE_BOOT_SCRIPT }} />
      <AppShell />
    </>
  );
}
