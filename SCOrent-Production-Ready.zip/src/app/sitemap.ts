/* sitemap.xml — نقشه سایت با URLهای واقعی و قابل ایندکس
 * مسیرهای عمومی SPA از طریق middleware (‎_route) به نمای واقعی نگاشت می‌شوند،
 * پس URLهای اینجا دقیقاً همان چیزهایی هستند که گوگل می‌تواند ایندکس کند.
 * بازی‌ها فقط اگر وضعیت عمومی داشته باشند (PUBLISHED/غیرحذف/خارج از زمان‌بندی) می‌آیند.
 */

import type { MetadataRoute } from "next";
import { db } from "@/lib/db";
import { isPubliclyVisible, listAllRecords } from "@/lib/server/catalog-store";
import { SITE_BASE } from "@/lib/seo";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const statics: MetadataRoute.Sitemap = [
    "",
    "/store",
    "/rent",
    "/ai",
    "/ai-chat",
    "/discovery",
    "/deals",
    "/trial",
    "/rewards",
    "/share",
    "/support",
  ].map((p) => ({ url: `${SITE_BASE}${p}`, lastModified: new Date(), changeFrequency: p === "" ? "daily" : "weekly", priority: p === "" ? 1 : 0.7 }));

  const extras: MetadataRoute.Sitemap = [];
  try {
    // بازی‌های عمومی — فقط وضعیت منتشرشده و قابل مشاهده
    const records = await listAllRecords();
    for (const v of records) {
      if (!isPubliclyVisible(v)) continue;
      extras.push({ url: `${SITE_BASE}/game/${v.id}`, lastModified: new Date(v.updatedAt), changeFrequency: "weekly", priority: 0.8 });
    }
    // صفحات CMS منتشرشده
    const pages = await db.page.findMany({ where: { status: "PUBLISHED" }, select: { slug: true, updatedAt: true } });
    for (const p of pages) {
      extras.push({ url: `${SITE_BASE}/p/${p.slug}`, lastModified: p.updatedAt, changeFrequency: "monthly", priority: 0.6 });
    }
  } catch {
    // بدون دیتابیس: حداقل مسیرهای ایستا سرو می‌شوند
  }
  return [...statics, ...extras];
}
