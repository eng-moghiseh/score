/* GET /api/filters — تعریف فیلترهای فعال فروشگاه (پویا از DB) */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import type { FilterOption } from "@/lib/cms/types";

export async function GET() {
  try {
    const rows = await db.filterDefinition.findMany({ where: { enabled: true }, orderBy: [{ order: "asc" }, { createdAt: "asc" }] });
    const filters = rows.map((r) => {
      let options: FilterOption[] = [];
      let meta: Record<string, unknown> = {};
      try {
        options = JSON.parse(r.options) as FilterOption[];
      } catch { /* ignore */ }
      try {
        meta = JSON.parse(r.meta) as Record<string, unknown>;
      } catch { /* ignore */ }
      return { id: r.id, key: r.key, labelFa: r.labelFa, labelEn: r.labelEn, type: r.type, options, meta, order: r.order };
    });
    const res = NextResponse.json({ ok: true, filters });
    res.headers.set("Cache-Control", "public, max-age=60, stale-while-revalidate=300");
    return res;
  } catch {
    const res = NextResponse.json({ ok: true, filters: [] });
    res.headers.set("Cache-Control", "no-store");
    return res;
  }
}
