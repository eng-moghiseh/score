/* GET /api/media/:id — سرو تصویر رسانه از DB (سازگار با serverless) */

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  if (!/^[a-z0-9]+$/i.test(id)) return new NextResponse("Bad id", { status: 400 });
  try {
    const row = await db.media.findUnique({ where: { id } });
    if (!row) return new NextResponse("Not found", { status: 404 });
    const buf = Buffer.from(row.data, "base64");
    return new NextResponse(new Uint8Array(buf), {
      status: 200,
      headers: {
        "Content-Type": row.mime,
        "Content-Length": String(buf.length),
        "Cache-Control": "public, max-age=86400, immutable",
      },
    });
  } catch {
    return new NextResponse("Server error", { status: 500 });
  }
}
