/* GET /api/navigation — منوهای فعال عمومی به تفکیک محل */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { buildTree, navToNode } from "@/lib/cms/tree";
import type { NavNode } from "@/lib/cms/types";

export async function GET() {
  try {
    const rows = await db.navigationItem.findMany({ where: { enabled: true }, orderBy: [{ order: "asc" }, { createdAt: "asc" }] });
    const byLocation: Record<string, unknown> = {};
    for (const loc of ["header", "mobile", "footer", "custom"]) {
      byLocation[loc] = buildTree<(typeof rows)[number], NavNode>(
        rows.filter((r) => r.location === loc),
        (n, children) => ({ ...navToNode(n), children })
      );
    }
    const res = NextResponse.json({ ok: true, byLocation });
    res.headers.set("Cache-Control", "public, max-age=60, stale-while-revalidate=300");
    return res;
  } catch {
    const res = NextResponse.json({ ok: true, byLocation: {} });
    res.headers.set("Cache-Control", "no-store");
    return res;
  }
}
