/* GET /api/catalog — کاتالوگ عمومی از DB (GameRecord) با fallback دیتاست ثابت
 * پاسخ کش‌شدنی است؛ پس از ذخیره‌ی ادمین با refreshCatalog (?v=) شکسته می‌شود.
 */

import { NextRequest, NextResponse } from "next/server";
import { ensureCatalogSeed, safePublicCatalog } from "@/lib/server/catalog-store";
import { ensureSeed } from "@/lib/server/seed";

export async function GET(_req: NextRequest) {
  try {
    // Bootstrap کامل استقرار تازه: ادمین از env + محتوای پیش‌فرض + کاتالوگ — idempotent
    await ensureSeed();
    await ensureCatalogSeed();
    const games = await safePublicCatalog();
    const res = NextResponse.json({ ok: true, games, source: "db" });
    res.headers.set("Cache-Control", "public, max-age=30, stale-while-revalidate=120");
    return res;
  } catch (e) {
    console.error("[catalog]", e instanceof Error ? e.message : e);
    const { GAMES } = await import("@/lib/data/games");
    const res = NextResponse.json({ ok: true, games: GAMES, source: "static-fallback" });
    res.headers.set("Cache-Control", "no-store");
    return res;
  }
}
