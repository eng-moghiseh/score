/* GET /api/overrides — اورراید بازی‌ها + بازی‌های سفارشی ادمین (عمومی)
 * کلاینت اورراید را روی دیتاست اعمال و بازی‌های سفارشی را به انتهای کاتالوگ اضافه می‌کند.
 * ?v= — پارامتر کاسباست برای refreshCatalog پس از ویرایش ادمین.
 */

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isGameShape } from "@/lib/game-schema";

export async function GET(_req: NextRequest) {
  try {
    const [rows, customRows] = await Promise.all([db.gameOverride.findMany(), db.customGame.findMany({ orderBy: { createdAt: "asc" } })]);
    const overrides = Object.fromEntries(rows.map((r) => [r.gameId, JSON.parse(r.data) as Record<string, unknown>]));
    const customGames = customRows
      .map((r) => {
        try {
          const g = JSON.parse(r.data) as unknown;
          return isGameShape(g) ? g : null;
        } catch {
          return null;
        }
      })
      .filter((g): g is NonNullable<typeof g> => g !== null);
    const res = NextResponse.json({ ok: true, overrides, customGames });
    res.headers.set("Cache-Control", "public, max-age=30, stale-while-revalidate=120");
    return res;
  } catch {
    const res = NextResponse.json({ ok: true, overrides: {}, customGames: [] });
    res.headers.set("Cache-Control", "no-store");
    return res;
  }
}
