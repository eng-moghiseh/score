/* GET /api/pages/:slug — صفحه‌ی منتشرشده‌ی صفحه‌ساز (عمومی) */

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { parseBlocks } from "@/lib/cms/blocks";

export async function GET(_req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  const { slug } = await ctx.params;
  try {
    const page = await db.page.findUnique({ where: { slug } });
    if (!page || page.status !== "PUBLISHED") {
      return NextResponse.json({ ok: false, error: "PAGE_NOT_FOUND" }, { status: 404 });
    }
    const res = NextResponse.json({
      ok: true,
      page: {
        slug: page.slug,
        titleFa: page.titleFa,
        titleEn: page.titleEn,
        blocks: parseBlocks(page.blocks),
        updatedAt: page.updatedAt.toISOString(),
      },
    });
    res.headers.set("Cache-Control", "public, max-age=30, stale-while-revalidate=120");
    return res;
  } catch {
    return NextResponse.json({ ok: false, error: "PAGE_NOT_FOUND" }, { status: 404 });
  }
}
