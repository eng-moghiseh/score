/* GET /api/settings — تنظیمات عمومی سایت (بدون هیچ داده‌ی حساس) */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_SETTINGS, parseSettings } from "@/lib/cms/settings";

export async function GET() {
  try {
    const rows = await db.siteSetting.findMany();
    const settings = parseSettings(rows);
    const res = NextResponse.json({ ok: true, settings });
    res.headers.set("Cache-Control", "public, max-age=60, stale-while-revalidate=300");
    return res;
  } catch {
    const res = NextResponse.json({ ok: true, settings: DEFAULT_SETTINGS });
    res.headers.set("Cache-Control", "no-store");
    return res;
  }
}
