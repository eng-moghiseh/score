/* /api/admin/cms/[...path] — نقاط پایانی CMS (رده‌ها، فیلترها، ناوبری، صفحه‌ساز، رسانه، تنظیمات)
 *
 * GET    categories | filters | nav | pages | pages/:id | pages/:id/revisions | media | settings
 * POST   categories | filters | nav | pages | media/upload | pages/:id/publish | pages/:id/unpublish | pages/:id/revert
 * POST   categories/reorder | filters/reorder | nav/reorder
 * PATCH  categories/:id | filters/:id | nav/:id | pages/:id | media/:id | settings
 * DELETE categories/:id | filters/:id | nav/:id | pages/:id | media/:id
 *
 * همه‌ی مسیرها با مجوز «cms» گارد می‌شوند و هر تغییر در لاگ حسابرسی ثبت می‌شود.
 */

import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { badRequest, cleanText, json, notFound, readJson, sameOrigin } from "@/lib/server/http";
import { isGuardError, requirePerm } from "@/lib/server/guard";
import { clientIp, rateLimit } from "@/lib/server/rate-limit";
import { audit } from "@/lib/server/audit";
import { sanitizeBlocks, parseBlocks } from "@/lib/cms/blocks";
import { sanitizeSettings, SETTING_KEYS } from "@/lib/cms/settings";
import type { SiteSettings } from "@/lib/cms/settings";
import { buildTree, categoryToNode, navToNode, wouldCycle } from "@/lib/cms/tree";
import { cmsSlugOk, safeImageUrl, safeLinkHref, FILTER_TYPES } from "@/lib/cms/types";
import type { CategoryNode, FilterOption, FilterType, NavNode } from "@/lib/cms/types";

type Ctx = { params: Promise<{ path: string[] }> };

const err = (e: unknown) => {
  console.error("[cms-api]", e);
  return json({ ok: false, error: "SERVER_ERROR" }, 500);
};

const okInt = (v: unknown, lo: number, hi: number) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.max(lo, Math.min(hi, Math.round(n))) : null;
};

function parseFilterOptions(raw: unknown): { ok: boolean; options: FilterOption[] } {
  if (!Array.isArray(raw)) return { ok: false, options: [] };
  const out: FilterOption[] = [];
  for (const item of raw.slice(0, 60)) {
    if (typeof item !== "object" || item === null) continue;
    const o = item as Record<string, unknown>;
    const value = typeof o.value === "string" ? o.value.trim().slice(0, 120) : "";
    if (!value) continue;
    out.push({
      value,
      labelFa: typeof o.labelFa === "string" ? o.labelFa.trim().slice(0, 120) : value,
      labelEn: typeof o.labelEn === "string" ? o.labelEn.trim().slice(0, 120) : undefined,
    });
  }
  return { ok: true, options: out };
}

function parseFilterMeta(raw: unknown): Record<string, unknown> {
  if (typeof raw !== "object" || raw === null) return {};
  const r = raw as Record<string, unknown>;
  const meta: Record<string, unknown> = {};
  if (typeof r.field === "string" && /^[a-zA-Z][a-zA-Z0-9]{0,40}$/.test(r.field)) meta.field = r.field;
  for (const k of ["min", "max", "step"] as const) {
    const n = okInt(r[k], -1_000_000_000, 1_000_000_000);
    if (n !== null) meta[k] = n;
  }
  if (typeof r.unitFa === "string") meta.unitFa = r.unitFa.slice(0, 20);
  if (typeof r.unitEn === "string") meta.unitEn = r.unitEn.slice(0, 20);
  if (Array.isArray(r.categories)) meta.categories = r.categories.filter((x): x is string => cmsSlugOk(x)).slice(0, 20);
  return meta;
}

/* ————————————————— GET ————————————————— */

export async function GET(req: NextRequest, ctx: Ctx) {
  try {
    const { path } = await ctx.params;
    const [head, id, action] = path;

    if (head === "categories") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const rows = await db.category.findMany({ orderBy: [{ order: "asc" }, { createdAt: "asc" }] });
      const tree = buildTree<(typeof rows)[number], CategoryNode>(rows, (c, children) => ({ ...categoryToNode(c), children }));
      return json({ ok: true, tree, flat: rows.map(categoryToNode) });
    }

    if (head === "filters") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const rows = await db.filterDefinition.findMany({ orderBy: [{ order: "asc" }, { createdAt: "asc" }] });
      return json({
        ok: true,
        filters: rows.map((r) => ({
          id: r.id,
          key: r.key,
          labelFa: r.labelFa,
          labelEn: r.labelEn,
          type: r.type,
          options: parseFilterOptions(JSON.parse(r.options)).options,
          meta: parseFilterMeta(JSON.parse(r.meta)),
          order: r.order,
          enabled: r.enabled,
        })),
      });
    }

    if (head === "nav") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const rows = await db.navigationItem.findMany({ orderBy: [{ order: "asc" }, { createdAt: "asc" }] });
      const byLoc: Record<string, ReturnType<typeof buildTree>> = {};
      for (const loc of ["header", "mobile", "footer", "custom"]) {
        byLoc[loc] = buildTree<(typeof rows)[number], NavNode>(
          rows.filter((r) => r.location === loc),
          (n, children) => ({ ...navToNode(n), children })
        );
      }
      return json({ ok: true, byLocation: byLoc, flat: rows.map(navToNode) });
    }

    if (head === "pages" && !id) {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const rows = await db.page.findMany({ orderBy: { updatedAt: "desc" }, select: { id: true, slug: true, titleFa: true, titleEn: true, status: true, publishedAt: true, updatedAt: true, createdAt: true } });
      return json({ ok: true, pages: rows });
    }

    if (head === "pages" && id && action === "revisions") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const page = await db.page.findUnique({ where: { id } });
      if (!page) return notFound("PAGE_NOT_FOUND");
      const revisions = await db.pageRevision.findMany({ where: { pageId: id }, orderBy: { createdAt: "desc" }, take: 30, select: { id: true, titleFa: true, titleEn: true, note: true, createdBy: true, createdAt: true } });
      return json({ ok: true, revisions, blocks: parseBlocks(page.blocks), status: page.status });
    }

    if (head === "pages" && id) {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const page = await db.page.findUnique({ where: { id } });
      if (!page) return notFound("PAGE_NOT_FOUND");
      return json({ ok: true, page: { ...page, blocks: parseBlocks(page.blocks) } });
    }

    if (head === "media") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const url = new URL(req.url);
      const q = url.searchParams.get("q")?.trim().toLowerCase() ?? "";
      const page = Math.max(1, Number(url.searchParams.get("page") ?? "1") || 1);
      const pageSize = 30;
      const where = q ? { name: { contains: q } } : {};
      const [items, total] = await Promise.all([
        db.media.findMany({ where, orderBy: { createdAt: "desc" }, skip: (page - 1) * pageSize, take: pageSize, select: { id: true, name: true, mime: true, size: true, altFa: true, altEn: true, meta: true, createdAt: true, updatedAt: true } }),
        db.media.count({ where }),
      ]);
      return json({
        ok: true,
        media: items.map((m) => ({ ...m, url: `/api/media/${m.id}` })),
        total,
        page,
        pageSize,
        storage: process.env.CLOUDINARY_URL || (process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_API_KEY) ? "cloudinary" : "database",
      });
    }

    if (head === "settings") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const rows = await db.siteSetting.findMany();
      const values: Record<string, unknown> = {};
      for (const r of rows) {
        if (!SETTING_KEYS.includes(r.key as keyof SiteSettings)) continue;
        try {
          values[r.key] = JSON.parse(r.value);
        } catch {
          values[r.key] = r.value;
        }
      }
      return json({ ok: true, values, keys: SETTING_KEYS });
    }

    return notFound("UNKNOWN_PATH");
  } catch (e) {
    return err(e);
  }
}

/* ————————————————— POST ————————————————— */

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
    const { path } = await ctx.params;
    const [head, id, action] = path;

    if (head === "categories") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      if (!(await rateLimit(`cms:${clientIp(req)}`, 60, 60_000))) return json({ ok: false, error: "RATE_LIMITED" }, 429);
      const body = await readJson<{ slug?: string; nameFa?: string; nameEn?: string; descFa?: string; descEn?: string; icon?: string; image?: string; seoFa?: string; seoEn?: string; parentId?: string | null; order?: number; enabled?: boolean }>(req);
      const slug = typeof body?.slug === "string" ? body.slug.trim().toLowerCase() : "";
      const nameFa = cleanText(body?.nameFa, 2, 80);
      if (!cmsSlugOk(slug) || !nameFa) return json({ ok: false, error: "INVALID_INPUT" }, 400);
      const nameEn = cleanText(body?.nameEn, 2, 80) ?? nameFa;
      if (body?.parentId) {
        const parent = await db.category.findUnique({ where: { id: body.parentId } });
        if (!parent) return json({ ok: false, error: "PARENT_NOT_FOUND" }, 400);
      }
      const clash = await db.category.findUnique({ where: { slug } });
      if (clash) return json({ ok: false, error: "SLUG_TAKEN" }, 409);
      const image = body?.image ? safeImageUrl(body.image) : null;
      if (body?.image && !image) return json({ ok: false, error: "INVALID_IMAGE_URL" }, 400);
      const row = await db.category.create({
        data: {
          slug,
          nameFa,
          nameEn,
          descFa: cleanText(body?.descFa, 0, 400) ?? null,
          descEn: cleanText(body?.descEn, 0, 400) ?? null,
          icon: typeof body?.icon === "string" ? body.icon.slice(0, 40) : null,
          image,
          seoFa: cleanText(body?.seoFa, 0, 160) ?? null,
          seoEn: cleanText(body?.seoEn, 0, 160) ?? null,
          parentId: body?.parentId ?? null,
          order: okInt(body?.order, 0, 10000) ?? 0,
          enabled: body?.enabled !== false,
          createdBy: guard.user.id,
          updatedBy: guard.user.id,
        },
      });
      audit("CATEGORY_CREATED", { actorId: guard.user.id, target: slug, ip: clientIp(req) });
      return json({ ok: true, category: categoryToNode(row) });
    }

    if (head === "filters") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      if (!(await rateLimit(`cms:${clientIp(req)}`, 60, 60_000))) return json({ ok: false, error: "RATE_LIMITED" }, 429);
      const body = await readJson<{ key?: string; labelFa?: string; labelEn?: string; type?: string; options?: unknown; meta?: unknown; order?: number; enabled?: boolean }>(req);
      const key = typeof body?.key === "string" ? body.key.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 40) : "";
      const labelFa = cleanText(body?.labelFa, 2, 80);
      if (!key || !labelFa) return json({ ok: false, error: "INVALID_INPUT" }, 400);
      const type = String(body?.type ?? "");
      if (!FILTER_TYPES.includes(type as FilterType)) return json({ ok: false, error: "INVALID_TYPE" }, 400);
      const opts = parseFilterOptions(body?.options);
      if (["select", "multiselect"].includes(type) && opts.options.length === 0) return json({ ok: false, error: "OPTIONS_REQUIRED" }, 400);
      const meta = parseFilterMeta(body?.meta);
      const clash = await db.filterDefinition.findUnique({ where: { key } });
      if (clash) return json({ ok: false, error: "KEY_TAKEN" }, 409);
      const row = await db.filterDefinition.create({
        data: {
          key,
          labelFa,
          labelEn: cleanText(body?.labelEn, 2, 80) ?? labelFa,
          type,
          options: JSON.stringify(opts.options),
          meta: JSON.stringify(meta),
          order: okInt(body?.order, 0, 1000) ?? 0,
          enabled: body?.enabled !== false,
          createdBy: guard.user.id,
          updatedBy: guard.user.id,
        },
      });
      audit("FILTER_CREATED", { actorId: guard.user.id, target: key, meta: type, ip: clientIp(req) });
      return json({ ok: true, filter: { ...row, options: opts.options, meta } });
    }

    if (head === "filters" && id === "reorder") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const body = await readJson<{ order?: string[] }>(req);
      const order = Array.isArray(body?.order) ? body!.order!.filter((x) => typeof x === "string").slice(0, 100) : [];
      for (let i = 0; i < order.length; i++) {
        await db.filterDefinition.update({ where: { id: order[i] }, data: { order: i } }).catch(() => undefined);
      }
      audit("FILTER_REORDERED", { actorId: guard.user.id, target: `${order.length} items`, ip: clientIp(req) });
      return json({ ok: true });
    }

    if (head === "categories" && id === "reorder") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const body = await readJson<{ order?: string[] }>(req);
      const order = Array.isArray(body?.order) ? body!.order!.filter((x) => typeof x === "string").slice(0, 200) : [];
      for (let i = 0; i < order.length; i++) {
        await db.category.update({ where: { id: order[i] }, data: { order: i } }).catch(() => undefined);
      }
      audit("CATEGORY_REORDERED", { actorId: guard.user.id, target: `${order.length} items`, ip: clientIp(req) });
      return json({ ok: true });
    }

    if (head === "nav") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      if (!(await rateLimit(`cms:${clientIp(req)}`, 60, 60_000))) return json({ ok: false, error: "RATE_LIMITED" }, 429);
      const body = await readJson<{ location?: string; parentId?: string | null; labelFa?: string; labelEn?: string; href?: string; icon?: string; descFa?: string; descEn?: string; order?: number; enabled?: boolean; newTab?: boolean }>(req);
      const location = ["header", "mobile", "footer", "custom"].includes(body?.location ?? "") ? body!.location! : "";
      const labelFa = cleanText(body?.labelFa, 1, 60);
      const href = safeLinkHref(body?.href);
      if (!location || !labelFa || !href) return json({ ok: false, error: "INVALID_INPUT" }, 400);
      if (body?.parentId) {
        const parent = await db.navigationItem.findUnique({ where: { id: body.parentId } });
        if (!parent) return json({ ok: false, error: "PARENT_NOT_FOUND" }, 400);
        if (parent.location !== location) return json({ ok: false, error: "LOCATION_MISMATCH" }, 400);
      }
      const row = await db.navigationItem.create({
        data: {
          location,
          parentId: body?.parentId ?? null,
          labelFa,
          labelEn: cleanText(body?.labelEn, 1, 60) ?? labelFa,
          href,
          icon: typeof body?.icon === "string" ? body.icon.slice(0, 40) : null,
          descFa: cleanText(body?.descFa, 0, 200) ?? null,
          descEn: cleanText(body?.descEn, 0, 200) ?? null,
          order: okInt(body?.order, 0, 10000) ?? 0,
          enabled: body?.enabled !== false,
          newTab: body?.newTab === true,
          createdBy: guard.user.id,
          updatedBy: guard.user.id,
        },
      });
      audit("NAV_CREATED", { actorId: guard.user.id, target: `${location}:${labelFa}`, ip: clientIp(req) });
      return json({ ok: true, item: navToNode(row) });
    }

    if (head === "nav" && id === "reorder") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const body = await readJson<{ order?: string[] }>(req);
      const order = Array.isArray(body?.order) ? body!.order!.filter((x) => typeof x === "string").slice(0, 200) : [];
      for (let i = 0; i < order.length; i++) {
        await db.navigationItem.update({ where: { id: order[i] }, data: { order: i } }).catch(() => undefined);
      }
      audit("NAV_REORDERED", { actorId: guard.user.id, target: `${order.length} items`, ip: clientIp(req) });
      return json({ ok: true });
    }

    if (head === "pages" && id && action === "publish") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const page = await db.page.findUnique({ where: { id } });
      if (!page) return notFound("PAGE_NOT_FOUND");
      await db.pageRevision.create({
        data: { pageId: id, titleFa: page.titleFa, titleEn: page.titleEn, blocks: page.blocks, note: "before publish", createdBy: guard.user.id },
      });
      const updated = await db.page.update({ where: { id }, data: { status: "PUBLISHED", publishedAt: new Date(), updatedBy: guard.user.id } });
      audit("PAGE_PUBLISHED", { actorId: guard.user.id, target: page.slug, ip: clientIp(req) });
      return json({ ok: true, page: { ...updated, blocks: parseBlocks(updated.blocks) } });
    }

    if (head === "pages" && id && action === "unpublish") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const page = await db.page.findUnique({ where: { id } });
      if (!page) return notFound("PAGE_NOT_FOUND");
      const updated = await db.page.update({ where: { id }, data: { status: "DRAFT", updatedBy: guard.user.id } });
      audit("PAGE_UNPUBLISHED", { actorId: guard.user.id, target: page.slug, ip: clientIp(req) });
      return json({ ok: true, page: { ...updated, blocks: parseBlocks(updated.blocks) } });
    }

    if (head === "pages" && id && action === "revert") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const body = await readJson<{ revisionId?: string }>(req);
      const revision = await db.pageRevision.findUnique({ where: { id: String(body?.revisionId ?? "") } });
      if (!revision || revision.pageId !== id) return notFound("REVISION_NOT_FOUND");
      const updated = await db.page.update({ where: { id }, data: { titleFa: revision.titleFa, titleEn: revision.titleEn, blocks: revision.blocks, updatedBy: guard.user.id } });
      audit("PAGE_REVERTED", { actorId: guard.user.id, target: `${id}@${revision.id}`, ip: clientIp(req) });
      return json({ ok: true, page: { ...updated, blocks: parseBlocks(updated.blocks) } });
    }

    if (head === "pages") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      if (!(await rateLimit(`cms:${clientIp(req)}`, 60, 60_000))) return json({ ok: false, error: "RATE_LIMITED" }, 429);
      const body = await readJson<{ slug?: string; titleFa?: string; titleEn?: string; blocks?: unknown }>(req);
      const slug = typeof body?.slug === "string" ? body.slug.trim().toLowerCase() : "";
      const titleFa = cleanText(body?.titleFa, 2, 120);
      if (!cmsSlugOk(slug) || !titleFa) return json({ ok: false, error: "INVALID_INPUT" }, 400);
      const blocks = sanitizeBlocks(body?.blocks ?? []);
      if (!blocks.ok) return json({ ok: false, error: "INVALID_BLOCKS", errors: blocks.errors }, 400);
      const clash = await db.page.findUnique({ where: { slug } });
      if (clash) return json({ ok: false, error: "SLUG_TAKEN" }, 409);
      const row = await db.page.create({
        data: {
          slug,
          titleFa,
          titleEn: cleanText(body?.titleEn, 2, 120) ?? titleFa,
          blocks: JSON.stringify(blocks.blocks),
          createdBy: guard.user.id,
          updatedBy: guard.user.id,
        },
      });
      audit("PAGE_CREATED", { actorId: guard.user.id, target: slug, ip: clientIp(req) });
      return json({ ok: true, page: { ...row, blocks: blocks.blocks } });
    }

    if (head === "media" && id === "upload") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      if (!(await rateLimit(`media-upload:${clientIp(req)}`, 20, 60_000))) return json({ ok: false, error: "RATE_LIMITED" }, 429);
      const MAX_BYTES = 1_500_000;
      let name = "file";
      let mime = "application/octet-stream";
      let dataB64 = "";
      try {
        const form = await req.formData();
        const file = form.get("file");
        if (file && typeof file === "object" && "arrayBuffer" in file) {
          name = String(form.get("name") || file.name || "file").slice(0, 120);
          mime = file.type || "application/octet-stream";
          const buf = Buffer.from(await file.arrayBuffer());
          if (buf.length > MAX_BYTES) return json({ ok: false, error: "FILE_TOO_LARGE" }, 413);
          dataB64 = buf.toString("base64");
        } else {
          const body = await readJson<{ name?: string; mime?: string; data?: string }>(req);
          name = String(body?.name ?? "file").slice(0, 120);
          mime = String(body?.mime ?? mime).slice(0, 100);
          dataB64 = String(body?.data ?? "");
        }
      } catch {
        return json({ ok: false, error: "INVALID_UPLOAD" }, 400);
      }
      if (!/^(image\/(png|jpeg|webp|gif|avif))$/.test(mime)) return json({ ok: false, error: "UNSUPPORTED_TYPE" }, 415);
      if (!dataB64) return json({ ok: false, error: "EMPTY_FILE" }, 400);
      const buf = Buffer.from(dataB64, "base64");
      if (!buf.length || buf.length > MAX_BYTES) return json({ ok: false, error: "FILE_TOO_LARGE" }, 413);
      const row = await db.media.create({
        data: { name, mime, size: buf.length, data: dataB64, uploadedBy: guard.user.id, updatedAt: new Date() },
      });
      audit("MEDIA_UPLOADED", { actorId: guard.user.id, target: name, meta: `${mime} ${buf.length}B`, ip: clientIp(req) });
      return json({ ok: true, media: { id: row.id, name: row.name, url: `/api/media/${row.id}`, mime, size: buf.length } });
    }

    return notFound("UNKNOWN_PATH");
  } catch (e) {
    return err(e);
  }
}

/* ————————————————— PATCH ————————————————— */

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
    const { path } = await ctx.params;
    const [head, id] = path;

    if (head === "categories" && id) {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const row = await db.category.findUnique({ where: { id } });
      if (!row) return notFound("CATEGORY_NOT_FOUND");
      const body = await readJson<{ nameFa?: string; nameEn?: string; descFa?: string; descEn?: string; icon?: string; image?: string; seoFa?: string; seoEn?: string; parentId?: string | null; order?: number; enabled?: boolean }>(req);
      const data: Record<string, unknown> = { updatedBy: guard.user.id };
      const nameFa = body?.nameFa !== undefined ? cleanText(body.nameFa, 2, 80) : undefined;
      if (nameFa) data.nameFa = nameFa;
      if (body?.nameEn !== undefined) data.nameEn = cleanText(body.nameEn, 2, 80) ?? String(data.nameFa ?? row.nameFa);
      for (const k of ["descFa", "descEn", "seoFa", "seoEn"] as const) {
        if (body?.[k] !== undefined) data[k] = cleanText((body[k] ?? "") as string, 0, 400) ?? "";
      }
      if (body?.icon !== undefined) data.icon = typeof body.icon === "string" ? body.icon.slice(0, 40) || null : null;
      if (body?.image !== undefined) {
        const img = body.image ? safeImageUrl(body.image) : null;
        if (body.image && !img) return json({ ok: false, error: "INVALID_IMAGE_URL" }, 400);
        data.image = img;
      }
      if (body?.parentId !== undefined) {
        if (body.parentId === null) data.parentId = null;
        else {
          const parent = await db.category.findUnique({ where: { id: body.parentId } });
          if (!parent) return json({ ok: false, error: "PARENT_NOT_FOUND" }, 400);
          const all = await db.category.findMany({ select: { id: true, parentId: true } });
          if (wouldCycle(all, id, body.parentId)) return json({ ok: false, error: "CYCLE_FORBIDDEN" }, 400);
          data.parentId = body.parentId;
        }
      }
      const order = okInt(body?.order, 0, 10000);
      if (order !== null) data.order = order;
      if (typeof body?.enabled === "boolean") data.enabled = body.enabled;
      if (Object.keys(data).length === 1) return json({ ok: false, error: "NOTHING_TO_UPDATE" }, 400);
      const updated = await db.category.update({ where: { id }, data });
      audit("CATEGORY_UPDATED", { actorId: guard.user.id, target: row.slug, ip: clientIp(req) });
      return json({ ok: true, category: categoryToNode(updated) });
    }

    if (head === "filters" && id) {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const row = await db.filterDefinition.findUnique({ where: { id } });
      if (!row) return notFound("FILTER_NOT_FOUND");
      const body = await readJson<{ labelFa?: string; labelEn?: string; options?: unknown; meta?: unknown; order?: number; enabled?: boolean }>(req);
      const data: Record<string, unknown> = { updatedBy: guard.user.id };
      const labelFa = body?.labelFa !== undefined ? cleanText(body.labelFa, 2, 80) : undefined;
      if (labelFa) data.labelFa = labelFa;
      if (body?.labelEn !== undefined) data.labelEn = cleanText(body.labelEn, 2, 80) ?? String(data.labelFa ?? row.labelFa);
      if (body?.options !== undefined) {
        const opts = parseFilterOptions(body.options);
        data.options = JSON.stringify(opts.options);
      }
      if (body?.meta !== undefined) data.meta = JSON.stringify(parseFilterMeta(body.meta));
      const order = okInt(body?.order, 0, 1000);
      if (order !== null) data.order = order;
      if (typeof body?.enabled === "boolean") data.enabled = body.enabled;
      if (Object.keys(data).length === 1) return json({ ok: false, error: "NOTHING_TO_UPDATE" }, 400);
      const updated = await db.filterDefinition.update({ where: { id }, data });
      audit("FILTER_UPDATED", { actorId: guard.user.id, target: row.key, ip: clientIp(req) });
      return json({ ok: true, filter: updated });
    }

    if (head === "nav" && id) {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const row = await db.navigationItem.findUnique({ where: { id } });
      if (!row) return notFound("NAV_NOT_FOUND");
      const body = await readJson<{ labelFa?: string; labelEn?: string; href?: string; icon?: string; descFa?: string; descEn?: string; parentId?: string | null; order?: number; enabled?: boolean; newTab?: boolean }>(req);
      const data: Record<string, unknown> = { updatedBy: guard.user.id };
      const labelFa = body?.labelFa !== undefined ? cleanText(body.labelFa, 1, 60) : undefined;
      if (labelFa) data.labelFa = labelFa;
      if (body?.labelEn !== undefined) data.labelEn = cleanText(body.labelEn, 1, 60) ?? String(data.labelFa ?? row.labelFa);
      if (body?.href !== undefined) {
        const href = safeLinkHref(body.href);
        if (!href) return json({ ok: false, error: "INVALID_HREF" }, 400);
        data.href = href;
      }
      if (body?.icon !== undefined) data.icon = typeof body.icon === "string" ? body.icon.slice(0, 40) || null : null;
      for (const k of ["descFa", "descEn"] as const) {
        if (body?.[k] !== undefined) data[k] = cleanText((body[k] ?? "") as string, 0, 200) ?? "";
      }
      if (body?.parentId !== undefined) {
        if (body.parentId === null) data.parentId = null;
        else {
          const parent = await db.navigationItem.findUnique({ where: { id: body.parentId } });
          if (!parent) return json({ ok: false, error: "PARENT_NOT_FOUND" }, 400);
          if (parent.location !== row.location) return json({ ok: false, error: "LOCATION_MISMATCH" }, 400);
          const all = await db.navigationItem.findMany({ select: { id: true, parentId: true } });
          if (wouldCycle(all, id, body.parentId)) return json({ ok: false, error: "CYCLE_FORBIDDEN" }, 400);
          data.parentId = body.parentId;
        }
      }
      const order = okInt(body?.order, 0, 10000);
      if (order !== null) data.order = order;
      if (typeof body?.enabled === "boolean") data.enabled = body.enabled;
      if (typeof body?.newTab === "boolean") data.newTab = body.newTab;
      if (Object.keys(data).length === 1) return json({ ok: false, error: "NOTHING_TO_UPDATE" }, 400);
      const updated = await db.navigationItem.update({ where: { id }, data });
      audit("NAV_UPDATED", { actorId: guard.user.id, target: `${row.location}:${updated.labelFa}`, ip: clientIp(req) });
      return json({ ok: true, item: navToNode(updated) });
    }

    if (head === "pages" && id) {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const row = await db.page.findUnique({ where: { id } });
      if (!row) return notFound("PAGE_NOT_FOUND");
      const body = await readJson<{ titleFa?: string; titleEn?: string; blocks?: unknown }>(req);
      const data: Record<string, unknown> = { updatedBy: guard.user.id };
      const titleFa = body?.titleFa !== undefined ? cleanText(body.titleFa, 2, 120) : undefined;
      if (titleFa) data.titleFa = titleFa;
      if (body?.titleEn !== undefined) data.titleEn = cleanText(body.titleEn, 2, 120) ?? String(data.titleFa ?? row.titleFa);
      if (body?.blocks !== undefined) {
        const blocks = sanitizeBlocks(body.blocks);
        if (!blocks.ok) return json({ ok: false, error: "INVALID_BLOCKS", errors: blocks.errors }, 400);
        data.blocks = JSON.stringify(blocks.blocks);
      }
      if (Object.keys(data).length === 1) return json({ ok: false, error: "NOTHING_TO_UPDATE" }, 400);
      const updated = await db.page.update({ where: { id }, data });
      audit("PAGE_UPDATED", { actorId: guard.user.id, target: row.slug, ip: clientIp(req) });
      return json({ ok: true, page: { ...updated, blocks: parseBlocks(updated.blocks) } });
    }

    if (head === "media" && id) {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const row = await db.media.findUnique({ where: { id } });
      if (!row) return notFound("MEDIA_NOT_FOUND");
      const body = await readJson<{ altFa?: string; altEn?: string; meta?: Record<string, unknown> }>(req);
      const data: Record<string, unknown> = { updatedAt: new Date() };
      if (body?.altFa !== undefined) data.altFa = cleanText(body.altFa, 0, 200) ?? "";
      if (body?.altEn !== undefined) data.altEn = cleanText(body.altEn, 0, 200) ?? "";
      if (body?.meta && typeof body.meta === "object") {
        const safe: Record<string, unknown> = {};
        for (const [k, v] of Object.entries(body.meta).slice(0, 20)) {
          if (typeof v === "string" || typeof v === "number" || typeof v === "boolean") safe[k.slice(0, 40)] = v;
        }
        data.meta = JSON.stringify(safe);
      }
      await db.media.update({ where: { id }, data });
      audit("MEDIA_UPDATED", { actorId: guard.user.id, target: row.name, ip: clientIp(req) });
      return json({ ok: true });
    }

    if (head === "settings") {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const body = await readJson<Record<string, unknown>>(req);
      const parsed = sanitizeSettings(body ?? {});
      if (!parsed.ok) return json({ ok: false, error: "INVALID_SETTINGS", errors: parsed.errors }, 400);
      for (const key of SETTING_KEYS) {
        const value = JSON.stringify(parsed.settings[key]);
        await db.siteSetting.upsert({ where: { key }, update: { value, updatedBy: guard.user.id }, create: { key, value, updatedBy: guard.user.id } });
      }
      audit("SETTINGS_UPDATED", { actorId: guard.user.id, target: `${SETTING_KEYS.length} keys`, ip: clientIp(req) });
      return json({ ok: true, settings: parsed.settings });
    }

    return notFound("UNKNOWN_PATH");
  } catch (e) {
    return err(e);
  }
}

/* ————————————————— DELETE ————————————————— */

export async function DELETE(req: NextRequest, ctx: Ctx) {
  try {
    if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
    const { path } = await ctx.params;
    const [head, id] = path;

    if (head === "categories" && id) {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const row = await db.category.findUnique({ where: { id }, include: { children: true } });
      if (!row) return notFound("CATEGORY_NOT_FOUND");
      if (row.children.length > 0) {
        // حذف امن: فرزندان به والدِ این رده منتقل می‌شوند
        await db.category.updateMany({ where: { parentId: id }, data: { parentId: row.parentId } });
      }
      await db.category.delete({ where: { id } });
      audit("CATEGORY_DELETED", { actorId: guard.user.id, target: row.slug, ip: clientIp(req) });
      return json({ ok: true });
    }

    if (head === "filters" && id) {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const row = await db.filterDefinition.findUnique({ where: { id } });
      if (!row) return notFound("FILTER_NOT_FOUND");
      await db.filterDefinition.delete({ where: { id } });
      audit("FILTER_DELETED", { actorId: guard.user.id, target: row.key, ip: clientIp(req) });
      return json({ ok: true });
    }

    if (head === "nav" && id) {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const row = await db.navigationItem.findUnique({ where: { id } });
      if (!row) return notFound("NAV_NOT_FOUND");
      await db.navigationItem.updateMany({ where: { parentId: id }, data: { parentId: row.parentId } });
      await db.navigationItem.delete({ where: { id } });
      audit("NAV_DELETED", { actorId: guard.user.id, target: `${row.location}:${row.labelFa}`, ip: clientIp(req) });
      return json({ ok: true });
    }

    if (head === "pages" && id) {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const row = await db.page.findUnique({ where: { id } });
      if (!row) return notFound("PAGE_NOT_FOUND");
      await db.page.delete({ where: { id } });
      audit("PAGE_DELETED", { actorId: guard.user.id, target: row.slug, ip: clientIp(req) });
      return json({ ok: true });
    }

    if (head === "media" && id) {
      const guard = await requirePerm(req, "cms");
      if (isGuardError(guard)) return guard;
      const row = await db.media.findUnique({ where: { id } });
      if (!row) return notFound("MEDIA_NOT_FOUND");
      await db.media.delete({ where: { id } });
      audit("MEDIA_DELETED", { actorId: guard.user.id, target: row.name, ip: clientIp(req) });
      return json({ ok: true });
    }

    return notFound("UNKNOWN_PATH");
  } catch (e) {
    return err(e);
  }
}
