/* /api/admin/[...path] — مسیر جامع پنل مدیریت با گارد ماتریس دسترسی
 *
 * GET    stats                              (روند ۱۴ روزه + تفکیک‌ها)
 * GET    users?q&role&status&page           | GET users/export (CSV)
 * GET    users/:id                          (جزئیات + تیکت‌ها + پیام‌های اخیر)
 * PATCH  users/:id                          | DELETE users/:id
 * GET    admins                             | POST admins | PATCH admins/:id | DELETE admins/:id
 * GET    announcements                      | POST announcements
 * GET    notifications?status&channel&q&page | POST notifications/:id/retry
 * GET    content                            | POST content | DELETE content/:key
 * GET    overrides                          | POST overrides | DELETE overrides/:gameId
 * GET    games?q&status&source&deleted      (کاتالوگ کامل DB — شامل آرشیو و حذف‌شده‌ها)
 * POST   games | games/:id/duplicate | games/:id/restore | games/bulk
 * PATCH  games/:id (کامل یا جزئی + status/scheduledAt)
 * DELETE games/:id (حذف نرم — قابل بازیابی)
 * GET    tickets?status&priority&q&page     | GET tickets/:id | POST tickets/:id/reply | PATCH tickets/:id
 * GET    providers                          | POST providers/test-email
 * GET    audit?action&page&take             (گزارش حسابرسی صفحه‌بندی‌شده)
 */

import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { badRequest, cleanName, cleanText, forbidden, json, notFound, readJson, sameOrigin } from "@/lib/server/http";
import { isGuardError, requirePerm, ROLES } from "@/lib/server/guard";
import type { Perm } from "@/lib/server/guard";
import { clientIp, rateLimit } from "@/lib/server/rate-limit";
import { audit } from "@/lib/server/audit";
import { hashPassword } from "@/lib/server/password";
import { CONTENT_KEYS } from "@/lib/site-content";
import { emailConfigured, emailHtml, escapeHtml, googleConfigured, sendAndLog, smsConfigured } from "@/lib/server/notify";
import { countPerDay, dayLabels, toCsv } from "@/lib/server/stats";
import { GAMES } from "@/lib/data/games";
import { isGameShape, sanitizeGameInput, sanitizeGamePatch, slugOk, slugify } from "@/lib/game-schema";
import {
  ensureCatalogSeed,
  getRecord,
  listAllRecords,
  saveGame,
  seedGamesFromDataset,
  type GameRecordView,
} from "@/lib/server/catalog-store";
import type { GameSource, GameStatus } from "@/lib/cms/types";

const DAY = 86_400_000;
const TREND_DAYS = 14;

type Ctx = { params: Promise<{ path: string[] }> };
const PAGE_SIZE = 20;

const err = (e: unknown) => {
  console.error("[admin-api]", e);
  return json({ ok: false, error: "SERVER_ERROR" }, 500);
};

/* ————————————————— GET ————————————————— */

export async function GET(req: NextRequest, ctx: Ctx) {
  try {
    const { path } = await ctx.params;
    const [head, id] = path;

    if (head === "stats") {
      const guard = await requirePerm(req, "stats");
      if (isGuardError(guard)) return guard;
      const now = new Date();
      const since7 = new Date(now.getTime() - 7 * DAY);
      const since1 = new Date(now.getTime() - 1 * DAY);
      const sinceTrend = new Date(now.getTime() - TREND_DAYS * DAY);
      const [
        users, usersSuspended, usersVerified, usersNew7d, usersNewToday,
        ticketsOpen, ticketsTotal, ticketsPending, ticketsClosed,
        notifs, notifsEmail, notifsSms,
        announcements, overrides, content,
        latestUsers, latestTickets, userCreatedAt, ticketCreatedAt,
        customGames, overrideRows,
      ] = await Promise.all([
        db.user.count(),
        db.user.count({ where: { status: "SUSPENDED" } }),
        db.user.count({ where: { OR: [{ emailVerified: true }, { phoneVerified: true }] } }),
        db.user.count({ where: { createdAt: { gte: since7 } } }),
        db.user.count({ where: { createdAt: { gte: since1 } } }),
        db.supportTicket.count({ where: { status: { in: ["OPEN", "PENDING"] } } }),
        db.supportTicket.count(),
        db.supportTicket.count({ where: { status: "PENDING" } }),
        db.supportTicket.count({ where: { status: "CLOSED" } }),
        db.notification.count({ where: { status: { in: ["SENT", "SIMULATED"] } } }),
        db.notification.count({ where: { channel: "EMAIL", status: { in: ["SENT", "SIMULATED"] } } }),
        db.notification.count({ where: { channel: "SMS", status: { in: ["SENT", "SIMULATED"] } } }),
        db.announcement.count(),
        db.gameOverride.count(),
        db.siteContent.count(),
        db.user.findMany({ orderBy: { createdAt: "desc" }, take: 6, select: { id: true, name: true, email: true, phone: true, role: true, createdAt: true, status: true } }),
        db.supportTicket.findMany({ orderBy: { createdAt: "desc" }, take: 6, select: { id: true, subject: true, status: true, priority: true, createdAt: true, category: true } }),
        db.user.findMany({ where: { createdAt: { gte: sinceTrend } }, select: { createdAt: true } }),
        db.supportTicket.findMany({ where: { createdAt: { gte: sinceTrend } }, select: { createdAt: true } }),
        db.customGame.count(),
        db.gameOverride.findMany({ select: { data: true } }),
      ]);
      let gamesHidden = 0;
      let gamesFeatured = 0;
      const [recordRows, customCount] = await Promise.all([
        db.gameRecord.findMany({ where: { deletedAt: null }, select: { data: true, status: true } }),
        db.gameRecord.count({ where: { deletedAt: null, source: "CUSTOM" } }),
      ]);
      let gamesTotal = 0;
      for (const row of recordRows) {
        gamesTotal++;
        if (row.status !== "PUBLISHED") gamesHidden++;
        try {
          if ((JSON.parse(row.data) as { featured?: boolean }).featured === true) gamesFeatured++;
        } catch {
          /* ignore */
        }
      }
      for (const row of overrideRows) {
        try {
          if ((JSON.parse(row.data) as { hidden?: boolean }).hidden === true) gamesHidden++;
        } catch {
          /* ignore */
        }
      }
      return json({
        ok: true,
        stats: {
          users, usersSuspended, usersVerified, usersNew7d, usersNewToday,
          ticketsOpen, ticketsTotal, ticketsPending, ticketsClosed,
          notifs, notifsEmail, notifsSms,
          announcements, overrides, content,
          gamesTotal,
          gamesCustom: customCount,
          gamesHidden,
          gamesFeatured,
          trendLabels: dayLabels(TREND_DAYS, now),
          trendUsers: countPerDay(userCreatedAt.map((u) => u.createdAt), TREND_DAYS, now),
          trendTickets: countPerDay(ticketCreatedAt.map((t) => t.createdAt), TREND_DAYS, now),
        },
        latestUsers,
        latestTickets,
      });
    }

    if (head === "audit") {
      const guard = await requirePerm(req, "admins.manage");
      if (isGuardError(guard)) return guard;
      const url = new URL(req.url);
      const pageSize = Math.min(100, Math.max(10, Number(url.searchParams.get("take") ?? "25") || 25));
      const page = Math.max(1, Number(url.searchParams.get("page") ?? "1") || 1);
      const action = url.searchParams.get("action")?.trim() ?? "";
      const where = action ? { action } : {};
      const [rows, total] = await Promise.all([
        db.auditLog.findMany({
          where,
          orderBy: { createdAt: "desc" },
          skip: (page - 1) * pageSize,
          take: pageSize,
          select: { id: true, actorId: true, action: true, target: true, meta: true, ip: true, createdAt: true },
        }),
        db.auditLog.count({ where }),
      ]);
      return json({ ok: true, audit: rows, total, page, pageSize });
    }

    if (head === "users" && id === "export") {
      const guard = await requirePerm(req, "users.write");
      if (isGuardError(guard)) return guard;
      const rows = await db.user.findMany({
        orderBy: { createdAt: "desc" },
        select: { id: true, name: true, email: true, phone: true, role: true, status: true, emailVerified: true, phoneVerified: true, lang: true, googleId: true, lastLoginAt: true, createdAt: true },
      });
      const csv = toCsv([
        ["id", "name", "email", "phone", "role", "status", "emailVerified", "phoneVerified", "lang", "googleLinked", "lastLoginAt", "createdAt"],
        ...rows.map((u) => [
          u.id, u.name, u.email ?? "", u.phone ?? "", u.role, u.status, u.emailVerified ? "1" : "0", u.phoneVerified ? "1" : "0", u.lang, u.googleId ? "1" : "0", u.lastLoginAt?.toISOString() ?? "", u.createdAt.toISOString(),
        ]),
      ]);
      audit("USERS_EXPORTED", { actorId: guard.user.id, target: `rows=${rows.length}`, ip: clientIp(req) });
      return new Response(`\uFEFF${csv}`, {
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": `attachment; filename="scorent-users-${new Date().toISOString().slice(0, 10)}.csv"`,
          "Cache-Control": "no-store",
        },
      });
    }

    if (head === "users") {
      const guard = await requirePerm(req, "users.read");
      if (isGuardError(guard)) return guard;
      if (id) {
        const user = await db.user.findUnique({ where: { id }, include: { _count: { select: { tickets: true, notifications: true } } } });
        if (!user) return notFound("USER_NOT_FOUND");
        const [recentTickets, recentNotifs] = await Promise.all([
          db.supportTicket.findMany({ where: { userId: id }, orderBy: { updatedAt: "desc" }, take: 5, select: { id: true, subject: true, status: true, priority: true, createdAt: true } }),
          db.notification.findMany({ where: { userId: id }, orderBy: { createdAt: "desc" }, take: 5, select: { id: true, channel: true, kind: true, status: true, subject: true, createdAt: true } }),
        ]);
        const { passwordHash: _ph, ...safe } = user;
        void _ph;
        return json({ ok: true, user: safe, recentTickets, recentNotifs });
      }
      const url = new URL(req.url);
      const q = url.searchParams.get("q")?.trim() ?? "";
      const role = url.searchParams.get("role") ?? "";
      const status = url.searchParams.get("status") ?? "";
      const page = Math.max(1, Number(url.searchParams.get("page") ?? "1") || 1);
      const where = {
        ...(q ? { OR: [{ name: { contains: q } }, { email: { contains: q } }, { phone: { contains: q } }] } : {}),
        ...(role ? { role } : {}),
        ...(status ? { status } : {}),
      };
      const [items, total] = await Promise.all([
        db.user.findMany({ where, orderBy: { createdAt: "desc" }, skip: (page - 1) * PAGE_SIZE, take: PAGE_SIZE, select: { id: true, name: true, email: true, phone: true, role: true, status: true, emailVerified: true, phoneVerified: true, emailOptIn: true, smsOptIn: true, lang: true, googleId: true, passwordHash: true, lastLoginAt: true, createdAt: true } }),
        db.user.count({ where }),
      ]);
      return json({ ok: true, users: items.map((u) => ({ ...u, passwordHash: Boolean(u.passwordHash), googleLinked: Boolean(u.googleId), googleId: undefined })), total, page, pageSize: PAGE_SIZE });
    }

    if (head === "admins") {
      const guard = await requirePerm(req, "admins.manage");
      if (isGuardError(guard)) return guard;
      const admins = await db.user.findMany({ where: { role: { in: ["SUPER_ADMIN", "ADMIN", "CONTENT_EDITOR", "SUPPORT_AGENT"] } }, orderBy: { createdAt: "asc" }, select: { id: true, name: true, email: true, phone: true, role: true, status: true, lastLoginAt: true, createdAt: true } });
      return json({ ok: true, admins, me: guard.user.id });
    }

    if (head === "announcements") {
      const guard = await requirePerm(req, "notify");
      if (isGuardError(guard)) return guard;
      const announcements = await db.announcement.findMany({ orderBy: { createdAt: "desc" }, take: 50 });
      return json({ ok: true, announcements });
    }

    if (head === "notifications") {
      const guard = await requirePerm(req, "notify");
      if (isGuardError(guard)) return guard;
      const url = new URL(req.url);
      const status = url.searchParams.get("status") ?? "";
      const channel = url.searchParams.get("channel") ?? "";
      const q = url.searchParams.get("q")?.trim() ?? "";
      const page = Math.max(1, Number(url.searchParams.get("page") ?? "1") || 1);
      const where = {
        ...(status ? { status } : {}),
        ...(channel ? { channel } : {}),
        ...(q ? { OR: [{ recipient: { contains: q } }, { subject: { contains: q } }, { body: { contains: q } }] } : {}),
      };
      const [items, total] = await Promise.all([
        db.notification.findMany({ where, orderBy: { createdAt: "desc" }, skip: (page - 1) * PAGE_SIZE, take: PAGE_SIZE }),
        db.notification.count({ where }),
      ]);
      return json({ ok: true, notifications: items, total, page, pageSize: PAGE_SIZE });
    }

    if (head === "content") {
      const guard = await requirePerm(req, "content");
      if (isGuardError(guard)) return guard;
      const rows = await db.siteContent.findMany({ orderBy: { key: "asc" } });
      return json({ ok: true, content: rows });
    }

    if (head === "overrides") {
      const guard = await requirePerm(req, "games");
      if (isGuardError(guard)) return guard;
      const rows = await db.gameOverride.findMany({ orderBy: { updatedAt: "desc" } });
      return json({ ok: true, overrides: rows });
    }

    if (head === "games") {
      const guard = await requirePerm(req, "games");
      if (isGuardError(guard)) return guard;
      await ensureCatalogSeed();
      const url = new URL(req.url);
      const q = url.searchParams.get("q")?.trim().toLowerCase() ?? "";
      const status = url.searchParams.get("status") ?? "";
      const source = url.searchParams.get("source") ?? "";
      const deleted = url.searchParams.get("deleted") ?? ""; // "only" | "none" | "" (همه)
      let views: GameRecordView[] = await listAllRecords();
      if (q) views = views.filter((v) => v.game.title.toLowerCase().includes(q) || v.id.includes(q) || (v.game.taglineEn ?? v.game.tagline).toLowerCase().includes(q) || (v.game.developer ?? "").toLowerCase().includes(q));
      if (status && ["PUBLISHED", "DRAFT", "ARCHIVED"].includes(status)) views = views.filter((v) => v.status === status);
      if (source && ["DATASET", "CUSTOM"].includes(source)) views = views.filter((v) => v.source === source);
      if (deleted === "only") views = views.filter((v) => v.deletedAt);
      else if (deleted === "none") views = views.filter((v) => !v.deletedAt);
      return json({
        ok: true,
        games: views,
        total: views.length,
        datasetSize: views.filter((v) => v.source === "DATASET").length,
      });
    }

    if (head === "tickets") {
      const guard = await requirePerm(req, "tickets");
      if (isGuardError(guard)) return guard;
      if (id) {
        const ticket = await db.supportTicket.findUnique({ where: { id }, include: { messages: { orderBy: { createdAt: "asc" } }, user: { select: { id: true, name: true, email: true, phone: true, role: true } } } });
        if (!ticket) return notFound("TICKET_NOT_FOUND");
        return json({ ok: true, ticket });
      }
      const url = new URL(req.url);
      const status = url.searchParams.get("status") ?? "";
      const priority = url.searchParams.get("priority") ?? "";
      const q = url.searchParams.get("q")?.trim() ?? "";
      const page = Math.max(1, Number(url.searchParams.get("page") ?? "1") || 1);
      const where = {
        ...(status ? { status } : {}),
        ...(priority ? { priority } : {}),
        ...(q ? { OR: [{ subject: { contains: q } }, { contact: { contains: q } }, { guestName: { contains: q } }] } : {}),
      };
      const [items, total] = await Promise.all([
        db.supportTicket.findMany({ where, orderBy: [{ priority: "asc" }, { updatedAt: "desc" }], skip: (page - 1) * PAGE_SIZE, take: PAGE_SIZE, include: { _count: { select: { messages: true } }, user: { select: { name: true, email: true } } } }),
        db.supportTicket.count({ where }),
      ]);
      return json({ ok: true, tickets: items, total, page, pageSize: PAGE_SIZE });
    }

    if (head === "providers") {
      const guard = await requirePerm(req, "providers");
      if (isGuardError(guard)) return guard;
      return json({
        ok: true,
        providers: {
          email: { configured: emailConfigured(), host: emailConfigured() ? String(process.env.SMTP_HOST) : null, user: process.env.SMTP_USER ?? null },
          sms: { configured: smsConfigured(), provider: process.env.SMS_PROVIDER ?? (process.env.SMS_WEBHOOK_URL ? "webhook" : null) },
          google: { configured: googleConfigured() },
          adminPasswordEnv: Boolean(process.env.ADMIN_PASSWORD),
        },
      });
    }

    return notFound("UNKNOWN_PATH");
  } catch (e) {
    return err(e);
  }
}

/* ————————————————— POST ————————————————— */

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
    const { path } = await ctx.params;
    const [head, id, action] = path;

    if (head === "admins") {
      const guard = await requirePerm(req, "admins.manage");
      if (isGuardError(guard)) return guard;
      if (!(await rateLimit(`admin-add:${clientIp(req)}`, 10, 60_000))) return json({ ok: false, error: "RATE_LIMITED" }, 429);
      const body = await readJson<{ name?: string; email?: string; password?: string; role?: string }>(req);
      const name = cleanName(body?.name);
      const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
      const password = typeof body?.password === "string" ? body.password : "";
      const role = body?.role ?? "";
      if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || password.length < 8) return json({ ok: false, error: "INVALID_INPUT" }, 400);
      if (!["ADMIN", "CONTENT_EDITOR", "SUPPORT_AGENT"].includes(role)) return json({ ok: false, error: "INVALID_ROLE" }, 400);
      const exists = await db.user.findUnique({ where: { email } });
      if (exists) return json({ ok: false, error: "EMAIL_TAKEN" }, 409);
      const user = await db.user.create({
        data: { name, email, passwordHash: await hashPassword(password), role, emailVerified: true },
      });
      audit("ADMIN_ADDED", { actorId: guard.user.id, target: email, meta: role, ip: clientIp(req) });
      return json({ ok: true, admin: { id: user.id, name: user.name, email: user.email, role: user.role } });
    }

    if (head === "announcements") {
      const guard = await requirePerm(req, "notify");
      if (isGuardError(guard)) return guard;
      if (!(await rateLimit(`announce:${clientIp(req)}`, 6, 60_000))) return json({ ok: false, error: "RATE_LIMITED" }, 429);
      const body = await readJson<{ titleFa?: string; titleEn?: string; bodyFa?: string; bodyEn?: string; kind?: string; audience?: string; channels?: string[] }>(req);
      const titleFa = cleanText(body?.titleFa, 3, 120);
      const bodyFa = cleanText(body?.bodyFa, 5, 2000);
      if (!titleFa || !bodyFa) return json({ ok: false, error: "INVALID_INPUT" }, 400);
      const titleEn = cleanText(body?.titleEn, 3, 120) ?? titleFa;
      const bodyEn = cleanText(body?.bodyEn, 5, 2000) ?? bodyFa;
      const kind = ["EVENT", "UPDATE", "PROMO", "MAINTENANCE"].includes(body?.kind ?? "") ? body!.kind! : "EVENT";
      const audience = ["USERS", "ADMINS", "ALL"].includes(body?.audience ?? "") ? body!.audience! : "USERS";
      const channels = (body?.channels ?? []).filter((c) => c === "EMAIL" || c === "SMS");
      if (channels.length === 0) return json({ ok: false, error: "NO_CHANNEL" }, 400);

      const roles = audience === "ADMINS" ? ["SUPER_ADMIN", "ADMIN", "CONTENT_EDITOR", "SUPPORT_AGENT"] : audience === "ALL" ? undefined : ["USER"];
      const users = await db.user.findMany({ where: { status: "ACTIVE", ...(roles ? { role: { in: roles } } : {}) } });

      const announcement = await db.announcement.create({
        data: { title: titleFa, body: bodyFa, kind, audience, channels: JSON.stringify(channels), createdById: guard.user.id },
      });

      let sent = 0;
      let failed = 0;
      for (const u of users) {
        const fa = u.lang !== "en";
        const title = fa ? titleFa : titleEn;
        const text = fa ? bodyFa : bodyEn;
        for (const channel of channels) {
          if (channel === "EMAIL" && u.email && u.emailOptIn) {
            const r = await sendAndLog({
              userId: u.id,
              channel,
              recipient: u.email,
              subject: `Scorent — ${title}`,
              body: text,
              html: emailHtml(fa ? "fa" : "en", escapeHtml(title), `<p>${escapeHtml(text).replace(/\n/g, "<br/>")}</p>`),
              kind: "ANNOUNCEMENT",
              meta: { announcementId: announcement.id },
            });
            if (r.status === "FAILED") failed++; else sent++;
          } else if (channel === "SMS" && u.phone && u.smsOptIn) {
            const r = await sendAndLog({ userId: u.id, channel, recipient: u.phone, body: `Scorent — ${title}: ${text}`, kind: "ANNOUNCEMENT", meta: { announcementId: announcement.id } });
            if (r.status === "FAILED") failed++; else sent++;
          }
        }
      }
      const updated = await db.announcement.update({ where: { id: announcement.id }, data: { recipients: users.length, sentCount: sent, failCount: failed } });
      audit("ANNOUNCEMENT_SENT", { actorId: guard.user.id, target: announcement.id, meta: `sent=${sent} failed=${failed} audience=${audience} channels=${channels.join(",")}`, ip: clientIp(req) });
      return json({ ok: true, announcement: updated, sent, failed, skipped: users.length - sent - failed < 0 ? 0 : users.length });
    }

    if (head === "content") {
      const guard = await requirePerm(req, "content");
      if (isGuardError(guard)) return guard;
      const body = await readJson<{ key?: string; valueFa?: string; valueEn?: string }>(req);
      const key = typeof body?.key === "string" ? body.key.trim() : "";
      const valueFa = typeof body?.valueFa === "string" ? body.valueFa.slice(0, 4000) : "";
      const valueEn = typeof body?.valueEn === "string" ? body.valueEn.slice(0, 4000) : "";
      if (!/^[a-z0-9._-]{2,60}$/.test(key)) return json({ ok: false, error: "INVALID_KEY" }, 400);
      const row = await db.siteContent.upsert({
        where: { key },
        update: { valueFa, valueEn: valueEn || valueFa, updatedBy: guard.user.id },
        create: { key, valueFa, valueEn: valueEn || valueFa, updatedBy: guard.user.id },
      });
      audit("CONTENT_UPDATED", { actorId: guard.user.id, target: key, ip: clientIp(req) });
      return json({ ok: true, row });
    }

    if (head === "overrides") {
      const guard = await requirePerm(req, "games");
      if (isGuardError(guard)) return guard;
      const body = await readJson<{ gameId?: string; data?: Record<string, unknown> }>(req);
      const gameId = typeof body?.gameId === "string" ? body.gameId.trim() : "";
      if (!/^[a-z0-9-]{2,60}$/.test(gameId)) return json({ ok: false, error: "INVALID_GAME_ID" }, 400);
      const d = body?.data ?? {};
      const clean: Record<string, unknown> = {};
      if (typeof d.hidden === "boolean") clean.hidden = d.hidden;
      if (typeof d.featured === "boolean") clean.featured = d.featured;
      if (typeof d.discountPct === "number" && Number.isFinite(d.discountPct)) clean.discountPct = Math.max(0, Math.min(90, Math.round(d.discountPct)));
      for (const k of ["taglineFa", "taglineEn", "descriptionFa", "descriptionEn"] as const) {
        if (typeof d[k] === "string" && (d[k] as string).trim()) clean[k] = (d[k] as string).trim().slice(0, 2000);
      }
      if (Object.keys(clean).length === 0) return json({ ok: false, error: "EMPTY_OVERRIDE" }, 400);
      const row = await db.gameOverride.upsert({
        where: { gameId },
        update: { data: JSON.stringify(clean), updatedBy: guard.user.id },
        create: { gameId, data: JSON.stringify(clean), updatedBy: guard.user.id },
      });
      audit("OVERRIDE_UPDATED", { actorId: guard.user.id, target: gameId, meta: JSON.stringify(clean).slice(0, 300), ip: clientIp(req) });
      return json({ ok: true, row });
    }

    if (head === "games" && id === "bulk") {
      const guard = await requirePerm(req, "games");
      if (isGuardError(guard)) return guard;
      const body = await readJson<{ action?: string; ids?: string[] }>(req);
      const action = body?.action ?? "";
      const ids = Array.isArray(body?.ids) ? body!.ids!.filter((x) => typeof x === "string" && slugOk(x)).slice(0, 200) : [];
      if (!["publish", "draft", "archive", "restore", "delete"].includes(action) || ids.length === 0) {
        return json({ ok: false, error: "INVALID_INPUT" }, 400);
      }
      const data =
        action === "publish" ? { status: "PUBLISHED", deletedAt: null } :
        action === "draft" ? { status: "DRAFT" } :
        action === "archive" ? { status: "ARCHIVED" } :
        action === "restore" ? { deletedAt: null } :
        { deletedAt: new Date() };
      const result = await db.gameRecord.updateMany({ where: { id: { in: ids } }, data });
      audit("GAME_BULK", { actorId: guard.user.id, target: `${action}×${result.count}`, meta: ids.slice(0, 8).join(","), ip: clientIp(req) });
      return json({ ok: true, count: result.count });
    }

    if (head === "games" && id && (action === "duplicate" || action === "restore")) {
      const guard = await requirePerm(req, "games");
      if (isGuardError(guard)) return guard;
      if (!(await rateLimit(`admin-game:${clientIp(req)}`, 30, 60_000))) return json({ ok: false, error: "RATE_LIMITED" }, 429);
      if (action === "restore") {
        const existing = await db.gameRecord.findUnique({ where: { id } });
        if (!existing) return notFound("GAME_NOT_FOUND");
        await db.gameRecord.update({ where: { id }, data: { deletedAt: null } });
        audit("GAME_RESTORED", { actorId: guard.user.id, target: id, ip: clientIp(req) });
        return json({ ok: true });
      }
      // duplicate
      const source = await getRecord(id);
      if (!source) return notFound("GAME_NOT_FOUND");
      const base = slugify(`${source.game.title}-copy`) || `${source.id}-copy`;
      let newId = base;
      let n = 2;
      while (await db.gameRecord.findUnique({ where: { id: newId } })) newId = `${base}-${n++}`;
      const view = await saveGame(newId, { ...source.game, id: newId, featured: false }, { source: "CUSTOM", status: "DRAFT", actor: guard.user.id });
      audit("GAME_DUPLICATED", { actorId: guard.user.id, target: `${id} → ${newId}`, ip: clientIp(req) });
      return json({ ok: true, game: view });
    }

    if (head === "games") {
      const guard = await requirePerm(req, "games");
      if (isGuardError(guard)) return guard;
      if (!(await rateLimit(`admin-game:${clientIp(req)}`, 30, 60_000))) return json({ ok: false, error: "RATE_LIMITED" }, 429);
      const body = await readJson<{ id?: string; game?: Record<string, unknown>; status?: string; scheduledAt?: string | null }>(req);
      const id = typeof body?.id === "string" ? body.id.trim().toLowerCase() : "";
      const parsed = sanitizeGameInput(body?.game);
      if (!parsed.ok) return json({ ok: false, error: "INVALID_INPUT", errors: parsed.errors }, 400);
      if (id !== parsed.game.id) return json({ ok: false, error: "INVALID_INPUT", errors: ["ERR_ID_MISMATCH"] }, 400);
      const exists = await db.gameRecord.findUnique({ where: { id } });
      if (exists) return json({ ok: false, error: "GAME_ID_TAKEN" }, 409);
      const status = ["PUBLISHED", "DRAFT", "ARCHIVED"].includes(body?.status ?? "") ? (body!.status as GameStatus) : "PUBLISHED";
      let scheduledAt: Date | null = null;
      if (typeof body?.scheduledAt === "string" && body.scheduledAt) {
        const d = new Date(body.scheduledAt);
        if (Number.isNaN(d.getTime())) return json({ ok: false, error: "INVALID_SCHEDULE" }, 400);
        scheduledAt = d;
      }
      const view = await saveGame(id, parsed.game, { source: "CUSTOM", status, actor: guard.user.id });
      if (scheduledAt) await db.gameRecord.update({ where: { id }, data: { scheduledAt } });
      audit("GAME_CREATED", { actorId: guard.user.id, target: id, meta: parsed.game.title, ip: clientIp(req) });
      return json({ ok: true, game: { ...view, scheduledAt: scheduledAt?.toISOString() ?? null } });
    }

    if (head === "tickets" && id && action === "reply") {
      const guard = await requirePerm(req, "tickets");
      if (isGuardError(guard)) return guard;
      const ticket = await db.supportTicket.findUnique({ where: { id }, include: { user: true } });
      if (!ticket) return notFound("TICKET_NOT_FOUND");
      const body = await readJson<{ body?: string }>(req);
      const text = cleanText(body?.body, 2, 2000);
      if (!text) return json({ ok: false, error: "INVALID_INPUT" }, 400);

      const message = await db.ticketMessage.create({
        data: { ticketId: ticket.id, authorId: guard.user.id, authorName: guard.user.name, authorRole: "ADMIN", body: text },
      });
      await db.supportTicket.update({ where: { id: ticket.id }, data: { status: "PENDING", updatedAt: new Date() } });
      audit("TICKET_REPLIED", { actorId: guard.user.id, target: ticket.id, ip: clientIp(req) });

      // اطلاع‌رسانی پاسخ به صاحب تیکت
      if (ticket.user?.email && ticket.user.emailOptIn) {
        const fa = ticket.user.lang !== "en";
        const tid = ticket.id.slice(-8).toUpperCase();
        await sendAndLog({
          userId: ticket.user.id,
          channel: "EMAIL",
          recipient: ticket.user.email,
          subject: fa ? `پاسخ به تیکت #${tid} — Scorent` : `Reply to ticket #${tid} — Scorent`,
          body: text,
          html: emailHtml(fa ? "fa" : "en", fa ? "پشتیبانی Scorent پاسخ داد" : "Scorent support replied", `<p>${escapeHtml(text).replace(/\n/g, "<br/>")}</p>`),
          kind: "TICKET_REPLY",
          meta: { ticketId: ticket.id },
        });
      } else if (!ticket.user && ticket.contact.includes("@")) {
        await sendAndLog({
          channel: "EMAIL",
          recipient: ticket.contact,
          subject: `Scorent — Reply`,
          body: text,
          html: emailHtml("fa", "پاسخ پشتیبانی", `<p>${escapeHtml(text).replace(/\n/g, "<br/>")}</p>`),
          kind: "TICKET_REPLY",
          meta: { ticketId: ticket.id },
        });
      } else if (ticket.user?.phone && ticket.user.smsOptIn) {
        await sendAndLog({ userId: ticket.user.id, channel: "SMS", recipient: ticket.user.phone, body: `Scorent — پاسخ به تیکت شما: ${text}`.slice(0, 400), kind: "TICKET_REPLY", meta: { ticketId: ticket.id } });
      }
      return json({ ok: true, message });
    }

    if (head === "notifications" && id && action === "retry") {
      const guard = await requirePerm(req, "notify");
      if (isGuardError(guard)) return guard;
      const row = await db.notification.findUnique({ where: { id } });
      if (!row) return notFound("NOT_FOUND");
      const result = await sendAndLog({
        userId: row.userId,
        channel: row.channel as "EMAIL" | "SMS",
        recipient: row.recipient,
        subject: row.subject,
        body: row.body,
        kind: row.kind,
        meta: row.meta ? JSON.parse(row.meta) : undefined,
      });
      await db.notification.update({ where: { id: row.id }, data: { status: result.status, provider: result.provider, error: result.error ?? null, sentAt: result.status === "FAILED" ? null : new Date() } });
      audit("NOTIFICATION_RETRIED", { actorId: guard.user.id, target: row.id, meta: result.status, ip: clientIp(req) });
      return json({ ok: result.ok, result });
    }

    if (head === "providers" && id === "test-email") {
      const guard = await requirePerm(req, "providers");
      if (isGuardError(guard)) return guard;
      if (!(await rateLimit(`test-email:${clientIp(req)}`, 5, 60_000))) return json({ ok: false, error: "RATE_LIMITED" }, 429);
      if (!guard.user.email) return json({ ok: false, error: "NO_EMAIL" }, 400);
      const fa = guard.user.lang !== "en";
      const result = await sendAndLog({
        userId: guard.user.id,
        channel: "EMAIL",
        recipient: guard.user.email,
        subject: fa ? "ایمیل آزمایشی — Scorent" : "Test email — Scorent",
        body: fa ? "این یک ایمیل آزمایشی از پنل مدیریت Scorent است؛ اگر این را می‌بینی، SMTP درست کار می‌کند." : "This is a test email from the Scorent admin panel; if you can read this, SMTP works.",
        html: emailHtml(fa ? "fa" : "en", fa ? "ایمیل آزمایشی" : "Test email", `<p>${fa ? "اتصال SMTP با موفقیت انجام شد." : "SMTP connection verified."}</p>`),
        kind: "SYSTEM",
        meta: { test: true },
      });
      audit("TEST_EMAIL_SENT", { actorId: guard.user.id, target: guard.user.email, meta: result.status, ip: clientIp(req) });
      return json({ ok: result.ok, status: result.status, provider: result.provider, error: result.error ?? null });
    }

    return notFound("UNKNOWN_PATH");
  } catch (e) {
    return err(e);
  }
}

/* ————————————————— PATCH ————————————————— */

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
    const { path } = await ctx.params;
    const [head, id] = path;

    if (head === "users" && id) {
      const guard = await requirePerm(req, "users.write");
      if (isGuardError(guard)) return guard;
      const target = await db.user.findUnique({ where: { id } });
      if (!target) return notFound("USER_NOT_FOUND");
      const body = await readJson<{ name?: string; status?: string; emailVerified?: boolean; phoneVerified?: boolean; emailOptIn?: boolean; smsOptIn?: boolean; role?: string }>(req);
      if (!body) return badRequest("BAD_JSON");

      const data: Record<string, unknown> = {};
      if (typeof body.name === "string") {
        const n = cleanName(body.name);
        if (!n) return json({ ok: false, error: "INVALID_NAME" }, 400);
        data.name = n;
      }
      if (body.status === "ACTIVE" || body.status === "SUSPENDED") {
        if (target.id === guard.user.id) return json({ ok: false, error: "CANNOT_MODIFY_SELF" }, 400);
        if (target.role === "SUPER_ADMIN" && guard.user.role !== "SUPER_ADMIN") return forbidden();
        data.status = body.status;
      }
      if (typeof body.emailVerified === "boolean") data.emailVerified = body.emailVerified;
      if (typeof body.phoneVerified === "boolean") data.phoneVerified = body.phoneVerified;
      if (typeof body.emailOptIn === "boolean") data.emailOptIn = body.emailOptIn;
      if (typeof body.smsOptIn === "boolean") data.smsOptIn = body.smsOptIn;
      if (body.role) {
        if (!ROLES.includes(body.role as (typeof ROLES)[number])) return json({ ok: false, error: "INVALID_ROLE" }, 400);
        // تغییر نقش = مدیریت مدیران (و فقط ابر-ادمین)
        const g2 = await requirePerm(req, "admins.manage");
        if (isGuardError(g2)) return g2;
        if (target.id === guard.user.id) return json({ ok: false, error: "CANNOT_MODIFY_SELF" }, 400);
        if (target.role === "SUPER_ADMIN") return json({ ok: false, error: "CANNOT_CHANGE_SUPER_ADMIN" }, 400);
        data.role = body.role;
      }
      if (Object.keys(data).length === 0) return json({ ok: false, error: "NOTHING_TO_UPDATE" }, 400);
      const user = await db.user.update({ where: { id }, data });
      if (data.status === "SUSPENDED") audit("ACCOUNT_SUSPENDED", { actorId: guard.user.id, target: target.email ?? target.phone, ip: clientIp(req) });
      else if (data.status === "ACTIVE") audit("ACCOUNT_UNSUSPENDED", { actorId: guard.user.id, target: target.email ?? target.phone, ip: clientIp(req) });
      if (data.role) audit("ROLE_CHANGED", { actorId: guard.user.id, target: target.email ?? target.phone, meta: `${target.role} → ${String(data.role)}`, ip: clientIp(req) });
      return json({ ok: true, user: { id: user.id, name: user.name, email: user.email, phone: user.phone, role: user.role, status: user.status, emailVerified: user.emailVerified, phoneVerified: user.phoneVerified } });
    }

    if (head === "admins" && id) {
      const guard = await requirePerm(req, "admins.manage");
      if (isGuardError(guard)) return guard;
      const target = await db.user.findUnique({ where: { id } });
      if (!target) return notFound("USER_NOT_FOUND");
      if (target.id === guard.user.id) return json({ ok: false, error: "CANNOT_MODIFY_SELF" }, 400);
      if (target.role === "SUPER_ADMIN") return json({ ok: false, error: "CANNOT_CHANGE_SUPER_ADMIN" }, 400);
      const body = await readJson<{ role?: string; status?: string }>(req);
      const data: Record<string, unknown> = {};
      if (body?.role) {
        if (!["ADMIN", "CONTENT_EDITOR", "SUPPORT_AGENT", "USER"].includes(body.role)) return json({ ok: false, error: "INVALID_ROLE" }, 400);
        data.role = body.role;
      }
      if (body?.status === "ACTIVE" || body?.status === "SUSPENDED") data.status = body.status;
      if (Object.keys(data).length === 0) return json({ ok: false, error: "NOTHING_TO_UPDATE" }, 400);
      const user = await db.user.update({ where: { id }, data });
      if (data.role) audit("ROLE_CHANGED", { actorId: guard.user.id, target: target.email, meta: `${target.role} → ${String(data.role)}`, ip: clientIp(req) });
      if (data.status === "SUSPENDED") audit("ACCOUNT_SUSPENDED", { actorId: guard.user.id, target: target.email, ip: clientIp(req) });
      return json({ ok: true, admin: { id: user.id, name: user.name, email: user.email, role: user.role, status: user.status } });
    }

    if (head === "tickets" && id) {
      const guard = await requirePerm(req, "tickets");
      if (isGuardError(guard)) return guard;
      const ticket = await db.supportTicket.findUnique({ where: { id } });
      if (!ticket) return notFound("TICKET_NOT_FOUND");
      const body = await readJson<{ status?: string; priority?: string }>(req);
      const data: Record<string, unknown> = {};
      if (body?.status && ["OPEN", "PENDING", "CLOSED"].includes(body.status)) data.status = body.status;
      if (body?.priority && ["LOW", "NORMAL", "HIGH"].includes(body.priority)) data.priority = body.priority;
      if (Object.keys(data).length === 0) return json({ ok: false, error: "NOTHING_TO_UPDATE" }, 400);
      const updated = await db.supportTicket.update({ where: { id }, data });
      audit("TICKET_STATUS_CHANGED", { actorId: guard.user.id, target: id, meta: JSON.stringify(data), ip: clientIp(req) });
      return json({ ok: true, ticket: updated });
    }

    if (head === "games" && id) {
      const guard = await requirePerm(req, "games");
      if (isGuardError(guard)) return guard;
      const existing = await db.gameRecord.findUnique({ where: { id } });
      if (!existing) return notFound("GAME_NOT_FOUND");
      const body = await readJson<{ game?: Record<string, unknown>; patch?: Record<string, unknown>; status?: string; scheduledAt?: string | null; sortOrder?: number }>(req);
      const data: Record<string, unknown> = { updatedBy: guard.user.id };
      if (body?.game) {
        const parsed = sanitizeGameInput({ ...body.game, id });
        if (!parsed.ok) return json({ ok: false, error: "INVALID_INPUT", errors: parsed.errors }, 400);
        data.data = JSON.stringify(parsed.game);
      } else if (body?.patch && typeof body.patch === "object") {
        const check = sanitizeGamePatch(body.patch);
        if (!check.ok) return json({ ok: false, error: "INVALID_INPUT", errors: check.errors }, 400);
        let current: Record<string, unknown> = {};
        try {
          current = JSON.parse(existing.data) as Record<string, unknown>;
        } catch {
          return json({ ok: false, error: "CORRUPT_RECORD" }, 500);
        }
        const merged: Record<string, unknown> = { ...current, ...(body.patch as Record<string, unknown>), id };
        // اگر قیمت جدید از قیمت قبلی بالاتر رفت، originalPrice به‌طور خودکار بالا می‌آید (رفتار انتظاری ادمین)
        if (merged.price !== undefined && merged.originalPrice !== undefined && Number(merged.price) > Number(merged.originalPrice)) {
          merged.originalPrice = merged.price;
        }
        const reparsed = sanitizeGameInput(merged);
        if (!reparsed.ok) return json({ ok: false, error: "INVALID_INPUT", errors: reparsed.errors }, 400);
        data.data = JSON.stringify(reparsed.game);
      }
      if (body?.status && ["PUBLISHED", "DRAFT", "ARCHIVED"].includes(body.status)) data.status = body.status;
      if (body?.scheduledAt !== undefined) {
        if (body.scheduledAt === null) data.scheduledAt = null;
        else {
          const d = new Date(String(body.scheduledAt));
          if (Number.isNaN(d.getTime())) return json({ ok: false, error: "INVALID_SCHEDULE" }, 400);
          data.scheduledAt = d;
        }
      }
      if (typeof body?.sortOrder === "number" && Number.isFinite(body.sortOrder)) data.sortOrder = Math.max(0, Math.min(100000, Math.round(body.sortOrder)));
      if (Object.keys(data).length <= 1) return json({ ok: false, error: "NOTHING_TO_UPDATE" }, 400);
      const row = await db.gameRecord.update({ where: { id }, data });
      audit("GAME_UPDATED", { actorId: guard.user.id, target: id, meta: String(data.status ?? ""), ip: clientIp(req) });
      return json({ ok: true, game: { id: row.id, status: row.status, data: row.data, updatedAt: row.updatedAt.toISOString() } });
    }

    return notFound("UNKNOWN_PATH");
  } catch (e) {
    return err(e);
  }
}

/* ————————————————— DELETE ————————————————— */

export async function DELETE(req: NextRequest, ctx: Ctx) {
  try {
    if (!sameOrigin(req)) return badRequest("BAD_ORIGIN");
    const { path } = await ctx.params;
    const [head, id] = path;

    if (head === "users" && id) {
      const guard = await requirePerm(req, "users.delete");
      if (isGuardError(guard)) return guard;
      if (id === guard.user.id) return json({ ok: false, error: "CANNOT_DELETE_SELF" }, 400);
      const target = await db.user.findUnique({ where: { id } });
      if (!target) return notFound("USER_NOT_FOUND");
      if (target.role === "SUPER_ADMIN") return json({ ok: false, error: "CANNOT_DELETE_SUPER_ADMIN" }, 400);
      await db.user.delete({ where: { id } });
      audit("USER_DELETED", { actorId: guard.user.id, target: target.email ?? target.phone, meta: target.role, ip: clientIp(req) });
      return json({ ok: true });
    }

    if (head === "admins" && id) {
      const guard = await requirePerm(req, "admins.manage");
      if (isGuardError(guard)) return guard;
      const target = await db.user.findUnique({ where: { id } });
      if (!target) return notFound("USER_NOT_FOUND");
      if (target.id === guard.user.id) return json({ ok: false, error: "CANNOT_DEMOTE_SELF" }, 400);
      if (target.role === "SUPER_ADMIN") return json({ ok: false, error: "CANNOT_CHANGE_SUPER_ADMIN" }, 400);
      // حذف نرم: تنزل به کاربر عادی (تاریخچه‌ی تیکت‌ها حفظ می‌شود)
      const user = await db.user.update({ where: { id }, data: { role: "USER" } });
      audit("ADMIN_REMOVED", { actorId: guard.user.id, target: target.email, meta: `${target.role} → USER`, ip: clientIp(req) });
      return json({ ok: true, admin: { id: user.id, role: user.role } });
    }

    if (head === "content" && id) {
      const guard = await requirePerm(req, "content");
      if (isGuardError(guard)) return guard;
      if (CONTENT_KEYS.includes(id)) return json({ ok: false, error: "DEFAULT_KEY_DELETE" }, 400);
      await db.siteContent.delete({ where: { key: id } }).catch(() => undefined);
      audit("CONTENT_DELETED", { actorId: guard.user.id, target: id, ip: clientIp(req) });
      return json({ ok: true });
    }

    if (head === "overrides" && id) {
      const guard = await requirePerm(req, "games");
      if (isGuardError(guard)) return guard;
      await db.gameOverride.delete({ where: { gameId: id } }).catch(() => undefined);
      audit("OVERRIDE_DELETED", { actorId: guard.user.id, target: id, ip: clientIp(req) });
      return json({ ok: true });
    }

    if (head === "games" && id) {
      const guard = await requirePerm(req, "games");
      if (isGuardError(guard)) return guard;
      const existing = await db.gameRecord.findUnique({ where: { id } });
      if (!existing) return notFound("GAME_NOT_FOUND");
      // حذف نرم — بازی در زباله‌دان پنل می‌ماند و قابل بازیابی است؛ هیچ رابطه‌ای نمی‌شکند
      await db.gameRecord.update({ where: { id }, data: { deletedAt: new Date(), status: "ARCHIVED" } });
      audit("GAME_DELETED", { actorId: guard.user.id, target: id, meta: "soft", ip: clientIp(req) });
      return json({ ok: true, soft: true });
    }

    return notFound("UNKNOWN_PATH");
  } catch (e) {
    return err(e);
  }
}
