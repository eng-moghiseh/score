/* GET /api/categories — رده‌های فعال عمومی (تخت، مرتب) */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const rows = await db.category.findMany({ where: { enabled: true }, orderBy: [{ order: "asc" }, { createdAt: "asc" }] });
    const res = NextResponse.json({
      ok: true,
      categories: rows.map((r) => ({
        slug: r.slug,
        nameFa: r.nameFa,
        nameEn: r.nameEn,
        descFa: r.descFa,
        descEn: r.descEn,
      })),
    });
    res.headers.set("Cache-Control", "public, max-age=60, stale-while-revalidate=300");
    return res;
  } catch {
    const res = NextResponse.json({ ok: true, categories: [] });
    res.headers.set("Cache-Control", "no-store");
    return res;
  }
}
