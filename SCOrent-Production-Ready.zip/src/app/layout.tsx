import type { Metadata, Viewport } from "next";
import Script from "next/script";
import "@fontsource-variable/vazirmatn";
import "./globals.css";
import { UiEffects } from "@/components/scorent/ui-effects";
import { UI_BOOT_SCRIPT } from "@/lib/i18n";
import { SITE_BASE, siteJsonLd } from "@/lib/seo";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_BASE),
  title: {
    default: "Scorent | کشف کن، تجربه کن، بازی کن",
    template: "%s | Scorent",
  },
  description:
    "Scorent پلتفرم کشف و اجاره‌ی بازی است: با دستیار هوشمند متصل به کاتالوگ و موتور پیشنهاد شفاف، بازی بعدی‌ات را با سلیقه، بودجه و زمان خودت پیدا کن؛ اول تجربه کن، بعد با خیال راحت خرید کن.",
  keywords: ["Scorent", "بازی", "اجاره بازی", "پیشنهاد هوشمند بازی", "دستیار AI گیمینگ", "فروشگاه بازی", "کشف بازی"],
  authors: [{ name: "Team Scorent" }],
  applicationName: "Scorent",
  alternates: { canonical: SITE_BASE },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true, "max-image-preview": "large" } },
  openGraph: {
    title: "Scorent | کشف کن، تجربه کن، بازی کن",
    description:
      "پلتفرم کشف و اجاره‌ی بازی؛ با دستیار هوشمند، کاتالوگ شفاف و اجاره‌ی ۱/۳/۷ روزه، قبل از خرید تجربه کن.",
    siteName: "Scorent",
    type: "website",
    locale: "fa_IR",
    url: SITE_BASE,
  },
  twitter: { card: "summary_large_image", title: "Scorent | کشف کن، تجربه کن، بازی کن" },
  // تأیید مالکیت Google Search Console از env — GOOGLE_SITE_VERIFICATION
  ...(process.env.GOOGLE_SITE_VERIFICATION ? { verification: { google: process.env.GOOGLE_SITE_VERIFICATION } } : {}),
};

export const viewport: Viewport = {
  themeColor: "#111318",
};

const GA4_ID = process.env.NEXT_PUBLIC_GA4_ID;

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <head>
        {/* تنظیم زبان/جهت/تم قبل از اولین رنگ‌آمیزی — جلوگیری از FOUC */}
        <script dangerouslySetInnerHTML={{ __html: UI_BOOT_SCRIPT }} />
        {/* Structured Data سازمان و وب‌سایت — سطح کل سایت */}
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(siteJsonLd()) }} />
      </head>
      <body className="antialiased bg-background text-foreground min-h-screen font-sans">
        <UiEffects>{children}</UiEffects>
        {/* Google Analytics 4 — فقط وقتی NEXT_PUBLIC_GA4_ID ست شده باشد */}
        {GA4_ID ? (
          <>
            <Script src={`https://www.googletagmanager.com/gtag/js?id=${GA4_ID}`} strategy="afterInteractive" />
            <Script id="ga4-init" strategy="afterInteractive">
              {`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${GA4_ID}',{anonymize_ip:true});`}
            </Script>
          </>
        ) : null}
      </body>
    </html>
  );
}
