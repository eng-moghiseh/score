/* robots.txt — صفحات خصوصی (APIها و پنل مدیریت) از ایندکس خارج می‌شوند.
 * پنل ادمین فقط نمای hash است و URL مستقل ندارد؛ مسیر /admin نیز بسته شده است. */

import type { MetadataRoute } from "next";
import { SITE_BASE } from "@/lib/seo";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/api/", "/admin"] }],
    sitemap: `${SITE_BASE}/sitemap.xml`,
  };
}
