/* ————— Seed خودکار: ادمین ارشد (فقط از env) + محتوای پیش‌فرض + کاتالوگ DB —————
 * idempotent — یک‌بار در هر فرایند اجرا می‌شود.
 *
 * سیاست امن ادمین (نسخه‌ی حاکم‌سازی‌شده — بدون هیچ اعتبارنامه‌ی تعبیه‌شده در سورس):
 *  1) ADMIN_EMAIL + ADMIN_PASSWORD در env → اگر هیچ SUPER_ADMIN وجود نداشته باشد ساخته می‌شود؛
 *     رمزهای عمومی/پیش‌فرض و ضعیف رد می‌شوند. اگر SUPER_ADMIN موجود باشد، env دست نمی‌زند.
 *  2) بدون env → هیچ حسابی ساخته نمی‌شود؛ استقرار تازه باید متغیرهای env را ست کند
 *     (DEPLOY.md را ببینید). این تصمیم عمدی است: رمز هرگز در سورس نمی‌ماند.
 * هر اقدام در لاگ حسابرسی ثبت می‌شود.
 */

import { createHmac, randomInt, timingSafeEqual } from "node:crypto";
import { db } from "@/lib/db";
import { authSecret } from "./session";
import { hashPassword, verifyPassword } from "./password";
import { audit } from "./audit";
import { DEFAULT_CONTENT } from "@/lib/site-content";
import { ensureCatalogSeed } from "./catalog-store";

/* رمزهای عمومی/نشتی‌یافته — هرگز برای provisioning استفاده نمی‌شوند */
const PUBLIC_DEFAULT_PASSWORDS = new Set(["scorent@2026!", "admin", "12345678", "password"]);
/** حداقل طول رمز ادمین هنگام provisioning */
const MIN_ADMIN_PASSWORD_LEN = 12;

let seeded: Promise<void> | null = null;

export function ensureSeed(): Promise<void> {
  if (!seeded) seeded = doSeed();
  return seeded;
}

async function doSeed(): Promise<void> {
  try {
    await provisionAdmin();
    await seedDefaultContent();
    await ensureCatalogSeed();
  } catch (e) {
    // در محیط بدون دیتابیس خطا ثبت می‌شود؛ مسیرها خودشان خطای DB را می‌دهند
    console.error("[seed]", e instanceof Error ? e.message : e);
    seeded = null; // اجازه‌ی تلاش مجدد
  }
}

async function seedDefaultContent(): Promise<void> {
  for (const row of DEFAULT_CONTENT) {
    await db.siteContent.upsert({
      where: { key: row.key },
      update: {},
      create: { key: row.key, valueFa: row.valueFa, valueEn: row.valueEn, updatedBy: "system" },
    });
  }
}

async function provisionAdmin(): Promise<void> {
  const envEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const envPassword = process.env.ADMIN_PASSWORD;
  const envName = process.env.ADMIN_NAME?.trim() || "مدیر ارشد Scorent";

  if (!envEmail || !envPassword) {
    // بدون env: هیچ حسابی ساخته نمی‌شود (هیچ اعتبارنامه‌ای در سورس وجود ندارد)
    const existingSuper = await db.user.findFirst({ where: { role: "SUPER_ADMIN" } });
    if (!existingSuper) {
      console.warn("[seed] No SUPER_ADMIN and no ADMIN_EMAIL/ADMIN_PASSWORD env — admin provisioning skipped. Set ADMIN_EMAIL and ADMIN_PASSWORD env for fresh deployments.");
    }
    return;
  }

  if (PUBLIC_DEFAULT_PASSWORDS.has(envPassword.toLowerCase()) || envPassword.length < MIN_ADMIN_PASSWORD_LEN) {
    console.error("[seed] ADMIN_PASSWORD is a publicly-known default or too short (<12) — refusing to provision with it. Choose a unique strong password.");
    return;
  }

  const existingSuper = await db.user.findFirst({ where: { role: "SUPER_ADMIN" } });
  if (existingSuper) {
    // ادمین ارشد موجود است — هیچ تغییری در استارتاپ انجام نمی‌شود
    return;
  }

  const byEmail = await db.user.findUnique({ where: { email: envEmail } });
  if (byEmail) {
    // ارتقای صریح حساب موجود به ادمین ارشد با اعتبارنامه‌ی env (قصد عملیات، نه reset خودکار)
    await db.user.update({
      where: { id: byEmail.id },
      data: { role: "SUPER_ADMIN", status: "ACTIVE", passwordHash: await hashPassword(envPassword) },
    });
    audit("ROLE_CHANGED", { actorId: null, target: byEmail.email, meta: "provisioned via ADMIN_EMAIL/ADMIN_PASSWORD" });
    return;
  }

  await db.user.create({
    data: {
      name: envName,
      email: envEmail,
      passwordHash: await hashPassword(envPassword),
      role: "SUPER_ADMIN",
      emailVerified: true,
      lang: "fa",
    },
  });
  audit("ADMIN_ADDED", { actorId: null, target: envEmail, meta: "provisioned via env on empty database" });
}

/* ————— OTP: تولید امن + هش HMAC + مقایسه‌ی زمان-امن ————— */

/** کد ۶ رقمی با منبع آنتروپی رمزنگارانه (هرگز Math.random) */
export function generateOtp(): string {
  return String(randomInt(100_000, 1_000_000));
}

/** هش HMAC-SHA256 کد با کلید نشست — بدون کلید عمومی قابل حدس */
export function hashOtp(code: string): string {
  return createHmac("sha256", authSecret()).update(`otp:${code}`).digest("hex");
}

/** مقایسه‌ی زمان-امن کد واردشده با هش ذخیره‌شده */
export function otpMatches(code: string, storedHash: string): boolean {
  const a = Buffer.from(hashOtp(code), "hex");
  let b: Buffer;
  try {
    b = Buffer.from(storedHash, "hex");
  } catch {
    return false;
  }
  return a.length === b.length && timingSafeEqual(a, b);
}

/* دفاع دفاعی: verifyPassword هنوز در seed استفاده نمی‌شود ولی export حفظ شده
 * تا مسیرهای چرخش رمز آینده بدون تغییر امضا کار کنند. */
export { verifyPassword as _verifyPasswordForRotation };
