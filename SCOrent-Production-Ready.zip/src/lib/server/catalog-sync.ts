/* ————— همگام‌سازی کاتالوگ سرور برای AI و ابزارهای سمت سرور —————
 * ابزارهای دستیار (catalog-tools) روی آرایه‌ی زنده‌ی GAMES کار می‌کنند.
 * این ماژول همان آرایه را از DB (GameRecord منتشرشده) به‌روز می‌کند تا
 * بازی‌های تازه‌منتشرشده‌ی ادمین بلافاصله به دستیار و موتور پیشنهاد می‌رسند.
 * خطا هرگز چت را نمی‌شکند — دیتاست ثابت fallback است.
 */

import { GAMES } from "@/lib/data/games";
import { ensureCatalogSeed, publicCatalog } from "./catalog-store";

let lastSync = 0;
const SYNC_TTL = 30_000;

export async function syncServerCatalog(force = false): Promise<void> {
  const now = Date.now();
  if (!force && now - lastSync < SYNC_TTL) return;
  try {
    await ensureCatalogSeed();
    const games = await publicCatalog();
    if (games.length > 0) {
      GAMES.length = 0;
      GAMES.push(...games);
    }
    lastSync = now;
  } catch (e) {
    console.error("[catalog-sync]", e instanceof Error ? e.message : e);
    lastSync = now; // از تلاش‌های پرتکرار جلوگیری می‌شود
  }
}
