/* ————— انبار کاتالوگ سمت سرور — GameRecord منبع حقیقت —————
 * Seed idempotent: بازی‌های دیتاست مرکزی → GameRecord (فقط اگر شناسه نباشد؛
 * هیچ ویرایش ادمین بازنویسی نمی‌شود). اورراید‌ها و بازی‌های سفارشی قدیمی یک‌بار
 * ادغام می‌شوند (مارکر SiteSetting) و هیچ داده‌ای گم نمی‌شود.
 */

import { db } from "@/lib/db";
import { isGameShape, sanitizeGameInput, lenientGame } from "@/lib/game-schema";
import type { Game } from "@/lib/types";
import { GAMES } from "@/lib/data/games";
import type { GameSource, GameStatus } from "@/lib/cms/types";

const MERGE_MARKER = "catalog.legacyMerged.v1";

export interface GameRecordView {
  id: string;
  game: Game;
  status: GameStatus;
  source: GameSource;
  deletedAt: string | null;
  scheduledAt: string | null;
  sortOrder: number;
  updatedAt: string;
  updatedBy: string | null;
  createdBy: string | null;
}

interface Row {
  id: string;
  data: string;
  status: string;
  source: string;
  deletedAt: Date | null;
  scheduledAt: Date | null;
  sortOrder: number;
  updatedAt: Date;
  updatedBy: string | null;
  createdBy: string | null;
}

function toView(row: Row): GameRecordView | null {
  try {
    const game = JSON.parse(row.data) as unknown;
    if (!isGameShape(game)) return null;
    return {
      id: row.id,
      game,
      status: (["PUBLISHED", "DRAFT", "ARCHIVED"].includes(row.status) ? row.status : "PUBLISHED") as GameStatus,
      source: row.source === "DATASET" ? "DATASET" : "CUSTOM",
      deletedAt: row.deletedAt?.toISOString() ?? null,
      scheduledAt: row.scheduledAt?.toISOString() ?? null,
      sortOrder: row.sortOrder,
      updatedAt: row.updatedAt.toISOString(),
      updatedBy: row.updatedBy,
      createdBy: row.createdBy,
    };
  } catch {
    return null;
  }
}

/** وضعیت عمومی: فقط PUBLISHED، غیرحذف‌شده و خارج از زمان‌بندی انتشار */
export function isPubliclyVisible(view: GameRecordView, now = new Date()): boolean {
  if (view.status !== "PUBLISHED" || view.deletedAt) return false;
  if (view.scheduledAt && new Date(view.scheduledAt).getTime() > now.getTime()) return false;
  return true;
}

/** Seed یک‌باره: دیتاست + ادغام اورراید/سفارشی‌های قدیمی — کاملاً idempotent */
export async function seedGamesFromDataset(): Promise<{ created: number; merged: number }> {
  let created = 0;
  let merged = 0;

  const existing = await db.gameRecord.findMany({ select: { id: true } });
  const have = new Set(existing.map((r) => r.id));

  // ۱) دیتاست مرکزی → رکورد (بدون بازنویسی رکورد موجود)
  for (const game of GAMES) {
    if (have.has(game.id)) continue;
    await db.gameRecord.create({
      data: { id: game.id, data: JSON.stringify(game), status: "PUBLISHED", source: "DATASET", createdBy: "system", updatedBy: "system" },
    });
    have.add(game.id);
    created++;
  }

  // ۲) ادغام یک‌باره‌ی اورراید‌ها و بازی‌های سفارشی قدیمی
  const marker = await db.siteSetting.findUnique({ where: { key: MERGE_MARKER } });
  if (!marker) {
    const [overrideRows, customRows] = await Promise.all([
      db.gameOverride.findMany(),
      db.customGame.findMany({ orderBy: { createdAt: "asc" } }),
    ]);

    for (const row of overrideRows) {
      let patch: Record<string, unknown>;
      try {
        patch = JSON.parse(row.data) as Record<string, unknown>;
      } catch {
        continue;
      }
      const rec = await db.gameRecord.findUnique({ where: { id: row.gameId } });
      if (!rec) continue; // اورراید برای بازی ناموجود — نادیده (هیچ داده‌ای گم نمی‌شود؛ ردیف اورراید باقی می‌ماند)
      try {
        const game = JSON.parse(rec.data) as Record<string, unknown>;
        const next = { ...game };
        if (typeof patch.taglineFa === "string" && patch.taglineFa.trim()) next.tagline = patch.taglineFa;
        if (typeof patch.taglineEn === "string" && patch.taglineEn.trim()) next.taglineEn = patch.taglineEn;
        if (typeof patch.descriptionFa === "string" && patch.descriptionFa.trim()) next.description = patch.descriptionFa;
        if (typeof patch.descriptionEn === "string" && patch.descriptionEn.trim()) next.descriptionEn = patch.descriptionEn;
        if (typeof patch.featured === "boolean") next.featured = patch.featured;
        if (typeof patch.discountPct === "number") {
          const originalPrice = Number(next.originalPrice) || Number(next.price) || 0;
          const price = Math.max(1000, Math.round(((originalPrice * (100 - Math.max(0, Math.min(90, patch.discountPct)))) / 100) / 1000) * 1000);
          next.price = price;
          next.originalPrice = originalPrice;
        }
        const status = patch.hidden === true ? "ARCHIVED" : rec.status;
        await db.gameRecord.update({ where: { id: rec.id }, data: { data: JSON.stringify(next), status, updatedBy: row.updatedBy ?? "legacy-override" } });
        merged++;
      } catch {
        continue;
      }
    }

    for (const row of customRows) {
      if (have.has(row.id)) continue;
      await db.gameRecord.create({
        data: {
          id: row.id,
          data: row.data,
          status: "PUBLISHED",
          source: "CUSTOM",
          createdBy: row.createdBy ?? row.updatedBy ?? "legacy-custom",
          updatedBy: row.updatedBy ?? row.createdBy ?? "legacy-custom",
          createdAt: row.createdAt,
        },
      });
      have.add(row.id);
      created++;
    }

    await db.siteSetting.create({ data: { key: MERGE_MARKER, value: new Date().toISOString(), updatedBy: "system" } });
  }

  return { created, merged };
}

/** همه‌ی رکوردها برای پنل ادمین — شامل آرشیو/حذف‌شده */
export async function listAllRecords(): Promise<GameRecordView[]> {
  const rows = await db.gameRecord.findMany({ orderBy: [{ sortOrder: "asc" }, { updatedAt: "desc" }] });
  return rows.map(toView).filter((v): v is GameRecordView => v !== null);
}

/** کاتالوگ عمومی */
export async function publicCatalog(now = new Date()): Promise<Game[]> {
  const rows = await db.gameRecord.findMany({ where: { deletedAt: null }, orderBy: [{ sortOrder: "asc" }, { updatedAt: "desc" }] });
  return rows
    .map(toView)
    .filter((v): v is GameRecordView => v !== null && isPubliclyVisible(v, now))
    .map((v) => v.game);
}

/** یک بازی با هر وضعیتی (پنل ادمین) */
export async function getRecord(id: string): Promise<GameRecordView | null> {
  const row = await db.gameRecord.findUnique({ where: { id } });
  return row ? toView(row) : null;
}

/** ذخیره‌ی امن داده‌ی کامل بازی (سرور-ساید sanitize) — موجودی‌ها حفظ می‌شوند */
export async function saveGame(id: string, raw: unknown, meta: { source?: GameSource; status?: GameStatus; actor?: string }): Promise<GameRecordView> {
  const parsed = sanitizeGameInput(typeof raw === "object" && raw !== null ? { ...(raw as Record<string, unknown>), id } : { id });
  if (!parsed.ok) {
    const e = new Error("INVALID_INPUT") as Error & { code?: string; errors?: string[] };
    e.code = "INVALID_INPUT";
    e.errors = parsed.errors;
    throw e;
  }
  const existing = await db.gameRecord.findUnique({ where: { id } });
  const status = meta.status ?? existing?.status ?? "PUBLISHED";
  const row = await db.gameRecord.upsert({
    where: { id },
    update: { data: JSON.stringify(parsed.game), status, updatedBy: meta.actor ?? null },
    create: {
      id,
      data: JSON.stringify(parsed.game),
      status,
      source: meta.source ?? "CUSTOM",
      createdBy: meta.actor ?? null,
      updatedBy: meta.actor ?? null,
    },
  });
  return toView(row)!;
}

/** خواندن چند بازی بر اساس شناسه (برای AI و بلوک‌ها) */
export async function gamesByIds(ids: string[]): Promise<Game[]> {
  if (ids.length === 0) return [];
  const rows = await db.gameRecord.findMany({ where: { id: { in: ids }, deletedAt: null } });
  const views = rows.map(toView).filter((v): v is GameRecordView => v !== null && isPubliclyVisible(v));
  const byId = new Map(views.map((v) => [v.id, v.game]));
  return ids.map((id) => byId.get(id)).filter((g): g is Game => g !== undefined);
}

/** fallback سراسری: کاتالوگ زنده؛ اگر DB خطا داد از دیتاست ثابت استفاده می‌شود تا سایت هرگز نشکند */
export async function safePublicCatalog(): Promise<Game[]> {
  try {
    const list = await publicCatalog();
    return list.length > 0 ? list : [...GAMES.map((g) => ({ ...g }))];
  } catch {
    return GAMES.map((g) => ({ ...g }));
  }
}

/** خالص: پالایه‌ی lenient برای نمایش پیش‌نمایش در پنل */
export function previewGame(raw: unknown): Game {
  return lenientGame(raw);
}

/* ————— memoized one-time seed (در هر فرایند فقط یک تلاش جدی) ————— */

let seedOnce: Promise<{ created: number; merged: number }> | null = null;

/** تضمین seed کاتالوگ — قبل از هر خواندن پنل/کاتالوگ؛ خطا را بلع می‌طلعه از درخواست عبور می‌کند */
export async function ensureCatalogSeed(): Promise<void> {
  if (!seedOnce) {
    seedOnce = seedGamesFromDataset().catch((e) => {
      console.error("[catalog-seed]", e instanceof Error ? e.message : e);
      seedOnce = null;
      return { created: 0, merged: 0 };
    });
  }
  await seedOnce;
}
