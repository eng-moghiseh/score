/* ————— کمکی‌های داده‌ی پنل مدیریت: سبدبندی روند روزانه + سازنده‌ی CSV —————
 * توابع محض (بدون وابستگی) برای تست‌پذیری.
 */

/** تعداد رخداد در هر یک از N روز گذشته (قدیمی‌ترین → جدیدترین، شامل امروز؛ بر پایه‌ی ساعت سرور) */
export function countPerDay(isos: Array<string | Date>, days: number, now: Date = new Date()): number[] {
  const safeDays = Math.max(1, Math.min(90, Math.round(days)));
  const start = new Date(now);
  start.setHours(0, 0, 0, 0);
  start.setDate(start.getDate() - (safeDays - 1));
  const out = new Array<number>(safeDays).fill(0);
  for (const raw of isos) {
    const t = raw instanceof Date ? raw.getTime() : new Date(raw).getTime();
    if (!Number.isFinite(t)) continue;
    const day = new Date(t);
    day.setHours(0, 0, 0, 0);
    const diff = Math.floor((day.getTime() - start.getTime()) / 86_400_000);
    if (diff >= 0 && diff < safeDays) out[diff] += 1;
  }
  return out;
}

/** برچسب «ماه-روز» برای N روز گذشته — موازی با خروجی countPerDay */
export function dayLabels(days: number, now: Date = new Date()): string[] {
  const safeDays = Math.max(1, Math.min(90, Math.round(days)));
  const start = new Date(now);
  start.setHours(0, 0, 0, 0);
  start.setDate(start.getDate() - (safeDays - 1));
  return Array.from({ length: safeDays }, (_, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    return d.toISOString().slice(5, 10);
  });
}

/** گریز استاندارد یک فیلد CSV: نقل‌قول در صورت نیاز + دوبل‌کردن " */
export function csvField(v: unknown): string {
  const s = v === null || v === undefined ? "" : String(v);
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** ساخت CSV از ردیف‌های آرایه‌ای */
export function toCsv(rows: unknown[][]): string {
  return rows.map((r) => r.map(csvField).join(",")).join("\r\n");
}
