/* ————— لایه SEO: متادیتای هر مسیر + Structured Data + اسکریپت بوت مسیر —————
 * سایت SPA مبتنی بر hash است؛ برای اینکه گوگل بتواند صفحات واقعی را با URL
 * اختصاصی ایندکس کند، middleware مسیرهای عمومی (مثل /game/:id) را به «/» با
 * پارامتر ‎_route بازنویسی می‌کند و این ماژول متادیتا و JSON-LD همان نما را
 * سمت سرور تولید می‌کند. اسکریپت بوت، ‎_route را قبل از hydration به hash
 * تبدیل می‌کند تا رفتار روتر موجود صددرصد حفظ شود.
 */

import type { Metadata } from "next";
import { publicCatalog } from "@/lib/server/catalog-store";
import { db } from "@/lib/db";

export const SITE_BASE = process.env.SITE_URL || "https://scorent.space-z.ai";

/* مسیرهای عمومی — فقط این‌ها URL قابل ایندکس دارند؛ مسیرهای خصوصی
 * (profile/settings/admin/auth/…) عمداً در sitemap و rewrite نیستند. */
const STATIC_ROUTES: Record<string, { title: string; description: string }> = {
  "/store": { title: "فروشگاه بازی‌ها | کشف، خرید و اجاره", description: "کاتالوگ کامل بازی‌های Scorent با فیلترهای پویا: بر اساس ژانر، پلتفرم، قیمت و امتیاز جست‌وجو کن؛ اول اجاره کن، بعد با خیال راحت خرید کن." },
  "/rent": { title: "اجاره‌ی بازی | ۱، ۳ و ۷ روزه", description: "بازی‌های مورد علاقه‌ات را برای ۱، ۳ یا ۷ روز اجاره بگیر؛ قیمت شفاف، تحویل سریع و امکان تجربه قبل از خرید." },
  "/ai": { title: "دستیار هوشمند بازی", description: "دستیار هوشمند Scorent متصل به کاتالوگ واقعی: بر اساس سلیقه، بودجه و زمانت بازی بعدی‌ات را پیشنهاد می‌دهد." },
  "/ai-chat": { title: "گفت‌وگو با دستیار هوشمند", description: "با دستیار هوشمند گیمینگ Scorent گفت‌وگو کن؛ پیشنهاد بازی، مقایسه و پاسخ به سؤالات از دل کاتالوگ واقعی." },
  "/discovery": { title: "کشف بازی | پیشنهاد شفاف", description: "موتور پیشنهاد شفاف Scorent: بازی‌های مناسب سلیقه‌ات را کشف کن؛ منطق پیشنهاد کاملاً قابل مشاهده است." },
  "/deals": { title: "تخفیف‌ها و پیشنهادهای ویژه", description: "بازی‌های تخفیف‌دار و پیشنهادهای ویژه‌ی Scorent — قیمت‌های واقعی و به‌روز از کاتالوگ." },
  "/trial": { title: "تجربه‌ی بازی | اول امتحان کن", description: "قبل از خرید، بازی را تجربه کن؛ نسخه‌ی آزمایشی و اجاره‌ی کوتاه‌مدت در Scorent." },
  "/rewards": { title: "امتیازها و پاداش‌ها", description: "سیستم XP و پاداش‌های Scorent: با فعالیت در سایت امتیاز جمع کن و مزایا بگیر." },
  "/share": { title: "اشتراک‌گذاری و پروفایل عمومی", description: "کالکشن، علاقه‌مندی‌ها و تجربه‌های بازی‌ات را با دیگران به اشتراک بگذار." },
  "/support": { title: "پشتیبانی | سؤالات و تیکت", description: "مرکز پشتیبانی Scorent: سؤالات متداول و سیستم تیکت برای پاسخ سریع تیم پشتیبانی." },
};

/* اسکریپت بوت: ‎_route را قبل از hydration به hash روتر تبدیل می‌کند */
export const ROUTE_BOOT_SCRIPT = `(function(){try{var p=new URLSearchParams(location.search).get("_route");if(p&&p.charAt(0)==="/"){history.replaceState(null,"","/"+(p.length>1?"#"+p:""));}}catch(e){}})();`;

function absoluteImg(src: string | undefined): string | undefined {
  if (!src) return undefined;
  if (src.startsWith("https://") || src.startsWith("http://")) return src;
  if (src.startsWith("/") || src.startsWith("/api/")) return `${SITE_BASE}${src}`;
  return undefined; // data:/blob: برای OG مناسب نیست
}

function metaFor(route: string | undefined, game?: Awaited<ReturnType<typeof getGame>>, pageTitle?: string, pageDescription?: string): Metadata {
  const isGame = route?.startsWith("/game/");
  const isPage = route?.startsWith("/p/");
  const staticMeta = route ? STATIC_ROUTES[route] : undefined;

  const title = game ? `${game.title} | خرید و اجاره` : pageTitle ?? staticMeta?.title;
  const description = game ? game.tagline : pageDescription ?? staticMeta?.description;
  const canonical = game ? `${SITE_BASE}/game/${game.id}` : isPage ? `${SITE_BASE}${route}` : route ? `${SITE_BASE}${route}` : SITE_BASE;
  const ogImage = game ? absoluteImg(game.coverUrl) : undefined;

  return {
    title: title ?? undefined,
    description,
    alternates: { canonical },
    robots: { index: Boolean(game || isPage || staticMeta), follow: true },
    openGraph: {
      title: title ?? undefined,
      description,
      url: canonical,
      siteName: "Scorent",
      locale: "fa_IR",
      type: "website",
      images: ogImage ? [{ url: ogImage, width: 920, height: 1300, alt: game?.title }] : undefined,
    },
    twitter: { card: ogImage ? "summary_large_image" : "summary", title: title ?? undefined, description, images: ogImage ? [ogImage] : undefined },
  };
}

export interface RouteMetaInput {
  route?: string | string[];
}

export async function routeMetadata(route?: string | string[]): Promise<Metadata> {
  const r = Array.isArray(route) ? route[0] : route;
  if (r?.startsWith("/game/")) {
    const game = await getGame(r.slice("/game/".length));
    if (game) return metaFor(r, game);
    return { robots: { index: false, follow: true } };
  }
  if (r?.startsWith("/p/")) {
    const page = await getPage(r.slice("/p/".length));
    if (page) return metaFor(r, undefined, page.title, page.description);
    return { robots: { index: false, follow: true } };
  }
  if (r && !STATIC_ROUTES[r]) return { robots: { index: false, follow: true } };
  return metaFor(r);
}

/* ————— JSON-LD ————— */

export async function routeJsonLd(route?: string | string[]): Promise<Record<string, unknown> | null> {
  const r = Array.isArray(route) ? route[0] : route;
  if (!r?.startsWith("/game/")) return null;
  const game = await getGame(r.slice("/game/".length));
  if (!game) return null;
  const url = `${SITE_BASE}/game/${game.id}`;
  const ld: Record<string, unknown> = {
    "@context": "https://schema.org",
    "@type": "VideoGame",
    name: game.title,
    description: game.tagline,
    url,
    inLanguage: "fa-IR",
    breadcrumb: {
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "خانه", item: SITE_BASE },
        { "@type": "ListItem", position: 2, name: "فروشگاه", item: `${SITE_BASE}/store` },
        { "@type": "ListItem", position: 3, name: game.title, item: url },
      ],
    },
  };
  if (game.coverUrl) {
    const img = absoluteImg(game.coverUrl);
    if (img) ld.image = img;
  }
  if (Number.isFinite(game.price) && game.price > 0) {
    // قیمت‌های سایت تومان است؛ در Schema.org ارز رسمی IRR ثبت می‌شود (۱ تومان = ۱۰ ریال)
    ld.offers = {
      "@type": "Offer",
      price: Math.round(game.price * 10),
      priceCurrency: "IRR",
      availability: "https://schema.org/InStock",
      url,
    };
  }
  return ld;
}

/* Organization + WebSite برای کل سایت — در layout رندر می‌شود */
export function siteJsonLd(): Record<string, unknown> {
  return {
    "@context": "https://schema.org",
    "@graph": [
      { "@type": "Organization", name: "Scorent", url: SITE_BASE, applicationCategory: "GameApplication" },
      {
        "@type": "WebSite",
        name: "Scorent",
        url: SITE_BASE,
        inLanguage: ["fa-IR", "en"],
        potentialAction: { "@type": "SearchAction", target: `${SITE_BASE}/store?q={search_term_string}`, "query-input": "required name=search_term_string" },
      },
    ],
  };
}

/* ————— خواندن داده‌ی واقعی از دیتابیس ————— */

async function getGame(id: string): Promise<{ id: string; title: string; tagline: string; coverUrl?: string; price: number } | null> {
  try {
    const games = await publicCatalog();
    const g = games.find((x) => x.id === id);
    if (!g || !g.title) return null;
    return { id: g.id, title: g.title, tagline: g.tagline || g.title, coverUrl: g.coverUrl, price: Number(g.price) || 0 };
  } catch {
    return null;
  }
}

async function getPage(slug: string): Promise<{ title: string; description?: string } | null> {
  try {
    const p = await db.page.findFirst({ where: { slug, status: "PUBLISHED" }, select: { titleFa: true, titleEn: true } });
    if (!p) return null;
    return { title: p.titleFa || p.titleEn || slug };
  } catch {
    return null;
  }
}
