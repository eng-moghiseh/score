/* ————— تنظیمات سراسری CMS — schema، پیش‌فرض‌ها و پالایه ————— */

import { safeImageUrl } from "./types";

export interface SiteSettings {
  /** حالت نگه‌داری — سایت عمومی غیر-کارمندان پیام نگه‌داری می‌بینند */
  maintenanceMode: boolean;
  maintenanceFa: string;
  maintenanceEn: string;
  /** حالت نمایشی — بنر شبیه‌سازی‌شدن تراکنش‌ها */
  demoMode: boolean;
  defaultLang: "fa" | "en";
  currencyFa: string;
  currencyEn: string;
  contactEmail: string;
  contactPhone: string;
  contactAddressFa: string;
  contactAddressEn: string;
  socialInstagram: string;
  socialTelegram: string;
  socialX: string;
  socialDiscord: string;
  seoTitleFa: string;
  seoTitleEn: string;
  seoDescFa: string;
  seoDescEn: string;
  seoKeywords: string;
  ogImage: string;
  /** اجاره */
  rentalEnabled: boolean;
  rentalCommissionPct: number;
  /** فروشگاه */
  storeEnabled: boolean;
  minPrice: number;
  maxPrice: number;
}

export const DEFAULT_SETTINGS: SiteSettings = {
  maintenanceMode: false,
  maintenanceFa: "سایت موقتاً در دست تعمیر است؛ به‌زودی برمی‌گردیم.",
  maintenanceEn: "The site is temporarily under maintenance; we'll be back soon.",
  demoMode: true,
  defaultLang: "fa",
  currencyFa: "تومان",
  currencyEn: "Toman",
  contactEmail: "",
  contactPhone: "",
  contactAddressFa: "",
  contactAddressEn: "",
  socialInstagram: "",
  socialTelegram: "",
  socialX: "",
  socialDiscord: "",
  seoTitleFa: "Scorent | کشف کن، تجربه کن، بازی کن",
  seoTitleEn: "Scorent | Discover. Experience. Play.",
  seoDescFa: "پلتفرم کشف، اجاره و خرید بازی با دستیار هوشمند و پیشنهاد شفاف — اول تجربه کن، بعد انتخاب کن.",
  seoDescEn: "Discover, rent and buy games with an AI assistant and transparent recommendations — try first, then buy.",
  seoKeywords: "بازی، اجاره بازی، خرید بازی، Scorent، game rental",
  ogImage: "",
  rentalEnabled: true,
  rentalCommissionPct: 10,
  storeEnabled: true,
  minPrice: 100_000,
  maxPrice: 2_500_000,
};

/** کلیدهای مجاز — هر چیز دیگر نادیده گرفته می‌شود */
export const SETTING_KEYS = Object.keys(DEFAULT_SETTINGS) as (keyof SiteSettings)[];

export type SettingsValidation = { ok: true; settings: SiteSettings } | { ok: false; errors: string[] };

/** پالایه‌ی تنظیمات دریافتی از ادمین */
export function sanitizeSettings(raw: unknown): SettingsValidation {
  if (typeof raw !== "object" || raw === null) return { ok: false, errors: ["ERR_NOT_OBJECT"] };
  const r = raw as Record<string, unknown>;
  const errors: string[] = [];
  const out: SiteSettings = { ...DEFAULT_SETTINGS };
  const bool = (v: unknown) => v === true || v === "true" || v === 1;
  const str = (v: unknown, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : undefined);
  const num = (v: unknown, min: number, max: number) => {
    const n = Number(v);
    return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : undefined;
  };

  if (r.maintenanceMode !== undefined) out.maintenanceMode = bool(r.maintenanceMode);
  if (r.demoMode !== undefined) out.demoMode = bool(r.demoMode);
  if (r.rentalEnabled !== undefined) out.rentalEnabled = bool(r.rentalEnabled);
  if (r.storeEnabled !== undefined) out.storeEnabled = bool(r.storeEnabled);

  for (const key of ["maintenanceFa", "maintenanceEn", "contactAddressFa", "contactAddressEn", "seoDescFa", "seoDescEn", "seoKeywords"] as const) {
    if (r[key] !== undefined) {
      const v = str(r[key], 600);
      if (v !== undefined) out[key] = v;
    }
  }
  for (const key of ["contactEmail", "contactPhone", "socialInstagram", "socialTelegram", "socialX", "socialDiscord"] as const) {
    if (r[key] !== undefined) {
      const v = str(r[key], 200);
      if (v !== undefined) out[key] = v;
    }
  }
  if (r.contactEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(out.contactEmail)) errors.push("ERR_CONTACT_EMAIL");
  for (const key of ["socialInstagram", "socialTelegram", "socialX", "socialDiscord"] as const) {
    if (out[key] && !/^https?:\/\/[^\s"'<>]+$/i.test(out[key])) errors.push(`ERR_SOCIAL:${key}`);
  }

  if (typeof r.defaultLang === "string" && /^(fa|en)$/i.test(r.defaultLang.trim())) {
    out.defaultLang = r.defaultLang.trim().toLowerCase() === "en" ? "en" : "fa";
  }
  const cur = (key: "currencyFa" | "currencyEn") => {
    if (r[key] !== undefined) {
      const v = str(r[key], 20);
      if (v) out[key] = v;
    }
  };
  cur("currencyFa");
  cur("currencyEn");

  const seoTitle = (key: "seoTitleFa" | "seoTitleEn") => {
    if (r[key] !== undefined) {
      const v = str(r[key], 120);
      if (v) out[key] = v;
    }
  };
  seoTitle("seoTitleFa");
  seoTitle("seoTitleEn");

  if (r.ogImage !== undefined) {
    const v = safeImageUrl(r.ogImage);
    if (v !== null) out.ogImage = v;
    else if (typeof r.ogImage === "string" && r.ogImage.trim() !== "") errors.push("ERR_OG_IMAGE");
  }

  const rentalPct = num(r.rentalCommissionPct, 0, 50);
  if (rentalPct !== undefined) out.rentalCommissionPct = rentalPct;
  const minP = num(r.minPrice, 0, 1_000_000_000);
  if (minP !== undefined) out.minPrice = minP;
  const maxP = num(r.maxPrice, 0, 1_000_000_000);
  if (maxP !== undefined) out.maxPrice = maxP;
  if (out.minPrice > out.maxPrice) errors.push("ERR_PRICE_RANGE");

  return errors.length ? { ok: false, errors } : { ok: true, settings: out };
}

/** خواندن JSON تنظیمات با گارد */
export function parseSettings(rows: { key: string; value: string }[]): SiteSettings {
  const out: Record<string, unknown> = {};
  for (const row of rows) {
    if (!SETTING_KEYS.includes(row.key as keyof SiteSettings)) continue;
    try {
      out[row.key] = JSON.parse(row.value);
    } catch {
      /* مقدار خراب نادیده گرفته می‌شود */
    }
  }
  const parsed = sanitizeSettings(out);
  return parsed.ok ? parsed.settings : DEFAULT_SETTINGS;
}
