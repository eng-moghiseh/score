/* ————— موتور فیلتر پویا — خالص و تست‌پذیر —————
 * تعریف فیلترها از DB می‌آید (FilterDefinition) و این موتور آن‌ها را روی
 * آرایه‌ی Game اجرا می‌کند. هیچ تعریف hardcode در مسیر اصلی نیست.
 * URL params → FilterValues → applyFilters → Game[]
 */

import type { FilterDef, FilterOption } from "./types";
import type { Game } from "@/lib/types";
import { finalPrice } from "@/lib/pricing";

export type { FilterDef, FilterMeta, FilterOption } from "./types";

export type FilterValue = string | number | boolean | [number, number] | string[] | null;

export type FilterValues = Record<string, FilterValue>;

/** مقادیر URL (?key=v&key=min-max) → FilterValues typed */
export function parseFilterParams(defs: FilterDef[], params: URLSearchParams): FilterValues {
  const values: FilterValues = {};
  for (const def of defs) {
    const raw = params.get(def.key);
    if (raw === null || raw === "") continue;
    const v = parseValue(def, raw);
    if (v !== null) values[def.key] = v;
  }
  return values;
}

function parseValue(def: FilterDef, raw: string): FilterValue | null {
  switch (def.type) {
    case "text":
      return raw.slice(0, 80);
    case "number":
    case "rating": {
      const n = Number(raw);
      return Number.isFinite(n) ? n : null;
    }
    case "range":
    case "daterange":
    case "price": {
      const m = /^(-?[\d.]+)\.\.(-?[\d.]+)$/.exec(raw);
      if (!m) return null;
      const a = Number(m[1]);
      const b = Number(m[2]);
      if (!Number.isFinite(a) || !Number.isFinite(b)) return null;
      return [a, b];
    }
    case "boolean":
      return raw === "1" || raw === "true";
    case "select":
      return raw.slice(0, 120);
    case "multiselect": {
      const list = raw.split(",").map((s) => s.slice(0, 120)).filter(Boolean).slice(0, 30);
      return list.length ? list : null;
    }
    default:
      return null;
  }
}

/** FilterValues → URL params (برای هم‌رسانی لینک) */
export function filtersToParams(defs: FilterDef[], values: FilterValues): Record<string, string> {
  const out: Record<string, string> = {};
  for (const def of defs) {
    const v = values[def.key];
    if (v === null || v === undefined || v === "" || v === false) continue;
    if (Array.isArray(v)) {
      if (v.length === 2 && typeof v[0] === "number" && typeof v[1] === "number") {
        if (def.type === "price" && v[1] >= (def.meta.max ?? Number.MAX_SAFE_INTEGER)) continue;
        out[def.key] = `${v[0]}..${v[1]}`;
      } else if (v.length > 0) {
        out[def.key] = v.join(",");
      }
    } else if (v === true) {
      out[def.key] = "1";
    } else if (typeof v === "number") {
      if (def.type === "price" && v >= (def.meta.max ?? Number.MAX_SAFE_INTEGER)) continue;
      if (def.type === "rating" && v <= 0) continue;
      out[def.key] = String(v);
    } else {
      out[def.key] = String(v);
    }
  }
  return out;
}

function fieldOf(game: Game, def: FilterDef): unknown {
  const field = def.meta.field ?? def.key;
  if (field === "price") return finalPrice(game);
  if (field === "discount") return game.discountPercent;
  if (field === "popularity") return game.popularity;
  if (field === "rentalAvailable") return game.rentalAvailable;
  const rec = game as unknown as Record<string, unknown>;
  return rec[field];
}

function asNumber(v: unknown): number | null {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function includesFold(hay: unknown, needle: string): boolean {
  if (typeof hay === "string") return hay.toLowerCase().includes(needle.toLowerCase());
  if (Array.isArray(hay)) return hay.some((x) => typeof x === "string" && x.toLowerCase().includes(needle.toLowerCase()));
  return false;
}

function optionLabel(def: FilterDef, value: string, lang: "fa" | "en"): string {
  const opt = def.options.find((o) => o.value === value);
  if (!opt) return value;
  return lang === "en" ? opt.labelEn || opt.labelFa : opt.labelFa;
}

/** یک فیلتر واحد روی یک بازی — برای شمارش per-option هم استفاده می‌شود */
export function matchFilter(game: Game, def: FilterDef, value: FilterValue): boolean {
  if (value === null || value === undefined || value === "" || value === false) return true;
  const field = fieldOf(game, def);
  switch (def.type) {
    case "text":
      return typeof value === "string" ? includesFold(field, value) : true;
    case "number": {
      const n = asNumber(field);
      return n !== null && typeof value === "number" ? n === value : true;
    }
    case "range":
    case "daterange":
    case "price": {
      if (!Array.isArray(value) || typeof value[0] !== "number" || typeof value[1] !== "number") return true;
      const n = asNumber(field);
      return n !== null && n >= value[0] && n <= value[1];
    }
    case "boolean":
      return field === true;
    case "select":
      return typeof value === "string" ? String(field ?? "") === value : true;
    case "multiselect": {
      if (!Array.isArray(value) || value.length === 0) return true;
      const hay = Array.isArray(field) ? field.map(String) : [String(field ?? "")];
      return value.some((v) => hay.includes(v));
    }
    case "rating": {
      const n = asNumber(field);
      return n !== null && typeof value === "number" ? n >= value : true;
    }
    default:
      return true;
  }
}

/** موتور اصلی: همه‌ی فیلترهای فعال با AND ترکیب می‌شوند */
export function applyFilters(games: Game[], defs: FilterDef[], values: FilterValues): Game[] {
  const active = defs.filter((d) => {
    const v = values[d.key];
    return v !== null && v !== undefined && v !== "" && v !== false && !(Array.isArray(v) && v.length === 0);
  });
  if (active.length === 0) return games;
  return games.filter((g) => active.every((d) => matchFilter(g, d, values[d.key])));
}

/** شمارش نتایج هر گزینه ( برای نمایش تعداد کنار گزینه‌ها) — فیلترهای دیگر اعمال شده */
export function countOptions(
  games: Game[],
  def: FilterDef,
  defs: FilterDef[],
  values: FilterValues,
): Record<string, number> {
  const others = defs.filter((d) => d.id !== def.id);
  const rest = applyFilters(games, others, values);
  const counts: Record<string, number> = {};
  if (def.type === "select" || def.type === "multiselect") {
    for (const opt of def.options) counts[opt.value] = rest.filter((g) => matchFilter(g, def, [opt.value])).length;
  }
  return counts;
}

/** لیبل فارسی/انگلیسی مقدار انتخاب‌شده — برای چیپ‌های فعال */
export function valueLabel(def: FilterDef, value: FilterValue, lang: "fa" | "en"): string {
  if (Array.isArray(value)) {
    if (typeof value[0] === "number") return `${value[0]} – ${value[1]}`;
    return value.map((v) => optionLabel(def, String(v), lang)).join("، ");
  }
  if (typeof value === "boolean") return lang === "fa" ? "بله" : "Yes";
  if (typeof value === "number") return String(value);
  return optionLabel(def, String(value), lang);
}

/** مرتب‌سازی پیشرفته — همیشه روی کپی اجرا می‌شود */
export type SortKey = "popular" | "rating" | "price-asc" | "price-desc" | "discount" | "newest" | "year-desc";

export function sortGames(games: Game[], sort: SortKey): Game[] {
  const list = [...games];
  switch (sort) {
    case "rating":
      return list.sort((a, b) => b.rating - a.rating);
    case "price-asc":
      return list.sort((a, b) => finalPrice(a) - finalPrice(b));
    case "price-desc":
      return list.sort((a, b) => finalPrice(b) - finalPrice(a));
    case "discount":
      return list.sort((a, b) => b.discountPercent - a.discountPercent);
    case "newest":
      return list.sort((a, b) => b.year - a.year || b.popularity - a.popularity);
    case "year-desc":
      return list.sort((a, b) => b.year - a.year);
    default:
      return list.sort((a, b) => b.popularity - a.popularity);
  }
}

/** صفحه‌بندی ساده */
export function paginate<T>(list: T[], page: number, perPage: number): { items: T[]; total: number; pages: number; page: number } {
  const total = list.length;
  const pages = Math.max(1, Math.ceil(total / perPage));
  const p = Math.min(Math.max(1, page), pages);
  return { items: list.slice((p - 1) * perPage, p * perPage), total, pages, page: p };
}
