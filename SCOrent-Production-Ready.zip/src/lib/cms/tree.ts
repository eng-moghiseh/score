/* ————— ابزارهای درخت (رده‌ها و ناوبری) — خالص و تست‌پذیر ————— */

import type { CategoryNode, NavNode } from "./types";

interface FlatLike {
  id: string;
  parentId: string | null;
  order: number;
}

/** ساخت درخت از لیست تخت — حلقه‌ها (ن paradox) قطع و بلاک‌های یتیم نادیده گرفته می‌شوند */
export function buildTree<T extends FlatLike, U = T>(flat: T[], attach: (item: T, children: U[]) => U): U[] {
  interface Wrap {
    item: T;
    children: Wrap[];
  }
  const byId = new Map<string, Wrap>();
  for (const item of flat) byId.set(item.id, { item, children: [] });
  const roots: Wrap[] = [];
  for (const item of flat) {
    const node = byId.get(item.id)!;
    const parent = item.parentId ? byId.get(item.parentId) : undefined;
    if (!item.parentId || !parent || parent.item.id === item.id) roots.push(node);
    else parent.children.push(node);
  }
  const wire = (nodes: Wrap[]): U[] =>
    nodes
      .sort((a, b) => a.item.order - b.item.order)
      .map((n) => attach(n.item, wire(n.children)));
  return wire(roots);
}

export function categoryToNode(c: {
  id: string;
  slug: string;
  nameFa: string;
  nameEn: string;
  descFa: string | null;
  descEn: string | null;
  icon: string | null;
  image: string | null;
  seoFa: string | null;
  seoEn: string | null;
  parentId: string | null;
  order: number;
  enabled: boolean;
}): CategoryNode {
  return {
    id: c.id,
    slug: c.slug,
    nameFa: c.nameFa,
    nameEn: c.nameEn,
    descFa: c.descFa,
    descEn: c.descEn,
    icon: c.icon,
    image: c.image,
    seoFa: c.seoFa,
    seoEn: c.seoEn,
    parentId: c.parentId,
    order: c.order,
    enabled: c.enabled,
    children: [],
  };
}

export function navToNode(n: {
  id: string;
  location: string;
  parentId: string | null;
  labelFa: string;
  labelEn: string;
  href: string;
  icon: string | null;
  descFa: string | null;
  descEn: string | null;
  order: number;
  enabled: boolean;
  newTab: boolean;
}): NavNode {
  return {
    id: n.id,
    location: n.location,
    parentId: n.parentId,
    labelFa: n.labelFa,
    labelEn: n.labelEn,
    href: n.href,
    icon: n.icon,
    descFa: n.descFa,
    descEn: n.descEn,
    order: n.order,
    enabled: n.enabled,
    newTab: n.newTab,
    children: [],
  };
}

/** تخت‌سازی درخت با ترتیب DFS — برای drag-drop reorder */
export function flattenTree<T extends { children: T[] }>(nodes: T[]): T[] {
  const out: T[] = [];
  const walk = (list: T[]) => {
    for (const n of list) {
      out.push(n);
      if (n.children?.length) walk(n.children);
    }
  };
  walk(nodes);
  return out;
}

/** جلوگیری از حلقه در والد پذیری: آیا movingId جدّ ancestor است؟ */
export function wouldCycle(flat: { id: string; parentId: string | null }[], movingId: string, newParentId: string | null): boolean {
  if (!newParentId) return false;
  if (movingId === newParentId) return true;
  const byId = new Map(flat.map((f) => [f.id, f.parentId]));
  let cur: string | null = newParentId;
  const guard = new Set<string>();
  while (cur) {
    if (cur === movingId) return true;
    if (guard.has(cur)) return true;
    guard.add(cur);
    cur = byId.get(cur) ?? null;
  }
  return false;
}
