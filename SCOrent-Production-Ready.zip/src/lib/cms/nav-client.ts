"use client";

/* ————— کلاینت ناوبری CMS — منوهای دیتابیس با fallback ثابت ————— */

import { create } from "zustand";
import { useEffect } from "react";
import type { NavNode } from "./types";

interface NavState {
  byLocation: Record<string, NavNode[]>;
  loaded: boolean;
}

export const useNavStore = create<NavState>()(() => ({ byLocation: {}, loaded: false }));

async function load(): Promise<void> {
  try {
    const res = await fetch("/api/navigation", { cache: "no-cache" });
    const data = (await res.json()) as { ok: boolean; byLocation?: Record<string, NavNode[]> };
    if (data.ok && data.byLocation) {
      useNavStore.setState({ byLocation: data.byLocation, loaded: true });
    }
  } catch {
    useNavStore.setState({ loaded: true });
  }
}

/* بارگذاری اولیه — خارج از رندر (module-level) */
void load();

/** هوک: منوی یک محل از DB — وقتی DB خالی است null برمی‌گرداند (fallback ثابت) */
export function useNavLocation(location: string): NavNode[] | null {
  const byLocation = useNavStore((s) => s.byLocation);
  const loaded = useNavStore((s) => s.loaded);
  if (!loaded) return null;
  const items = byLocation[location];
  return items && items.length > 0 ? items : null;
}

/** پس از ذخیره‌ی ادمین، منوها دوباره خوانده می‌شوند */
export function reloadNavigation(): void {
  void load();
}
