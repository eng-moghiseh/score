/* ————— رجیستری بلوک‌های صفحه‌ساز — امن و اعتبارسنجی‌شده —————
 * هیچ کد JS دلخواه از ورودی ادمین اجرا نمی‌شود؛ هر بلوک schema مشخص و
 * props پالایه‌شده دارد. رندر فقط با کامپوننت‌های ثبت‌شده انجام می‌گیرد.
 */

import { safeImageUrl, safeLinkHref } from "./types";

export interface BlockConfig {
  type: string;
  labelFa: string;
  labelEn: string;
  icon: string;
  /** فیلدهای قابل ویرایش — فرم ادمین از همین ساخته می‌شود */
  fields: BlockField[];
  defaults: Record<string, unknown>;
  /** تک‌لایه یا چندلایه بودن پیش‌فرض عرض */
  wide?: boolean;
}

export type BlockFieldType =
  | "text"
  | "textarea"
  | "number"
  | "boolean"
  | "select"
  | "image"
  | "link"
  | "list"
  | "faq"
  | "stat"
  | "color"
  | "range";

export interface BlockField {
  key: string;
  type: BlockFieldType;
  labelFa: string;
  labelEn: string;
  options?: { value: string; labelFa: string; labelEn?: string }[];
  min?: number;
  max?: number;
  step?: number;
  hintFa?: string;
  placeholder?: string;
}

export interface Block {
  id: string;
  type: string;
  hidden?: boolean;
  props: Record<string, unknown>;
}

/* ————— helpers ————— */
const faEnText = (key: string, labelFa: string, labelEn: string, opts?: Partial<BlockField>): BlockField => ({
  key,
  type: "text",
  labelFa,
  labelEn,
  ...opts,
});

const BILINGUAL = (base: string, labelFa: string, labelEn: string, textarea = false): BlockField[] => [
  { key: `${base}Fa`, type: textarea ? "textarea" : "text", labelFa: `${labelFa} (فارسی)`, labelEn: `${labelEn} (fa)` },
  { key: `${base}En`, type: textarea ? "textarea" : "text", labelFa: `${labelEn} (English)`, labelEn: `${labelEn} (en)` },
];

export const BLOCK_REGISTRY: Record<string, BlockConfig> = {
  hero: {
    type: "hero",
    labelFa: "هیرو (عنوان بزرگ)",
    labelEn: "Hero",
    icon: "Sparkles",
    wide: true,
    fields: [
      ...BILINGUAL("kicker", "برچسب بالا", "Kicker"),
      ...BILINGUAL("title", "تیتر", "Title"),
      ...BILINGUAL("desc", "توضیح", "Description", true),
      { key: "cta1Fa", type: "text", labelFa: "دکمه ۱ (فارسی)", labelEn: "CTA 1 (fa)" },
      { key: "cta1En", type: "text", labelFa: "دکمه ۱ (English)", labelEn: "CTA 1 (en)" },
      { key: "cta1Href", type: "link", labelFa: "لینک دکمه ۱", labelEn: "CTA 1 link", placeholder: "/store" },
      { key: "cta2Fa", type: "text", labelFa: "دکمه ۲ (فارسی)", labelEn: "CTA 2 (fa)" },
      { key: "cta2En", type: "text", labelFa: "دکمه ۲ (English)", labelEn: "CTA 2 (en)" },
      { key: "cta2Href", type: "link", labelFa: "لینک دکمه ۲", labelEn: "CTA 2 link", placeholder: "/ai-chat" },
      { key: "coverGameIds", type: "list", labelFa: "شناسه بازی‌های کلاژ کاور", labelEn: "Cover collage game IDs", hintFa: "شناسه‌ها را با کاما جدا کنید" },
    ],
    defaults: {
      kickerFa: "پلتفرم کشف و اجاره‌ی بازی",
      kickerEn: "Game discovery & rental platform",
      titleFa: "بازی بعدیت رو هوشمندانه انتخاب کن",
      titleEn: "Choose your next game, intelligently",
      descFa: "با دستیار هوشمند متصل به کاتالوگ و موتور پیشنهاد شفاف، بازی بعدیات را بر اساس سلیقه، بودجه و زمان خودت پیدا کن؛ اول تجربه کن، بعد با خیال راحت انتخاب کن.",
      descEn: "Find your next game with an AI assistant connected to the catalog and a transparent recommendation engine — try first, then buy with confidence.",
      cta1Fa: "کشف بازی‌ها",
      cta1En: "Browse games",
      cta1Href: "/store",
      cta2Fa: "گفتگو با دستیار",
      cta2En: "Chat with assistant",
      cta2Href: "/ai-chat",
      coverGameIds: "elden-ring,hades,forza-horizon-5",
    },
  },

  richText: {
    type: "richText",
    labelFa: "متن غنی",
    labelEn: "Rich text",
    icon: "FileText",
    fields: [
      ...BILINGUAL("title", "تیتر", "Title"),
      ...BILINGUAL("body", "متن", "Body", true),
    ],
    defaults: {
      titleFa: "درباره Scorent",
      titleEn: "About Scorent",
      bodyFa: "Scorent یک پلتفرم نمایشی برای کشف، اجاره و خرید بازی است. این یک پروتوتایپ آموزشی است و همه‌ی تراکنش‌ها شبیه‌سازی‌شده‌اند.",
      bodyEn: "Scorent is a demo platform for discovering, renting and buying games. It is an educational prototype; all transactions are simulated.",
    },
  },

  image: {
    type: "image",
    labelFa: "تصویر",
    labelEn: "Image",
    icon: "Image",
    fields: [
      { key: "src", type: "image", labelFa: "آدرس تصویر", labelEn: "Image URL" },
      { key: "altFa", type: "text", labelFa: "متن جایگزین (فارسی)", labelEn: "Alt (fa)" },
      { key: "altEn", type: "text", labelFa: "متن جایگزین (English)", labelEn: "Alt (en)" },
      { key: "href", type: "link", labelFa: "لینک (اختیاری)", labelEn: "Link (optional)" },
      { key: "rounded", type: "boolean", labelFa: "گوشه‌های گرد", labelEn: "Rounded" },
    ],
    defaults: { src: "", altFa: "", altEn: "", href: "", rounded: true },
  },

  imageText: {
    type: "imageText",
    labelFa: "تصویر + متن",
    labelEn: "Image + text",
    icon: "PanelsTopLeft",
    fields: [
      { key: "src", type: "image", labelFa: "آدرس تصویر", labelEn: "Image URL" },
      ...BILINGUAL("title", "تیتر", "Title"),
      ...BILINGUAL("body", "متن", "Body", true),
      ...BILINGUAL("cta", "دکمه", "CTA"),
      { key: "href", type: "link", labelFa: "لینک دکمه", labelEn: "CTA link" },
      { key: "reverse", type: "boolean", labelFa: "تصویر سمت مقابل", labelEn: "Reverse side" },
    ],
    defaults: {
      src: "", titleFa: "", titleEn: "", bodyFa: "", bodyEn: "", ctaFa: "", ctaEn: "", href: "/store", reverse: false,
    },
  },

  gameCarousel: {
    type: "gameCarousel",
    labelFa: "کاروسل بازی‌ها",
    labelEn: "Game carousel",
    icon: "GalleryHorizontalEnd",
    wide: true,
    fields: [
      ...BILINGUAL("title", "تیتر بخش", "Section title"),
      { key: "gameIds", type: "list", labelFa: "شناسه بازی‌ها", labelEn: "Game IDs", hintFa: "با کاما جدا کنید؛ خالی = خودکار محبوب‌ترین‌ها" },
      { key: "limit", type: "number", labelFa: "حداکثر تعداد", labelEn: "Max items", min: 2, max: 20, step: 1 },
    ],
    defaults: { titleFa: "پیشنهاد ویژه", titleEn: "Featured picks", gameIds: "", limit: 8 },
  },

  productGrid: {
    type: "productGrid",
    labelFa: "شبکه محصولات (بازی‌ها)",
    labelEn: "Product grid",
    icon: "LayoutGrid",
    wide: true,
    fields: [
      ...BILINGUAL("title", "تیتر بخش", "Section title"),
      { key: "filterGenre", type: "text", labelFa: "فیلتر ژانر (اختیاری)", labelEn: "Genre filter (optional)" },
      { key: "sort", type: "select", labelFa: "مرتب‌سازی", labelEn: "Sort", options: [
        { value: "popular", labelFa: "محبوب‌ترین", labelEn: "Most popular" },
        { value: "rating", labelFa: "بیشترین امتیاز", labelEn: "Top rated" },
        { value: "discount", labelFa: "بیشترین تخفیف", labelEn: "Biggest discount" },
        { value: "newest", labelFa: "جدیدترین", labelEn: "Newest" },
      ] },
      { key: "limit", type: "number", labelFa: "تعداد", labelEn: "Count", min: 2, max: 16, step: 1 },
    ],
    defaults: { titleFa: "داغ‌ترین‌ها", titleEn: "Hot right now", filterGenre: "", sort: "popular", limit: 8 },
  },

  categoryGrid: {
    type: "categoryGrid",
    labelFa: "شبکه رده‌ها",
    labelEn: "Category grid",
    icon: "Shapes",
    wide: true,
    fields: [
      ...BILINGUAL("title", "تیتر بخش", "Section title"),
      { key: "limit", type: "number", labelFa: "حداکثر رده", labelEn: "Max categories", min: 2, max: 24, step: 1 },
    ],
    defaults: { titleFa: "دسته‌بندی‌ها", titleEn: "Categories", limit: 12 },
  },

  promoBanner: {
    type: "promoBanner",
    labelFa: "بنر تبلیغاتی",
    labelEn: "Promo banner",
    icon: "Megaphone",
    wide: true,
    fields: [
      ...BILINGUAL("title", "تیتر", "Title"),
      ...BILINGUAL("body", "متن", "Body", true),
      ...BILINGUAL("cta", "دکمه", "CTA"),
      { key: "href", type: "link", labelFa: "لینک", labelEn: "Link" },
      { key: "tone", type: "select", labelFa: "حال‌وهوا", labelEn: "Tone", options: [
        { value: "brand", labelFa: "برند (نارنجی)", labelEn: "Brand (orange)" },
        { value: "ai", labelFa: "هوش مصنوعی", labelEn: "AI" },
        { value: "rent", labelFa: "اجاره", labelEn: "Rent" },
      ] },
    ],
    defaults: {
      titleFa: "جشنواره تخفیف پایان فصل",
      titleEn: "End-of-season sale",
      bodyFa: "تا ۶۰٪ تخفیف روی عناوین منتخب — فقط مدت محدود.",
      bodyEn: "Up to 60% off selected titles — limited time.",
      ctaFa: "مشاهده تخفیف‌ها",
      ctaEn: "See deals",
      href: "/deals",
      tone: "brand",
    },
  },

  stats: {
    type: "stats",
    labelFa: "آمار",
    labelEn: "Stats",
    icon: "TrendingUp",
    wide: true,
    fields: [
      { key: "mode", type: "select", labelFa: "منبع داده", labelEn: "Data source", options: [
        { value: "live", labelFa: "زنده از کاتالوگ", labelEn: "Live from catalog" },
        { value: "manual", labelFa: "دستی", labelEn: "Manual" },
      ] },
      { key: "items", type: "stat", labelFa: "آیتم‌های دستی", labelEn: "Manual items", hintFa: "هر خط: برچسب فارسی | برچسب انگلیسی | عدد" },
    ],
    defaults: { mode: "live", items: "بازی در کاتالوگ|games in catalog|28" },
  },

  faq: {
    type: "faq",
    labelFa: "سوالات متداول",
    labelEn: "FAQ",
    icon: "CircleHelp",
    fields: [
      ...BILINGUAL("title", "تیتر بخش", "Section title"),
      { key: "items", type: "faq", labelFa: "سوال و جواب", labelEn: "Q & A", hintFa: "هر خط: سوال | جواب (دو زبانه: سوال#جواب#سوال انگلیسی#جواب انگلیسی)" },
    ],
    defaults: {
      titleFa: "سوالات متداول",
      titleEn: "FAQ",
      items: "اجاره چطور کار می‌کند؟|بازی را برای ۱، ۳ یا ۷ روز اجاره می‌کنید و کامل تجربه می‌کنید.#How does rental work?|You rent a game for 1, 3 or 7 days and experience it fully.",
    },
  },

  video: {
    type: "video",
    labelFa: "ویدیو / تریلر",
    labelEn: "Video",
    icon: "PlayCircle",
    wide: true,
    fields: [
      { key: "url", type: "link", labelFa: "آدرس ویدیو (mp4 یا YouTube)", labelEn: "Video URL (mp4 or YouTube)" },
      ...BILINGUAL("title", "تیتر", "Title"),
    ],
    defaults: { url: "", titleFa: "", titleEn: "" },
  },

  cta: {
    type: "cta",
    labelFa: "دعوت به اقدام",
    labelEn: "CTA",
    icon: "MousePointerClick",
    wide: true,
    fields: [
      ...BILINGUAL("title", "تیتر", "Title"),
      ...BILINGUAL("body", "متن", "Body", true),
      ...BILINGUAL("cta", "دکمه", "CTA"),
      { key: "href", type: "link", labelFa: "لینک", labelEn: "Link" },
    ],
    defaults: {
      titleFa: "آماده‌ای بازی بعدی‌ات را پیدا کنی؟",
      titleEn: "Ready to find your next game?",
      bodyFa: "دستیار هوشمند Scorent بر اساس سلیقه و بودجه‌ی تو پیشنهاد می‌دهد.",
      bodyEn: "Scorent's AI assistant recommends based on your taste and budget.",
      ctaFa: "شروع پیشنهاد هوشمند",
      ctaEn: "Start Smart Picks",
      href: "/ai",
    },
  },

  spacer: {
    type: "spacer",
    labelFa: "فاصله‌ساز",
    labelEn: "Spacer",
    icon: "MoveVertical",
    fields: [{ key: "size", type: "range", labelFa: "ارتفاع", labelEn: "Height", min: 8, max: 200, step: 8 }],
    defaults: { size: 48 },
  },
};

export const BLOCK_TYPES = Object.keys(BLOCK_REGISTRY);

export function blockConfig(type: string): BlockConfig | null {
  return BLOCK_REGISTRY[type] ?? null;
}

function sanitizeValue(field: BlockField, raw: unknown): unknown | undefined {
  switch (field.type) {
    case "text":
    case "textarea":
      return typeof raw === "string" ? raw.slice(0, field.type === "textarea" ? 4000 : 400) : undefined;
    case "number":
    case "range": {
      const n = Number(raw);
      if (!Number.isFinite(n)) return undefined;
      const min = field.min ?? -1e9;
      const max = field.max ?? 1e9;
      return Math.min(max, Math.max(min, n));
    }
    case "boolean":
      return raw === true || raw === "true" || raw === 1;
    case "select":
      return typeof raw === "string" && (field.options?.some((o) => o.value === raw) ?? false) ? raw : undefined;
    case "image":
      return safeImageUrl(raw) ?? undefined;
    case "link":
      return safeLinkHref(raw) ?? undefined;
    case "list":
      return typeof raw === "string" ? raw.split(",").map((s) => s.trim().slice(0, 80)).filter(Boolean).slice(0, 24).join(",") : undefined;
    case "stat":
    case "faq":
      return typeof raw === "string" ? raw.slice(0, 6000) : undefined;
    case "color":
      return typeof raw === "string" && /^#[0-9a-f]{6}$/i.test(raw) ? raw : undefined;
    default:
      return undefined;
  }
}

export type BlockValidation = { ok: true; blocks: Block[] } | { ok: false; errors: string[] };

/** پالایه‌ی بلوک‌های دریافتی از ادمین — امن‌سازی کامل props */
export function sanitizeBlocks(raw: unknown): BlockValidation {
  if (!Array.isArray(raw)) return { ok: false, errors: ["ERR_BLOCKS_NOT_ARRAY"] };
  const errors: string[] = [];
  const out: Block[] = [];
  const seen = new Set<string>();
  for (let i = 0; i < raw.length && out.length < 40; i++) {
    const item = raw[i] as Record<string, unknown>;
    const type = typeof item?.type === "string" ? item.type : "";
    const cfg = BLOCK_REGISTRY[type];
    if (!cfg) {
      errors.push(`ERR_BLOCK_TYPE:${i}`);
      continue;
    }
    let id = typeof item?.id === "string" && /^[a-z0-9-]{4,40}$/.test(item.id) ? item.id : "";
    if (!id || seen.has(id)) id = `${type}-${Math.random().toString(36).slice(2, 8)}`;
    seen.add(id);
    const props: Record<string, unknown> = {};
    for (const field of cfg.fields) {
      const v = sanitizeValue(field, item?.props?.[field.key] ?? cfg.defaults[field.key]);
      if (v !== undefined) props[field.key] = v;
      else if (cfg.defaults[field.key] !== undefined) props[field.key] = cfg.defaults[field.key];
    }
    out.push({ id, type, hidden: item?.hidden === true ? true : undefined, props });
  }
  return errors.length ? { ok: false, errors } : { ok: true, blocks: out };
}

/** بازسازی بلوک‌ها از JSON ذخیره‌شده با گارد کامل */
export function parseBlocks(json: string | null | undefined): Block[] {
  if (!json) return [];
  try {
    const parsed = sanitizeBlocks(JSON.parse(json));
    return parsed.ok ? parsed.blocks : [];
  } catch {
    return [];
  }
}
