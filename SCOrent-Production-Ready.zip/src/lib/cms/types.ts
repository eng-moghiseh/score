/* ————— CMS shared types + safe URL validation — client & server safe ————— */

export type GameStatus = "PUBLISHED" | "DRAFT" | "ARCHIVED";
export type GameSource = "DATASET" | "CUSTOM";

export interface CategoryNode {
  id: string;
  slug: string;
  nameFa: string;
  nameEn: string;
  descFa: string | null;
  descEn: string | null;
  icon: string | null;
  image: string | null;
  seoFa: string | null;
  seoEn: string | null;
  parentId: string | null;
  order: number;
  enabled: boolean;
  children: CategoryNode[];
}

export type FilterType =
  | "text"
  | "number"
  | "range"
  | "select"
  | "multiselect"
  | "boolean"
  | "daterange"
  | "price"
  | "rating";

export const FILTER_TYPES: FilterType[] = [
  "text",
  "number",
  "range",
  "select",
  "multiselect",
  "boolean",
  "daterange",
  "price",
  "rating",
];

export interface FilterOption {
  value: string;
  labelFa: string;
  labelEn?: string;
}

export interface FilterMeta {
  /** فیلد شیء Game که فیلتر روی آن اعمال می‌شود */
  field?: string;
  min?: number;
  max?: number;
  step?: number;
  unitFa?: string;
  unitEn?: string;
  /** فقط برای رده‌های مشخص نمایش داده شود (اسلاگ‌ها) — خالی = همه‌جا */
  categories?: string[];
  /** پیش‌فرض پنل */
  default?: string;
}

export interface FilterDef {
  id: string;
  key: string;
  labelFa: string;
  labelEn: string;
  type: FilterType;
  options: FilterOption[];
  meta: FilterMeta;
  order: number;
  enabled: boolean;
}

export type NavLocation = "header" | "mobile" | "footer" | "custom";

export interface NavNode {
  id: string;
  location: string;
  parentId: string | null;
  labelFa: string;
  labelEn: string;
  href: string;
  icon: string | null;
  descFa: string | null;
  descEn: string | null;
  order: number;
  enabled: boolean;
  newTab: boolean;
  children: NavNode[];
}

/* ————— URL امن: فقط http(s) مطلق، مسیر داخلی یا /api/media/:id ————— */

const SAFE_ABS = /^https?:\/\/[^\s"'<>]+$/i;
const SAFE_LOCAL = /^\/(?!\/)[^\s"'<>]*$/;
const MEDIA_RE = /^\/api\/media\/[a-z0-9]+$/i;

/** URL تصویری امن — برای کاور/گالری/بنر/رسانه */
export function safeImageUrl(url: unknown): string | null {
  if (typeof url !== "string") return null;
  const u = url.trim();
  if (!u || u.length > 2000) return null;
  if (MEDIA_RE.test(u)) return u;
  if (SAFE_LOCAL.test(u)) {
    if (/\.(svg|html|js|css)$/i.test(u)) return null;
    return u;
  }
  if (SAFE_ABS.test(u)) {
    try {
      const parsed = new URL(u);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
      if (parsed.username || parsed.password) return null;
      return u;
    } catch {
      return null;
    }
  }
  return null;
}

/** لینک ناوبری امن — مسیر داخلی هش‌روتر یا URL خارجی */
export function safeLinkHref(href: unknown): string | null {
  if (typeof href !== "string") return null;
  const h = href.trim();
  if (!h || h.length > 600) return null;
  if (/^[a-z0-9/-]+(\?[^"'<>]*)?$/i.test(h)) return h.startsWith("/") ? h : `/${h}`;
  if (/^https?:\/\/[^\s"'<>]+$/i.test(h)) {
    try {
      const parsed = new URL(h);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
      if (parsed.username || parsed.password) return null;
      return h;
    } catch {
      return null;
    }
  }
  return null;
}

/** slug امن برای صفحه/رده */
export function cmsSlugOk(slug: unknown): slug is string {
  return typeof slug === "string" && /^[a-z0-9-]{2,60}$/.test(slug);
}
