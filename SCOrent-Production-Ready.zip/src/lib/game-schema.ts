/* ————— پالایه و سازنده‌ی ورودی بازی — مشترک بین سرور و کلاینت —————
 * sanitizeGameInput: سخت‌گیرانه؛ ورودی خام فرم ادمین → شیء Game معتبر یا فهرست خطاها.
 * lenientGame: آسان‌گیر؛ برای «پیش‌نمایش زنده» فرم — همیشه یک Game کامل با پیش‌فرض‌ها.
 * slugify / slugOk: ساخت و اعتبارسنجی شناسه یکتا.
 */

import { ALL_GENRES, ALL_MODES, ALL_PLAYSTYLES } from "@/lib/types";
import type { CoverMotif, Game, GameMode, Genre, Playstyle, Structure, TrialKind } from "@/lib/types";
import { safeImageUrl } from "@/lib/cms/types";

/* ————— فیلدهای CMS اختیاری — پالایش امن URL و طول ————— */

function cmsExtras(r: Record<string, unknown>): Partial<Game> {
  const out: Partial<Game> = {};
  const cover = safeImageUrl(r.coverUrl);
  if (cover) out.coverUrl = cover;
  if (Array.isArray(r.gallery)) {
    const gallery = r.gallery.map(safeImageUrl).filter((u): u is string => u !== null).slice(0, 8);
    if (gallery.length) out.gallery = gallery;
  }
  const trailer = safeImageUrl(r.trailerUrl);
  if (trailer) out.trailerUrl = trailer;
  const age = str(r.ageRating).slice(0, 20);
  if (age) out.ageRating = age;
  const langs = Array.isArray(r.languages) ? r.languages.filter((x): x is string => typeof x === "string" && Boolean(x.trim())).map((x) => x.trim().slice(0, 40)).slice(0, 20) : [];
  if (langs.length) out.languages = langs;
  const platforms = Array.isArray(r.platforms) ? r.platforms.filter((x): x is string => typeof x === "string" && Boolean(x.trim())).map((x) => x.trim().slice(0, 40)).slice(0, 10) : [];
  if (platforms.length) out.platforms = platforms;
  const publisher = str(r.publisher).slice(0, 80);
  if (publisher) out.publisher = publisher;
  const seoTitleFa = str(r.seoTitleFa).slice(0, 120);
  if (seoTitleFa) out.seoTitleFa = seoTitleFa;
  const seoTitleEn = str(r.seoTitleEn).slice(0, 120);
  if (seoTitleEn) out.seoTitleEn = seoTitleEn;
  const seoDescFa = str(r.seoDescFa).slice(0, 300);
  if (seoDescFa) out.seoDescFa = seoDescFa;
  const seoDescEn = str(r.seoDescEn).slice(0, 300);
  if (seoDescEn) out.seoDescEn = seoDescEn;
  const cats = Array.isArray(r.categories) ? r.categories.filter((x): x is string => typeof x === "string" && /^[a-z0-9-]{2,60}$/.test(x)).slice(0, 12) : [];
  if (cats.length) out.categories = cats;
  const tags = Array.isArray(r.tags) ? r.tags.filter((x): x is string => typeof x === "string" && Boolean(x.trim())).map((x) => x.trim().slice(0, 40)).slice(0, 16) : [];
  if (tags.length) out.tags = tags;
  return out;
}

export const STRUCTURES: Structure[] = ["دنیای آزاد", "نیمه‌آزاد", "خطی"];
export const MOTIFS: CoverMotif[] = ["peaks", "orb", "grid", "waves", "slashes", "spiral", "shards", "ring", "pips", "arch"];
export const TRIAL_KINDS: TrialKind[] = ["none", "official-demo", "friends-pass"];

const GENRE_SET = new Set<string>(ALL_GENRES);
const PLAYSTYLE_SET = new Set<string>(ALL_PLAYSTYLES);
const MODE_SET = new Set<string>(ALL_MODES);
const STRUCTURE_SET = new Set<string>(STRUCTURES);
const MOTIF_SET = new Set<string>(MOTIFS);
const TRIAL_SET = new Set<string>(TRIAL_KINDS);
const HEX_RE = /^#[0-9a-f]{6}$/i;

const clampInt = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, Math.round(v)));

/** اسلاگ لاتین از عنوان (برای پیشنهاد خودکار id) */
export function slugify(title: string): string {
  return title
    .toLowerCase()
    .replace(/['’"]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/-{2,}/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60)
    .replace(/-+$/g, "");
}

export const slugOk = (id: string) => /^[a-z0-9-]{2,60}$/.test(id);

/** پالت سه‌رنگ پایدار از هش شناسه — پس‌زمینه‌ی تیره، میانه، رنگ تأکید روشن */
export function autoPalette(seed: string): [string, string, string] {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  const hue = h % 360;
  const h2 = (hue + 25) % 360;
  const h3 = (hue + 195) % 360;
  const hex = (hh: number, s: number, l: number) => {
    const a = (s / 100) * Math.min(l / 100, 1 - l / 100);
    const f = (n: number) => {
      const k = (n + hh / 30) % 12;
      const c = l / 100 - a * Math.max(-1, Math.min(k - 3, Math.min(9 - k, 1)));
      return Math.round(255 * c)
        .toString(16)
        .padStart(2, "0");
    };
    return `#${f(0)}${f(8)}${f(4)}`;
  };
  return [hex(hue, 42, 13), hex(h2, 45, 27), hex(h3, 68, 58)];
}

const autoMotif = (seed: string): CoverMotif => {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 33 + seed.charCodeAt(i)) >>> 0;
  return MOTIFS[h % MOTIFS.length];
};

/** نسبت‌های پیشنهادی اجاره — همان الگوی دیتاست اصلی (۱۲.۵٪ / ۳۱.۲۵٪ / ۵۰٪) */
export function suggestRental(price: number): { d1: number; d3: number; d7: number } {
  const p = Math.max(0, price);
  return {
    d1: Math.max(0, Math.round((p * 0.125) / 1000) * 1000),
    d3: Math.max(0, Math.round((p * 0.3125) / 1000) * 1000),
    d7: Math.max(0, Math.round((p * 0.5) / 1000) * 1000),
  };
}

function str(v: unknown): string {
  return typeof v === "string" ? v.trim() : "";
}
function pickSet<T extends string>(v: unknown, allowed: Set<string>, max: number): T[] {
  if (!Array.isArray(v)) return [];
  return [...new Set(v.filter((x): x is T => typeof x === "string" && allowed.has(x)))].slice(0, max) as T[];
}
function rangePair(v: unknown, lo: number, hi: number): [number, number] | null {
  if (!Array.isArray(v) || v.length !== 2) return null;
  const a = Number(v[0]);
  const b = Number(v[1]);
  if (!Number.isFinite(a) || !Number.isFinite(b)) return null;
  const x = clampInt(a, lo, hi);
  const y = clampInt(b, lo, hi);
  return x <= y ? [x, y] : [y, x];
}

/** سازنده‌ی آسان‌گیر: همه‌ی فیلدها با کلمپ و پیش‌فرض پر می‌شوند — خروجی همیشه Game */
export function lenientGame(raw: unknown): Game {
  const r = (raw ?? {}) as Record<string, unknown>;
  const id = slugOk(str(r.id)) ? str(r.id) : "untitled-game";
  const title = str(r.title).slice(0, 80) || "بدون عنوان";
  const price = Math.max(1000, clampInt(Number(r.price) || 0, 1000, 500_000_000));
  let originalPrice = Number.isFinite(Number(r.originalPrice)) ? clampInt(Number(r.originalPrice), 0, 500_000_000) : price;
  if (originalPrice < price) originalPrice = price;
  const discountPercent = Math.max(0, Math.min(90, clampInt(Number(r.discountPercent ?? deriveDiscount(price, originalPrice)), 0, 90)));
  const rentalAvailable = r.rentalAvailable === true;
  const rawRental = (r.rental ?? {}) as Record<string, unknown>;
  const suggested = suggestRental(price);
  const rental = rentalAvailable
    ? {
        d1: Math.max(0, clampInt(Number(rawRental.d1) || suggested.d1, 0, 500_000_000)),
        d3: Math.max(0, clampInt(Number(rawRental.d3) || suggested.d3, 0, 500_000_000)),
        d7: Math.max(0, clampInt(Number(rawRental.d7) || suggested.d7, 0, 500_000_000)),
      }
    : null;
  const highlights = Array.isArray(r.highlights)
    ? r.highlights.filter((x): x is string => typeof x === "string" && x.trim().length > 0).map((x) => x.trim().slice(0, 160)).slice(0, 8)
    : [];
  const paletteRaw = Array.isArray(r.palette) ? r.palette.filter((x): x is string => typeof x === "string" && HEX_RE.test(x.trim())) : [];
  const palette = (paletteRaw.length === 3 ? paletteRaw : autoPalette(id || title)) as [string, string, string];
  const trialRaw = (r.trial ?? {}) as Record<string, unknown>;
  const trialKind = TRIAL_SET.has(str(trialRaw.kind)) ? (str(trialRaw.kind) as TrialKind) : "none";
  return {
    id,
    title,
    tagline: str(r.tagline).slice(0, 160) || title,
    description: str(r.description).slice(0, 4000) || title,
    developer: str(r.developer).slice(0, 80) || "نامشخص",
    year: clampInt(Number(r.year) || 2024, 1980, new Date().getFullYear() + 2),
    genres: pickSet<Genre>(r.genres, GENRE_SET, 4),
    playstyles: pickSet<Playstyle>(r.playstyles, PLAYSTYLE_SET, 3),
    structure: STRUCTURE_SET.has(str(r.structure)) ? (str(r.structure) as Structure) : "خطی",
    modes: pickSet<GameMode>(r.modes, MODE_SET, 4),
    sessionMinutes: rangePair(r.sessionMinutes, 5, 600) ?? [60, 180],
    campaignHours: rangePair(r.campaignHours, 1, 2000),
    rating: Math.max(0, Math.min(5, Math.round(Number(r.rating) * 10) / 10 || 0)),
    ratingSource: str(r.ratingSource).slice(0, 120) || "داده نمونه — ورودی ادمین",
    price,
    originalPrice,
    discountPercent,
    rental,
    rentalAvailable,
    indie: r.indie === true,
    featured: r.featured === true,
    popularity: clampInt(Number(r.popularity) || 50, 0, 100),
    available: r.available !== false,
    trial: { kind: trialKind, note: str(trialRaw.note).slice(0, 400) || "برای این بازی دموی رسمی ثبت نشده؛ اجاره‌ی کوتاه Scorent راه آزمودن است." },
    palette,
    motif: MOTIF_SET.has(str(r.motif)) ? (str(r.motif) as CoverMotif) : autoMotif(id || title),
    highlights,
    taglineEn: str(r.taglineEn).slice(0, 160) || undefined,
    descriptionEn: str(r.descriptionEn).slice(0, 4000) || undefined,
    ...cmsExtras(r),
  };
}

function deriveDiscount(price: number, originalPrice: number): number {
  if (originalPrice > price && price > 0) return Math.max(0, Math.min(90, Math.round((1 - price / originalPrice) * 100)));
  return 0;
}

export type GameValidation = { ok: true; game: Game } | { ok: false; errors: string[] };

/** پالایه‌ی سخت‌گیرانه: ورودی خام فرم → Game معتبر؛ یا همه‌ی خطاها با کد یکتا */
export function sanitizeGameInput(raw: unknown): GameValidation {
  const r = (raw ?? {}) as Record<string, unknown>;
  const errors: string[] = [];

  const id = str(r.id).toLowerCase();
  if (!slugOk(id)) errors.push("ERR_ID");

  const title = str(r.title);
  if (title.length < 2 || title.length > 80) errors.push("ERR_TITLE");

  const tagline = str(r.tagline);
  if (tagline.length < 3 || tagline.length > 160) errors.push("ERR_TAGLINE");

  const description = str(r.description);
  if (description.length < 10 || description.length > 4000) errors.push("ERR_DESCRIPTION");

  const developer = str(r.developer);
  if (developer.length < 2 || developer.length > 80) errors.push("ERR_DEVELOPER");

  const yearRaw = r.year;
  const year = Number(yearRaw);
  // سال خالی = پیش‌فرض؛ فقط مقدار اشتباه خطا دارد
  if (!(yearRaw === undefined || yearRaw === null || yearRaw === "") && (!Number.isFinite(year) || year < 1980 || year > new Date().getFullYear() + 2)) errors.push("ERR_YEAR");

  const genres = pickSet<Genre>(r.genres, GENRE_SET, 4);
  if (genres.length === 0) errors.push("ERR_GENRES");

  const playstyles = pickSet<Playstyle>(r.playstyles, PLAYSTYLE_SET, 3);
  if (playstyles.length === 0) errors.push("ERR_PLAYSTYLES");

  const modes = pickSet<GameMode>(r.modes, MODE_SET, 4);
  if (modes.length === 0) errors.push("ERR_MODES");

  if (!STRUCTURE_SET.has(str(r.structure))) errors.push("ERR_STRUCTURE");

  const price = Number(r.price);
  if (!Number.isFinite(price) || price < 1000 || price > 500_000_000) errors.push("ERR_PRICE");

  const originalPrice = Number.isFinite(Number(r.originalPrice)) ? Number(r.originalPrice) : price;
  if (originalPrice < price) errors.push("ERR_ORIGINAL_PRICE");

  if (r.rentalAvailable === true) {
    const rental = (r.rental ?? {}) as Record<string, unknown>;
    let rentalBad = false;
    for (const k of ["d1", "d3", "d7"] as const) {
      const v = rental[k];
      // مقدار خالی/نامشخص = پیشنهاد خودکار از قیمت؛ فقط مقدارِ اشتباه خطا دارد
      if (v === undefined || v === null || v === "") continue;
      const n = Number(v);
      if (!Number.isFinite(n) || n < 0 || n > 500_000_000) {
        rentalBad = true;
        break;
      }
    }
    if (rentalBad) errors.push("ERR_RENTAL");
  }

  const highlights = Array.isArray(r.highlights)
    ? r.highlights.filter((x): x is string => typeof x === "string" && x.trim().length > 0)
    : [];
  if (highlights.length > 8 || highlights.some((h) => h.trim().length < 3 || h.trim().length > 160)) errors.push("ERR_HIGHLIGHTS");

  const game = lenientGame({ ...r, id });
  if (errors.length > 0) return { ok: false, errors };

  // تخفیف نهایی: از رابطه‌ی قیمت‌ها استخراج می‌شود (ورودی صرفاً نمایشی است)
  game.discountPercent = deriveDiscount(game.price, game.originalPrice);
  return { ok: true, game };
}

/** پالایش سبک بخشی از بازی (بدون الزام‌ها) — برای PATCH جزئی */
export function sanitizeGamePatch(raw: Record<string, unknown>): { ok: boolean; errors: string[] } {
  const errors: string[] = [];
  if (raw.price !== undefined) {
    const price = Number(raw.price);
    if (!Number.isFinite(price) || price < 1000 || price > 500_000_000) errors.push("ERR_PRICE");
  }
  if (raw.originalPrice !== undefined) {
    const op = Number(raw.originalPrice);
    if (!Number.isFinite(op) || op < 0 || op > 500_000_000) errors.push("ERR_ORIGINAL_PRICE");
  }
  if (raw.featured !== undefined && typeof raw.featured !== "boolean") errors.push("ERR_FEATURED");
  if (raw.available !== undefined && typeof raw.available !== "boolean") errors.push("ERR_AVAILABLE");
  if (raw.popularity !== undefined) {
    const p = Number(raw.popularity);
    if (!Number.isFinite(p) || p < 0 || p > 100) errors.push("ERR_POPULARITY");
  }
  if (raw.rating !== undefined) {
    const ra = Number(raw.rating);
    if (!Number.isFinite(ra) || ra < 0 || ra > 5) errors.push("ERR_RATING");
  }
  for (const k of ["title", "tagline", "developer", "publisher"] as const) {
    if (raw[k] !== undefined && (typeof raw[k] !== "string" || raw[k].length > 120)) errors.push(`ERR_${k.toUpperCase()}`);
  }
  if (raw.description !== undefined && (typeof raw.description !== "string" || raw.description.length > 4000)) errors.push("ERR_DESCRIPTION");
  return { ok: errors.length === 0, errors };
}

/** گارد سبک برای خواندن JSON ذخیره‌شده/دریافتی از API عمومی */
export function isGameShape(x: unknown): x is Game {
  if (typeof x !== "object" || x === null) return false;
  const g = x as Record<string, unknown>;
  return (
    slugOk(str(g.id)) &&
    typeof g.title === "string" &&
    typeof g.tagline === "string" &&
    typeof g.description === "string" &&
    typeof g.price === "number" &&
    Array.isArray(g.genres) &&
    Array.isArray(g.palette) &&
    g.palette.length === 3
  );
}
