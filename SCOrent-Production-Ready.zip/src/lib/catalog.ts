"use client";

/* ————— کاتالوگ زنده: دیتاست اصلی + اورراید ادمین + بازی‌های سفارشی —————
 * اورراید از /api/overrides خوانده و «در همان آرایه‌ی GAMES» اعمال می‌شود؛
 * چون همه‌ی ماژول‌ها مرجع یکسان GAMES را ایمپورت کرده‌اند، همه‌ی صفحات و
 * سلکتورهای موجود (getGame، featuredGames، GAMES.length و ...) بدون تغییر
 * از اورراید و بازی‌های سفارشی پیروی می‌کنند.
 *
 * اعمال «idempotent» است: هر بار ابتدا آرایه به اسنپ‌شات اولیه برمی‌گردد،
 * سپس اورراید اعمال و بازی‌های سفارشی اضافه می‌شوند؛ بنابراین refreshCatalog
 * می‌تواند هر تعداد بار فراخوانی شود (مثلاً پس از افزودن بازی در پنل ادمین).
 */

import { create } from "zustand";
import { GAMES } from "@/lib/data/games";
import type { Game } from "@/lib/types";
import { sanitizeGameInput, isGameShape } from "@/lib/game-schema";

export interface GameOverrideData {
  hidden?: boolean;
  featured?: boolean;
  discountPct?: number;
  taglineFa?: string;
  taglineEn?: string;
  descriptionFa?: string;
  descriptionEn?: string;
}

interface CatalogState {
  overrides: Record<string, GameOverrideData>;
  customCount: number;
  version: number; // 0 = هنوز hydrate نشده
}

export const useCatalog = create<CatalogState>()(() => ({ overrides: {}, customCount: 0, version: 0 }));

/** اسنپ‌شات بی‌درنگ از دیتاست اولیه — مبنای بازنشانی idempotent */
const PRISTINE: Game[] = GAMES.map((g) => ({ ...g }));

let inFlight: Promise<void> | null = null;

function applyPayload(overrides: Record<string, GameOverrideData>, customGames: unknown[]): void {
  // بازنشانی به حالت اولیه (طول آرایه‌ی زنده صفر و پرکردن مجدد — مرجع ثابت می‌ماند)
  GAMES.length = 0;
  GAMES.push(...PRISTINE.map((g) => ({ ...g })));

  // اورراید ادمین: پنهان‌ها حذف، بقیه با مقادیر جدید جایگزین می‌شوند
  for (let i = GAMES.length - 1; i >= 0; i--) {
    const g = GAMES[i];
    const o = overrides[g.id];
    if (!o) continue;
    if (o.hidden) {
      GAMES.splice(i, 1);
      continue;
    }
    const next: Game = { ...g };
    if (typeof o.featured === "boolean") next.featured = o.featured;
    if (typeof o.discountPct === "number") {
      const pct = Math.max(0, Math.min(90, Math.round(o.discountPct)));
      next.originalPrice = next.originalPrice || next.price;
      next.discountPercent = pct;
      next.price = Math.max(1000, Math.round((next.originalPrice * (1 - pct / 100)) / 1000) * 1000);
    }
    if (o.taglineFa) next.tagline = o.taglineFa;
    if (o.taglineEn) next.taglineEn = o.taglineEn;
    if (o.descriptionFa) next.description = o.descriptionFa;
    if (o.descriptionEn) next.descriptionEn = o.descriptionEn;
    GAMES[i] = next;
  }

  // بازی‌های سفارشی ادمین — با پالایه‌ی کامل و بدون تکرار شناسه
  let added = 0;
  const ids = new Set(GAMES.map((g) => g.id));
  for (const raw of customGames) {
    const parsed = sanitizeGameInput(raw);
    if (!parsed.ok) continue;
    if (ids.has(parsed.game.id)) continue;
    ids.add(parsed.game.id);
    GAMES.push(parsed.game);
    added++;
  }
  useCatalog.setState({ overrides, customCount: added, version: useCatalog.getState().version + 1 });
}

/** اعمال کاتالوگ کامل DB (مسیر جدید) — در همان آرایه‌ی زنده‌ی GAMES */
function applyCatalog(games: Game[]): void {
  GAMES.length = 0;
  GAMES.push(...games);
  useCatalog.setState({ overrides: {}, customCount: 0, version: useCatalog.getState().version + 1 });
}

async function fetchAndApply(bust: boolean): Promise<void> {
  // ۱) مسیر جدید: کاتالوگ کامل DB از /api/catalog — منبع حقیقت CMS
  try {
    const url = bust ? `/api/catalog?v=${Date.now()}` : "/api/catalog";
    const res = await fetch(url, { cache: "no-cache" });
    const data = (await res.json()) as { ok: boolean; games?: unknown[] };
    if (data.ok && Array.isArray(data.games) && data.games.length > 0) {
      const games = data.games.filter(isGameShape).map((g) => ({ ...g }));
      applyCatalog(games);
      return;
    }
  } catch {
    /* مسیر قدیمی امتحان می‌شود */
  }

  // ۲) مسیر قدیمی (سازگاری): اورراید + بازی‌های سفارشی
  const url = bust ? `/api/overrides?v=${Date.now()}` : "/api/overrides";
  const res = await fetch(url, { cache: "no-cache" });
  const data = (await res.json()) as { ok: boolean; overrides?: Record<string, GameOverrideData>; customGames?: unknown[] };
  if (!data.ok || !data.overrides) {
    applyPayload({}, []);
    return;
  }
  applyPayload(data.overrides, Array.isArray(data.customGames) ? data.customGames : []);
}

/** اولین hydrate — یک بار در طول عمر صفحه */
let hydrated = false;

export function hydrateCatalog(): void {
  if (hydrated || inFlight) return;
  hydrated = true;
  inFlight = fetchAndApply(false)
    .catch(() => applyPayload({}, []))
    .finally(() => {
      inFlight = null;
    });
}

/** بازخوانی صریح کاتالوگ (پس از ذخیره‌ی ادمین) — با شکستن کش CDN */
export async function refreshCatalog(): Promise<void> {
  if (inFlight) return inFlight;
  inFlight = fetchAndApply(true)
    .catch(() => undefined)
    .finally(() => {
      inFlight = null;
    });
  return inFlight;
}

/** هوک شِل: اولین دسترسی باعث hydrate می‌شود؛ تغییر نسخه → رندر مجدد درختی */
export function useCatalogReady(): boolean {
  const version = useCatalog((s) => s.version);
  if (!hydrated) hydrateCatalog();
  return version > 0;
}

/** بررسی اینکه شناسه در دیتاست ثابت اشغال شده است (برای فرم ادمین) */
export function datasetHas(id: string): boolean {
  return PRISTINE.some((g) => g.id === id);
}
