"use client";

import { ScorpionMark, ScorentMark } from "./logo";
import { Link } from "./router";
import { DEMO_DATA_NOTE } from "@/lib/data/games";
import { useT, useTx, useLang } from "@/lib/i18n";
import { useNavLocation } from "@/lib/cms/nav-client";
import type { NavNode } from "@/lib/cms/types";

const COLUMNS: { titleKey: string; links: { to: string; labelKey: string }[] }[] = [
  {
    titleKey: "footer.modules",
    links: [
      { to: "/store", labelKey: "footer.storeLink" },
      { to: "/ai-chat", labelKey: "nav.aiChatFull" },
      { to: "/ai", labelKey: "nav.ai" },
      { to: "/rent", labelKey: "nav.rent" },
      { to: "/share", labelKey: "footer.shareLink" },
    ],
  },
  {
    titleKey: "footer.explore",
    links: [
      { to: "/discovery", labelKey: "footer.discoveryLink" },
      { to: "/deals", labelKey: "footer.dealsLink" },
      { to: "/trial", labelKey: "footer.trialLink" },
      { to: "/rewards", labelKey: "nav.rewards" },
    ],
  },
  {
    titleKey: "footer.account",
    links: [
      { to: "/profile", labelKey: "nav.profile" },
      { to: "/rentals", labelKey: "nav.rentals" },
      { to: "/wishlist", labelKey: "nav.wishlist" },
      { to: "/settings", labelKey: "footer.settingsLink" },
    ],
  },
];

interface FooterColumn {
  title: string;
  links: { to: string; label: string; external: boolean }[];
}

export function Footer() {
  const t = useT();
  const tx = useTx();
  const lang = useLang();
  const cmsFooter = useNavLocation("footer");

  const cmsColumns: FooterColumn[] | null = cmsFooter
    ? cmsFooter.map((col: NavNode) => ({
        title: lang === "en" ? col.labelEn || col.labelFa : col.labelFa,
        links: (col.children ?? []).map((c) => ({
          to: c.href,
          label: lang === "en" ? c.labelEn || c.labelFa : c.labelFa,
          external: !c.href.startsWith("/"),
        })),
      }))
    : null;

  const fallbackColumns: FooterColumn[] = COLUMNS.map((col) => ({
    title: t(col.titleKey),
    links: col.links.map((l) => ({ to: l.to, label: t(l.labelKey), external: false })),
  }));

  const columns = cmsColumns && cmsColumns.every((c) => c.links.length > 0) && cmsColumns.length > 0 ? cmsColumns : fallbackColumns;

  const renderItem = (item: { to: string; label: string; external: boolean }) =>
    item.external ? (
      <a href={item.to} target="_blank" rel="noopener noreferrer" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
        {item.label}
      </a>
    ) : (
      <Link to={item.to} className="text-sm text-muted-foreground transition-colors hover:text-foreground">
        {item.label}
      </Link>
    );
  return (
    <footer className="relative mt-auto bg-surface pb-28 lg:pb-32">
      <div className="hairline-brand" aria-hidden />
      <div className="mx-auto w-full max-w-7xl px-4 py-12 md:px-6">
        <div className="grid gap-10 md:grid-cols-[1.3fr_1fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-3">
              <ScorpionMark size={40} />
              <div>
                <p className="text-lg font-extrabold" dir="ltr" style={{ textAlign: "start" }}>
                  Scorent
                </p>
                <p className="text-xs font-bold text-deal">«{t("brand.slogan")}»</p>
              </div>
            </div>
            <p className="mt-4 max-w-xs text-sm leading-7 text-muted-foreground">{t("footer.about")}</p>
            <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-rent/25 bg-rent/8 px-3 py-1.5 text-[0.7rem] font-bold text-rent">
              {t("brand.rentSlogan")}
            </div>
          </div>

          {columns.map((col) => (
            <nav key={col.title} aria-label={col.title}>
              <h3 className="mb-3 text-sm font-extrabold">{col.title}</h3>
              <ul className="space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.to + l.label}>{renderItem(l)}</li>
                ))}
              </ul>
            </nav>
          ))}
        </div>

        <div className="mt-10 space-y-3 border-t border-border pt-6 text-xs leading-6 text-muted-foreground">
          <p>{t("footer.disclaimer")}</p>
          <p>{tx(DEMO_DATA_NOTE)}</p>
          <p className="flex flex-wrap items-center justify-between gap-2">
            <span className="flex items-center gap-2">
              <ScorentMark size={16} />
              {t("footer.credit")}
            </span>
            <span dir="ltr" className="tnum">
              © 2026 Scorent Demo
            </span>
          </p>
        </div>
      </div>
    </footer>
  );
}
