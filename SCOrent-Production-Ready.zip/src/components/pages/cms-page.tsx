"use client";

/* ————— صفحه عمومی صفحه‌ساز — رندر بلوک‌های صفحه منتشرشده از DB ————— */

import { useEffect, useState } from "react";
import { BlocksRenderer } from "@/components/cms/blocks-render";
import { useLang } from "@/lib/i18n";
import { parseBlocks } from "@/lib/cms/blocks";
import { GAMES } from "@/lib/data/games";
import { useCatalogReady } from "@/lib/catalog";

export function CmsPage({ slug }: { slug: string }) {
  const [state, setState] = useState<{ title: string; blocks: string; found: boolean } | null>(null);
  const lang = useLang();
  const catalogReady = useCatalogReady();
  // hydrate کاتالوگ برای بلوک‌های متکی به GAMES
  void catalogReady;

  useEffect(() => {
    let alive = true;
    fetch(`/api/pages/${encodeURIComponent(slug)}`, { cache: "no-cache" })
      .then(async (r) => {
        const d = (await r.json()) as { ok: boolean; page?: { titleFa: string; titleEn: string; blocks: unknown } };
        if (!alive) return;
        if (d.ok && d.page) {
          setState({
            title: lang === "en" ? d.page.titleEn || d.page.titleFa : d.page.titleFa,
            blocks: JSON.stringify(d.page.blocks ?? []),
            found: true,
          });
        } else {
          setState({ title: "", blocks: "[]", found: false });
        }
      })
      .catch(() => {
        if (alive) setState({ title: "", blocks: "[]", found: false });
      });
    return () => {
      alive = false;
    };
  }, [slug, lang]);

  if (!state) {
    return (
      <div className="flex min-h-[50svh] items-center justify-center" role="status" aria-live="polite">
        <span className="size-8 animate-spin rounded-full border-2 border-border border-t-ai" />
      </div>
    );
  }

  if (!state.found) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center md:px-6">
        <h1 className="text-3xl font-black">{lang === "en" ? "Page not found" : "صفحه پیدا نشد"}</h1>
        <p className="mt-3 text-muted-foreground">{lang === "en" ? "This page has not been published." : "این صفحه منتشر نشده است."}</p>
      </div>
    );
  }

  const blocks = parseBlocks(state.blocks);
  return (
    <article>
      {blocks.length === 0 ? null : <BlocksRenderer blocks={blocks} />}
      {/* ارجاع به کاتالوگ برای اطمینان از hydrate شدن GAMES پیش از رندر بلوک‌ها */}
      <span className="hidden">{catalogReady ? GAMES.length : 0}</span>
    </article>
  );
}
