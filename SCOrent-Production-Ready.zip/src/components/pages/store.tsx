"use client";

/* ————— فروشگاه: جستجو + فیلترهای پویا (از DB) + مرتب‌سازی + صفحه‌بندی — دوزبانه —————
 * تعریف فیلترها از /api/filters می‌آید (FilterDefinition) و با موتور
 * src/lib/cms/filter-engine.ts روی کاتالوگ اعمال می‌شود. اگر هیچ تعریفی در
 * DB نباشد، مجموعه‌ی پیش‌فرض ثابت به‌عنوان fallback استفاده می‌شود (هرگز
 * منبع اصلی نیست — فقط بیمه‌ی رفتار قدیمی).
 */

import { useEffect, useMemo, useState } from "react";
import { Filter, Search, SlidersHorizontal, XCircle, ChevronRight, ChevronLeft } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { GameCard } from "@/components/scorent/commerce";
import { EmptyState, GameCardSkeleton } from "@/components/scorent/shared";
import { Link, useRoute, navigate } from "@/components/scorent/router";
import { GAMES } from "@/lib/data/games";
import { ALL_GENRES, ALL_MODES } from "@/lib/types";
import { useFmt, useT, useTx, useUiDir, useLang } from "@/lib/i18n";
import { useHydrated } from "@/lib/store";
import { cn } from "@/lib/utils";
import { applyFilters, parseFilterParams, filtersToParams, paginate, sortGames, valueLabel } from "@/lib/cms/filter-engine";
import type { FilterValues } from "@/lib/cms/filter-engine";
import type { FilterDef } from "@/lib/cms/types";
import type { SortKey } from "@/lib/cms/filter-engine";
import { useCatalogReady } from "@/lib/catalog";

const SORTS = [
  { value: "popular", key: "store.sortPopular" },
  { value: "rating", key: "store.sortRating" },
  { value: "price-asc", key: "store.sortPriceAsc" },
  { value: "price-desc", key: "store.sortPriceDesc" },
  { value: "discount", key: "store.sortDiscount" },
  { value: "newest", key: "store.sortNewest" },
] as const;

type SortValue = (typeof SORTS)[number]["value"];

const PER_PAGE = 12;

/* ————— fallback فیلترهای پیش‌فرض (وقتی DB خالی است) ————— */
function defaultFilterDefs(): FilterDef[] {
  return [
    {
      id: "def-genre",
      key: "genre",
      labelFa: "ژانر",
      labelEn: "Genre",
      type: "multiselect",
      options: ALL_GENRES.map((g) => ({ value: g, labelFa: g })),
      meta: { field: "genres" },
      order: 1,
      enabled: true,
    },
    {
      id: "def-mode",
      key: "mode",
      labelFa: "حالت بازی",
      labelEn: "Mode",
      type: "multiselect",
      options: ALL_MODES.map((m) => ({ value: m, labelFa: m })),
      meta: { field: "modes" },
      order: 2,
      enabled: true,
    },
    {
      id: "def-price",
      key: "price",
      labelFa: "سقف قیمت",
      labelEn: "Max price",
      type: "price",
      options: [],
      meta: { field: "price", min: 100_000, max: 2_500_000, step: 50_000, unitFa: "تومان", unitEn: "Toman" },
      order: 3,
      enabled: true,
    },
    {
      id: "def-rating",
      key: "rating",
      labelFa: "حداقل امتیاز",
      labelEn: "Min rating",
      type: "rating",
      options: [],
      meta: { field: "rating", min: 0, max: 5, step: 0.5 },
      order: 4,
      enabled: true,
    },
  ];
}

/* ————— استور کوچک تعریف فیلترها — یک‌بار در طول عمر صفحه ————— */
let cachedDefs: FilterDef[] | null = null;
let defsInFlight: Promise<FilterDef[]> | null = null;

async function loadFilterDefs(): Promise<FilterDef[]> {
  if (cachedDefs) return cachedDefs;
  if (!defsInFlight) {
    defsInFlight = fetch("/api/filters", { cache: "no-cache" })
      .then((r) => r.json())
      .then((d: { ok: boolean; filters?: FilterDef[] }) => {
        const defs = d.ok && Array.isArray(d.filters) && d.filters.length > 0 ? d.filters : defaultFilterDefs();
        cachedDefs = defs;
        return defs;
      })
      .catch(() => {
        cachedDefs = defaultFilterDefs();
        return cachedDefs;
      })
      .finally(() => {
        defsInFlight = null;
      });
  }
  return defsInFlight;
}

/* ————— کنترل یک فیلتر بر اساس نوع ————— */
function FilterControl({
  def,
  value,
  onChange,
  lang,
  dir,
}: {
  def: FilterDef;
  value: FilterValues[string] | undefined;
  onChange: (v: FilterValues[string] | null) => void;
  lang: "fa" | "en";
  dir: "rtl" | "ltr";
}) {
  const t = useT();
  const f = useFmt();
  const label = lang === "en" ? def.labelEn || def.labelFa : def.labelFa;
  const metaMin = typeof def.meta.min === "number" ? def.meta.min : 0;
  const metaMax = typeof def.meta.max === "number" ? def.meta.max : 100;
  const metaStep = typeof def.meta.step === "number" ? def.meta.step : 1;

  switch (def.type) {
    case "text":
      return (
        <div>
          <p className="mb-2 text-xs font-bold text-muted-foreground">{label}</p>
          <Input
            value={typeof value === "string" ? value : ""}
            onChange={(e) => onChange(e.target.value || null)}
            placeholder={label}
            aria-label={label}
          />
        </div>
      );

    case "number":
      return (
        <div>
          <p className="mb-2 text-xs font-bold text-muted-foreground">{label}</p>
          <Input
            type="number"
            value={typeof value === "number" ? String(value) : ""}
            min={metaMin}
            max={metaMax}
            step={metaStep}
            onChange={(e) => onChange(e.target.value === "" ? null : Number(e.target.value))}
            aria-label={label}
            className="tnum"
          />
        </div>
      );

    case "select":
      return (
        <Select value={typeof value === "string" ? value : "all"} onValueChange={(v) => onChange(v === "all" ? null : v)} dir={dir}>
          <SelectTrigger aria-label={label}>
            <span className="text-muted-foreground text-xs">{label}</span>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{lang === "en" ? "All" : "همه"}</SelectItem>
            {def.options.map((o) => (
              <SelectItem key={o.value} value={o.value}>
                {lang === "en" ? o.labelEn || o.labelFa : o.labelFa}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      );

    case "multiselect": {
      const selected = Array.isArray(value) ? (value as string[]) : [];
      return (
        <div>
          <p className="mb-2 text-xs font-bold text-muted-foreground">{label}</p>
          <div className="flex flex-wrap gap-1.5">
            {def.options.map((o) => {
              const on = selected.includes(o.value);
              return (
                <button
                  key={o.value}
                  type="button"
                  onClick={() => onChange(on ? selected.filter((x) => x !== o.value) : [...selected, o.value])}
                  className={cn(
                    "rounded-full border px-3 py-1 text-xs font-bold transition-colors",
                    on ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-muted-foreground hover:text-foreground"
                  )}
                  aria-pressed={on}
                >
                  {lang === "en" ? o.labelEn || o.labelFa : o.labelFa}
                </button>
              );
            })}
          </div>
        </div>
      );
    }

    case "boolean":
      return (
        <div className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card/60 px-3 py-2.5">
          <span className="text-xs font-bold">{label}</span>
          <Switch checked={value === true} onCheckedChange={(v) => onChange(v ? true : null)} aria-label={label} />
        </div>
      );

    case "price":
    case "range":
    case "daterange": {
      const pair = Array.isArray(value) && typeof value[0] === "number" ? ([value[0], value[1]] as [number, number]) : null;
      const isPrice = def.type === "price";
      const lo = pair?.[0] ?? metaMin;
      const hi = pair?.[1] ?? metaMax;
      const fmt = (v: number) => (isPrice ? f.toman(v) : f.num(v));
      return (
        <div>
          <div className="mb-2 flex justify-between text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <Filter className="size-3.5" />
              {label}
            </span>
            <span className="font-bold text-foreground tnum">
              {pair ? `${fmt(lo)} – ${fmt(hi)}` : lang === "en" ? "No cap" : "بدون محدودیت"}
            </span>
          </div>
          <Slider
            value={[lo, hi]}
            min={metaMin}
            max={metaMax}
            step={metaStep}
            onValueChange={([a, b]) => onChange(a <= b ? [a, b] : [b, a])}
            aria-label={label}
          />
        </div>
      );
    }

    case "rating": {
      const v = typeof value === "number" ? value : 0;
      return (
        <div>
          <div className="mb-2 flex justify-between text-xs text-muted-foreground">
            <span>{label}</span>
            <span className="font-bold text-foreground tnum">{v > 0 ? `${f.num(v)}+` : lang === "en" ? "All" : "همه"}</span>
          </div>
          <Slider
            value={[v]}
            min={0}
            max={metaMax}
            step={metaStep}
            onValueChange={([nv]) => onChange(nv > 0 ? nv : null)}
            aria-label={label}
          />
        </div>
      );
    }

    default:
      return null;
  }
}

function StorePage() {
  const route = useRoute();
  const hydrated = useHydrated();
  const catalogReady = useCatalogReady();
  const t = useT();
  const f = useFmt();
  const tx = useTx();
  const dir = useUiDir();
  const lang = useLang();

  const [defs, setDefs] = useState<FilterDef[]>(cachedDefs ?? []);
  const [page, setPage] = useState(1);

  useEffect(() => {
    let alive = true;
    loadFilterDefs().then((d) => {
      if (alive) setDefs(d);
    });
    return () => {
      alive = false;
    };
  }, []);

  const q = route.query.get("q") ?? "";
  const sort = (route.query.get("sort") ?? "popular") as SortValue;

  const values = useMemo(() => parseFilterParams(defs, route.query), [defs, route.query]);

  const setParam = (key: string, value: string | null) => {
    const next = new URLSearchParams(route.query.toString());
    if (value === null || value === "" || value === "all") next.delete(key);
    else next.set(key, value);
    const qs = next.toString();
    navigate(`/store${qs ? `?${qs}` : ""}`, { replace: true });
    setPage(1);
  };

  const setMany = (updates: Record<string, string | null>) => {
    const next = new URLSearchParams(route.query.toString());
    for (const [k, v] of Object.entries(updates)) {
      if (v === null || v === "" || v === "all") next.delete(k);
      else next.set(k, v);
    }
    const qs = next.toString();
    navigate(`/store${qs ? `?${qs}` : ""}`, { replace: true });
    setPage(1);
  };

  const results = useMemo(() => {
    let list = applyFilters(GAMES, defs, values);
    if (q.trim()) {
      const needle = q.trim().toLowerCase();
      list = list.filter(
        (g) => g.title.toLowerCase().includes(needle) || g.tagline.includes(needle) || g.description.includes(needle) || g.genres.some((x) => x.includes(needle))
      );
    }
    return sortGames(list, sort as SortKey);
  }, [defs, values, q, sort]);

  const paged = useMemo(() => paginate(results, page, PER_PAGE), [results, page]);

  const activeChips = useMemo(() => {
    const chips: { key: string; label: string }[] = [];
    for (const def of defs) {
      const v = values[def.key];
      if (v === undefined || v === null || v === false || (Array.isArray(v) && v.length === 0)) continue;
      chips.push({ key: def.key, label: `${lang === "en" ? def.labelEn || def.labelFa : def.labelFa}: ${valueLabel(def, v, lang)}` });
    }
    if (q) chips.push({ key: "q", label: `«${q}»` });
    return chips;
  }, [defs, values, q, lang]);

  const hasFilters = activeChips.length > 0 || sort !== "popular";

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-10 md:px-6">
      <header className="mb-8">
        <h1 className="text-3xl font-black">{t("store.heading")}</h1>
        <p className="mt-2 text-sm leading-7 text-muted-foreground">
          {t("store.desc", { n: f.num(catalogReady ? GAMES.length : 0) })}
        </p>
      </header>

      {/* نوار جستجو و مرتب‌سازی */}
      <div className="mb-6 space-y-4 rounded-2xl border border-border bg-card p-4">
        <div className="grid gap-3 md:grid-cols-[1.4fr_1fr]">
          <div className="relative">
            <Search className="absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setParam("q", e.target.value)}
              placeholder={t("store.searchPlaceholder")}
              className="ps-9"
              aria-label={t("store.searchAria")}
            />
          </div>
          <Select value={sort} onValueChange={(v) => setParam("sort", v)} dir={dir}>
            <SelectTrigger aria-label={t("store.sortAria")}>
              <SlidersHorizontal className="size-4 text-muted-foreground" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {SORTS.map((s) => (
                <SelectItem key={s.value} value={s.value}>
                  {t(s.key)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* فیلترهای پویا از CMS */}
        {defs.length > 0 ? (
          <div className="grid gap-4 border-t border-border pt-4 md:grid-cols-2 lg:grid-cols-3">
            {defs.map((def) => (
              <FilterControl
                key={def.id}
                def={def}
                value={values[def.key]}
                onChange={(v) => {
                  const params = filtersToParams(defs, { ...values, [def.key]: v });
                  const updates: Record<string, string | null> = { [def.key]: params[def.key] ?? null };
                  setMany(updates);
                }}
                lang={lang}
                dir={dir}
              />
            ))}
          </div>
        ) : null}

        {/* چیپ‌های فعال */}
        {activeChips.length > 0 ? (
          <div className="flex flex-wrap items-center gap-2 border-t border-border pt-3">
            {activeChips.map((chip) => (
              <button
                key={chip.key}
                type="button"
                onClick={() => (chip.key === "q" ? setParam("q", null) : setParam(chip.key, null))}
                className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary transition-colors hover:bg-primary/20"
              >
                {chip.label}
                <XCircle className="size-3.5" />
              </button>
            ))}
            <Button variant="ghost" onClick={() => navigate("/store", { replace: true })} className="gap-2 text-muted-foreground">
              <XCircle className="size-4" />
              {t("store.clearFilters")}
            </Button>
          </div>
        ) : null}
      </div>

      {/* نتیجه */}
      <div className="mb-4 flex items-center justify-between text-sm text-muted-foreground">
        <span className="tnum">
          {t("store.count", { n: f.num(results.length) })}
          {q ? <> {t("store.countFor", { q })}</> : null}
        </span>
        {hasFilters ? <span className="text-xs">{t("store.filtersShared")}</span> : null}
      </div>

      {!hydrated ? (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <GameCardSkeleton key={i} />
          ))}
        </div>
      ) : paged.items.length === 0 ? (
        <EmptyState
          icon={Search}
          title={t("store.emptyTitle")}
          description={t("store.emptyDesc")}
          action={
            <Button onClick={() => navigate("/store", { replace: true })} className="gap-2">
              <XCircle className="size-4" />
              {t("store.clearAllFilters")}
            </Button>
          }
        />
      ) : (
        <>
          <div className={cn("grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4")}>
            {paged.items.map((g, i) => (
              <GameCard key={g.id} game={g} index={i} />
            ))}
          </div>

          {/* صفحه‌بندی */}
          {paged.pages > 1 ? (
            <nav className="mt-8 flex items-center justify-center gap-2" aria-label="Pagination">
              <Button
                variant="outline"
                size="sm"
                disabled={paged.page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                aria-label={dir === "rtl" ? "Previous" : "Previous"}
              >
                <ChevronRight className="size-4 rtl:rotate-180" />
              </Button>
              <span className="tnum text-sm text-muted-foreground">
                {f.num(paged.page)} / {f.num(paged.pages)}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={paged.page >= paged.pages}
                onClick={() => setPage((p) => Math.min(paged.pages, p + 1))}
              >
                <ChevronLeft className="size-4 rtl:rotate-180" />
              </Button>
            </nav>
          ) : null}
        </>
      )}

      <p className="mt-10 text-center text-xs text-muted-foreground">
        {t("store.aiPromptPre")}{" "}
        <Link to="/ai" className="font-bold text-ai hover:underline">
          {t("store.aiQuizLink")}
        </Link>{" "}
        {t("store.aiPromptPost")}
      </p>
    </div>
  );
}

export { StorePage };
