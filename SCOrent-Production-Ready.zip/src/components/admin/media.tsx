"use client";

/* ————— کتابخانه رسانه — بارگذاری، جستجو، متادیتا، حذف ————— */

import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Image as ImageIcon, Search, Trash2, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { api } from "@/lib/auth";
import { useT } from "@/lib/i18n";
import { AdminError, AdminHeader } from "./ui";

interface MediaRow {
  id: string;
  name: string;
  mime: string;
  size: number;
  altFa: string | null;
  altEn: string | null;
  url: string;
  createdAt: string;
}

const MAX_UPLOAD = 1_500_000;

export function AdminMedia() {
  const t = useT();
  const [items, setItems] = useState<MediaRow[] | null>(null);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [q, setQ] = useState("");
  const [err, setErr] = useState(false);
  const [busy, setBusy] = useState(false);
  const [storage, setStorage] = useState("database");
  const [editing, setEditing] = useState<MediaRow | null>(null);
  const [altFa, setAltFa] = useState("");
  const [altEn, setAltEn] = useState("");
  const [deleting, setDeleting] = useState<MediaRow | null>(null);
  const [preview, setPreview] = useState<MediaRow | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try {
      const d = await api.get<{ ok: boolean; media: MediaRow[]; total: number; storage: string }>(`/api/admin/cms/media?page=${page}&q=${encodeURIComponent(q)}`);
      setItems(d.media);
      setTotal(d.total);
      setStorage(d.storage);
    } catch {
      setErr(true);
    }
  }, [page, q]);

  useEffect(() => {
    void load();
  }, [load]);

  async function upload(files: FileList | null) {
    if (!files || files.length === 0) return;
    setBusy(true);
    try {
      for (const file of Array.from(files).slice(0, 8)) {
        if (file.size > MAX_UPLOAD) {
          toast.error(t("admin.cms.fileTooLarge", { name: file.name }));
          continue;
        }
        const form = new FormData();
        form.append("file", file);
        const res = await fetch("/api/admin/cms/media/upload", { method: "POST", body: form, credentials: "same-origin" });
        const d = (await res.json()) as { ok: boolean; error?: string };
        if (!d.ok) throw new Error(d.error ?? "UPLOAD_FAILED");
      }
      toast.success(t("admin.cms.uploaded"));
      await load();
    } catch (e) {
      const code = e instanceof Error ? e.message : "";
      toast.error(code === "UNSUPPORTED_TYPE" ? t("admin.cms.unsupportedType") : t("admin.error"));
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function saveAlt() {
    if (!editing) return;
    setBusy(true);
    try {
      await api.patch(`/api/admin/cms/media/${editing.id}`, { altFa, altEn });
      toast.success(t("admin.cms.saved"));
      setEditing(null);
      await load();
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function remove(m: MediaRow) {
    setBusy(true);
    try {
      await api.del(`/api/admin/cms/media/${m.id}`);
      toast.success(t("admin.cms.deleted"));
      setDeleting(null);
      await load();
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  if (err) return <AdminError />;

  const pages = Math.max(1, Math.ceil(total / 30));

  return (
    <div>
      <AdminHeader
        kicker={t("admin.title")}
        title={t("admin.cms.mediaTitle")}
        description={t("admin.cms.mediaDesc")}
        icon={ImageIcon}
        action={
          <Button onClick={() => fileRef.current?.click()} disabled={busy} className="gap-2 bg-ai text-white hover:bg-ai/90">
            <Upload className="size-4" /> {t("admin.cms.upload")}
          </Button>
        }
      />
      <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif,image/avif" multiple hidden onChange={(e) => void upload(e.target.files)} />

      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="relative min-w-56 flex-1">
          <Search className="absolute inset-y-0 start-3 my-auto size-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} placeholder={t("admin.search")} className="ps-9" />
        </div>
        <span className="rounded-full bg-secondary px-3 py-1 text-[0.62rem] font-bold text-muted-foreground">
          {storage === "cloudinary" ? "Cloudinary" : t("admin.cms.storageDb")}
        </span>
        <span className="text-xs text-muted-foreground tnum">{total} {t("admin.cms.files")}</span>
      </div>

      <p className="mb-4 rounded-xl border border-amber-500/25 bg-amber-500/5 p-3 text-xs leading-6 text-amber-600 dark:text-amber-400">
        {t("admin.cms.mediaStorageNote")}
      </p>

      {!items ? (
        <div className="flex min-h-40 items-center justify-center"><span className="size-8 animate-spin rounded-full border-2 border-border border-t-ai" /></div>
      ) : items.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-secondary/20 p-8 text-center">
          <ImageIcon className="mx-auto size-8 text-muted-foreground/50" />
          <p className="mt-3 text-sm font-bold">{t("admin.cms.mediaEmpty")}</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-6">
          {items.map((m) => (
            <div key={m.id} className="group overflow-hidden rounded-2xl border border-border bg-card">
              <button type="button" onClick={() => setPreview(m)} className="block aspect-square w-full overflow-hidden bg-secondary/30">
                <img src={m.url} alt={m.altFa ?? m.altEn ?? m.name} loading="lazy" className="size-full object-cover transition-transform group-hover:scale-105" />
              </button>
              <div className="space-y-1.5 p-2">
                <p className="truncate text-[0.65rem] font-bold" title={m.name}>{m.name}</p>
                <p className="text-[0.6rem] text-muted-foreground tnum" dir="ltr">{Math.ceil(m.size / 1024)} KB</p>
                <div className="flex gap-1">
                  <Button size="sm" variant="ghost" className="h-6 flex-1 text-[0.62rem]" onClick={() => { setEditing(m); setAltFa(m.altFa ?? ""); setAltEn(m.altEn ?? ""); }}>
                    {t("admin.cms.edit")}
                  </Button>
                  <Button size="icon" variant="ghost" className="size-6 text-destructive hover:text-destructive" onClick={() => setDeleting(m)} aria-label={t("admin.cms.delete")}>
                    <Trash2 className="size-3" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {pages > 1 ? (
        <div className="mt-4 flex items-center justify-center gap-2">
          <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>{t("admin.cms.prev")}</Button>
          <span className="tnum text-xs text-muted-foreground">{page} / {pages}</span>
          <Button size="sm" variant="outline" disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>{t("admin.cms.next")}</Button>
        </div>
      ) : null}

      {/* پیش‌نمایش */}
      <Dialog open={Boolean(preview)} onOpenChange={(v) => !v && setPreview(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="truncate">{preview?.name}</DialogTitle>
            <DialogDescription dir="ltr">{preview?.mime} · {preview ? Math.ceil(preview.size / 1024) : 0} KB</DialogDescription>
          </DialogHeader>
          {preview ? (
            <img src={preview.url} alt={preview.altFa ?? preview.name} className="max-h-[50svh] w-full rounded-xl object-contain" />
          ) : null}
          <div className="rounded-xl bg-secondary/40 p-3 text-xs" dir="ltr">
            <code className="break-all">{preview?.url}</code>
          </div>
        </DialogContent>
      </Dialog>

      {/* ویرایش alt */}
      <Dialog open={Boolean(editing)} onOpenChange={(v) => !v && setEditing(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t("admin.cms.editMediaAlt")}</DialogTitle>
            <DialogDescription className="truncate">{editing?.name}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3">
            <div><Label className="mb-1.5 block text-xs font-bold">Alt (fa)</Label><Input value={altFa} onChange={(e) => setAltFa(e.target.value)} /></div>
            <div><Label className="mb-1.5 block text-xs font-bold">Alt (en)</Label><Input value={altEn} onChange={(e) => setAltEn(e.target.value)} dir="ltr" /></div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setEditing(null)}>{t("admin.cancel")}</Button>
            <Button onClick={saveAlt} disabled={busy}>{t("admin.save")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={Boolean(deleting)} onOpenChange={(v) => !v && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("admin.cms.deleteMediaTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("admin.cms.deleteMediaDesc", { name: deleting?.name ?? "" })}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("admin.cancel")}</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleting && remove(deleting)} className="bg-destructive text-white hover:bg-destructive/90">{t("admin.cms.delete")}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
