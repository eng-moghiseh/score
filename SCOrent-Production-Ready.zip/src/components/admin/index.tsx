"use client";

/* ————— پنل مدیریت: گارد نقش + پوسته‌ی زبانه‌ای —————
 * بهینه‌سازی: هر زبانه با next/dynamic بارگذاری می‌شود؛ کد داشبورد/کاربران/
 * تیکت‌ها و ... فقط با باز شدن همان زبانه دانلود می‌شود و هیچ‌کدام در بسته‌ی
 * اولیه‌ی کاربران عادی (صفحه‌ی اصلی، فروشگاه و ...) حضور ندارد.
 */

import dynamic from "next/dynamic";
import { useEffect, useMemo, useState } from "react";
import {
  Bell,
  Compass,
  FileText,
  Gamepad2,
  Image as ImageIcon,
  Inbox,
  LayoutDashboard,
  LifeBuoy,
  Loader2,
  ScrollText,
  Search,
  Settings2,
  Shapes,
  ShieldCheck,
  Users,
  Plug,
  Layers,
} from "lucide-react";
import { Link } from "@/components/scorent/router";
import { can, isStaff, useAuth } from "@/lib/auth";
import type { Perm } from "@/lib/auth";
import { useT } from "@/lib/i18n";
import { cn } from "@/lib/utils";

const TabSkeleton = () => (
  <div className="space-y-3" aria-hidden>
    <div className="h-16 animate-pulse rounded-2xl border border-border bg-card" />
    <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="h-24 animate-pulse rounded-2xl border border-border bg-card" />
      ))}
    </div>
    <div className="h-64 animate-pulse rounded-2xl border border-border bg-card" />
  </div>
);

const AdminDashboard = dynamic(() => import("./dashboard").then((m) => ({ default: m.AdminDashboard })), { ssr: false, loading: TabSkeleton });
const AdminUsers = dynamic(() => import("./users").then((m) => ({ default: m.AdminUsers })), { ssr: false, loading: TabSkeleton });
const AdminAdmins = dynamic(() => import("./admins").then((m) => ({ default: m.AdminAdmins })), { ssr: false, loading: TabSkeleton });
const AdminContent = dynamic(() => import("./content").then((m) => ({ default: m.AdminContent })), { ssr: false, loading: TabSkeleton });
const AdminGames = dynamic(() => import("./games").then((m) => ({ default: m.AdminGames })), { ssr: false, loading: TabSkeleton });
const AdminAnnouncements = dynamic(() => import("./notifications").then((m) => ({ default: m.AdminAnnouncements })), { ssr: false, loading: TabSkeleton });
const AdminOutbox = dynamic(() => import("./notifications").then((m) => ({ default: m.AdminOutbox })), { ssr: false, loading: TabSkeleton });
const AdminTickets = dynamic(() => import("./tickets").then((m) => ({ default: m.AdminTickets })), { ssr: false, loading: TabSkeleton });
const AdminProviders = dynamic(() => import("./providers").then((m) => ({ default: m.AdminProviders })), { ssr: false, loading: TabSkeleton });
const AuditLog = dynamic(() => import("./audit").then((m) => ({ default: m.AuditLog })), { ssr: false, loading: TabSkeleton });
const AdminCategories = dynamic(() => import("./categories").then((m) => ({ default: m.AdminCategories })), { ssr: false, loading: TabSkeleton });
const AdminFilters = dynamic(() => import("./filters").then((m) => ({ default: m.AdminFilters })), { ssr: false, loading: TabSkeleton });
const AdminNavigation = dynamic(() => import("./navigation").then((m) => ({ default: m.AdminNavigation })), { ssr: false, loading: TabSkeleton });
const AdminPages = dynamic(() => import("./pages").then((m) => ({ default: m.AdminPages })), { ssr: false, loading: TabSkeleton });
const AdminMedia = dynamic(() => import("./media").then((m) => ({ default: m.AdminMedia })), { ssr: false, loading: TabSkeleton });
const AdminSettings = dynamic(() => import("./settings").then((m) => ({ default: m.AdminSettings })), { ssr: false, loading: TabSkeleton });

interface TabDef {
  id: string;
  labelKey: string;
  icon: React.ElementType;
  perm: Perm;
}

const TABS: TabDef[] = [
  { id: "dashboard", labelKey: "admin.tab.dashboard", icon: LayoutDashboard, perm: "stats" },
  { id: "games", labelKey: "admin.tab.games", icon: Gamepad2, perm: "games" },
  { id: "categories", labelKey: "admin.tab.categories", icon: Shapes, perm: "cms" },
  { id: "filters", labelKey: "admin.tab.filters", icon: Search, perm: "cms" },
  { id: "navigation", labelKey: "admin.tab.navigation", icon: Compass, perm: "cms" },
  { id: "pages", labelKey: "admin.tab.pages", icon: Layers, perm: "cms" },
  { id: "media", labelKey: "admin.tab.media", icon: ImageIcon, perm: "cms" },
  { id: "settings", labelKey: "admin.tab.settings", icon: Settings2, perm: "cms" },
  { id: "content", labelKey: "admin.tab.content", icon: FileText, perm: "content" },
  { id: "users", labelKey: "admin.tab.users", icon: Users, perm: "users.read" },
  { id: "admins", labelKey: "admin.tab.admins", icon: ShieldCheck, perm: "admins.manage" },
  { id: "audit", labelKey: "admin.tab.audit", icon: ScrollText, perm: "admins.manage" },
  { id: "announce", labelKey: "admin.tab.announce", icon: Bell, perm: "notify" },
  { id: "outbox", labelKey: "admin.tab.outbox", icon: Inbox, perm: "notify" },
  { id: "tickets", labelKey: "admin.tab.tickets", icon: LifeBuoy, perm: "tickets" },
  { id: "providers", labelKey: "admin.tab.providers", icon: Plug, perm: "providers" },
];

export function AdminPage() {
  const t = useT();
  const { user, ready } = useAuth();
  const [tab, setTab] = useState<string>("dashboard");
  const [hashTab, setHashTab] = useState<string | null>(null);

  /* زبانه از مسیر: /admin/users و ... — با تغییر hash هم همگام می‌شود */
  useEffect(() => {
    if (typeof window === "undefined") return;
    const readHash = () => {
      const seg = window.location.hash.replace(/^#\/admin\/?/, "").split("?")[0];
      if (seg && TABS.some((x) => x.id === seg)) setHashTab(seg);
      else if (!seg && window.location.hash.replace(/^#\/?/, "") === "admin") setHashTab("dashboard");
    };
    readHash();
    window.addEventListener("hashchange", readHash);
    return () => window.removeEventListener("hashchange", readHash);
  }, []);

  useEffect(() => {
    if (hashTab && TABS.some((x) => x.id === hashTab)) setTab(hashTab);
  }, [hashTab]);

  if (!ready || !useAuth.getState().ready) {
    return (
      <div className="flex min-h-[50svh] items-center justify-center gap-3 text-sm font-bold text-muted-foreground">
        <Loader2 className="size-5 animate-spin" /> {t("admin.loading")}
      </div>
    );
  }

  if (!user || !isStaff(user.role)) {
    return (
      <div className="mx-auto flex min-h-[50svh] max-w-lg flex-col items-center justify-center gap-4 px-4 text-center">
        <ShieldCheck className="size-12 text-ai" />
        <h1 className="text-xl font-black">{t("admin.title")}</h1>
        <p className="text-sm leading-7 text-muted-foreground">{t(user ? "admin.noAccess" : "admin.signInFirst")}</p>
        {!user && (
          <Link to="/auth?next=/admin" className="rounded-xl bg-ai px-5 py-2.5 text-sm font-extrabold text-white hover:bg-ai/90">
            {t("admin.signIn")}
          </Link>
        )}
      </div>
    );
  }

  const visible = TABS.filter((x) => can(user.role, x.perm));

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-8 md:px-6 md:py-10">
      <div className="grid gap-6 lg:grid-cols-[220px_1fr]">
        {/* سایدبار زبانه‌ها */}
        <nav aria-label={t("admin.title")} className="lg:sticky lg:top-28 lg:self-start">
          <div className="flex gap-1.5 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible lg:pb-0" role="tablist">
            {visible.map(({ id, labelKey, icon: Icon }) => {
              const active = tab === id;
              return (
                <button
                  key={id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => {
                    setTab(id);
                    try {
                      window.history.replaceState(null, "", `#/admin/${id}`);
                    } catch {
                      /* ignore */
                    }
                  }}
                  className={cn(
                    "flex shrink-0 items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-sm font-bold transition-colors",
                    active ? "bg-ai/15 text-ai" : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                  )}
                >
                  <Icon className="size-4.5" />
                  {t(labelKey)}
                </button>
              );
            })}
            <Link to="/" className="mt-1 flex shrink-0 items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-sm font-bold text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground">
              ← {t("admin.backToSite")}
            </Link>
          </div>
        </nav>

        {/* محتوای زبانه */}
        <div className="min-w-0">
          {tab === "dashboard" && <AdminDashboard />}
          {tab === "games" && <AdminGames />}
          {tab === "categories" && <AdminCategories />}
          {tab === "filters" && <AdminFilters />}
          {tab === "navigation" && <AdminNavigation />}
          {tab === "pages" && <AdminPages />}
          {tab === "media" && <AdminMedia />}
          {tab === "settings" && <AdminSettings />}
          {tab === "content" && <AdminContent />}
          {tab === "users" && <AdminUsers />}
          {tab === "admins" && <AdminAdmins />}
          {tab === "audit" && <AuditLog />}
          {tab === "announce" && <AdminAnnouncements />}
          {tab === "outbox" && <AdminOutbox />}
          {tab === "tickets" && <AdminTickets />}
          {tab === "providers" && <AdminProviders />}
        </div>
      </div>
    </div>
  );
}
