"use client";

/* ————— گزارش حسابرسی — اقدامات حساس ثبت‌شده در سرور، با فیلتر و صفحه‌بندی ————— */

import { useCallback, useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, RefreshCcw, ScrollText, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { api } from "@/lib/auth";
import { useFmt, useLang, useT, useUiDir } from "@/lib/i18n";
import { AdminHeader } from "./ui";
import { cn } from "@/lib/utils";

interface AuditRow {
  id: string;
  actorId: string | null;
  action: string;
  target: string | null;
  meta: string | null;
  ip: string | null;
  createdAt: string;
}

const ACTION_TONE: Record<string, string> = {
  LOGIN_OK: "text-rent",
  LOGIN_FAIL: "text-destructive",
  ACCOUNT_CREATED: "text-rent",
  ACCOUNT_SUSPENDED: "text-destructive",
  ACCOUNT_UNSUSPENDED: "text-rent",
  USER_DELETED: "text-destructive",
  USERS_EXPORTED: "text-deal",
  ROLE_CHANGED: "text-deal",
  ADMIN_ADDED: "text-ai",
  ADMIN_REMOVED: "text-deal",
  PASSWORD_CHANGED: "text-ai",
  PASSWORD_RESET: "text-deal",
  PASSWORD_ROTATED_FROM_PUBLIC_DEFAULT: "text-destructive",
  SESSIONS_REVOKED: "text-deal",
  CONTENT_UPDATED: "text-ai",
  CONTENT_DELETED: "text-destructive",
  OVERRIDE_UPDATED: "text-ai",
  OVERRIDE_DELETED: "text-destructive",
  ANNOUNCEMENT_SENT: "text-ai",
  NOTIFICATION_RETRIED: "text-deal",
  TICKET_REPLIED: "text-ai",
  TICKET_STATUS_CHANGED: "text-deal",
  TEST_EMAIL_SENT: "text-deal",
  ADMIN_BOOTSTRAP: "text-ai",
};

/* فهرست اکشن‌های شناخته‌شده برای فیلتر */
const ACTIONS = [
  "LOGIN_OK",
  "LOGIN_FAIL",
  "ACCOUNT_CREATED",
  "ACCOUNT_SUSPENDED",
  "ACCOUNT_UNSUSPENDED",
  "USER_DELETED",
  "USERS_EXPORTED",
  "ROLE_CHANGED",
  "ADMIN_ADDED",
  "ADMIN_REMOVED",
  "PASSWORD_CHANGED",
  "PASSWORD_RESET",
  "SESSIONS_REVOKED",
  "CONTENT_UPDATED",
  "OVERRIDE_UPDATED",
  "ANNOUNCEMENT_SENT",
  "TICKET_REPLIED",
  "TICKET_STATUS_CHANGED",
];

const PAGE_SIZE = 25;

/** نسخه‌ی کامل گزارش حسابرسی — زبانه‌ی مستقل پنل */
export function AuditLog() {
  const t = useT();
  const lang = useLang();
  const dir = useUiDir();
  const f = useFmt();
  const [rows, setRows] = useState<AuditRow[] | null>(null);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [action, setAction] = useState("all");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(false);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const params = new URLSearchParams({ page: String(page), take: String(PAGE_SIZE) });
      if (action !== "all") params.set("action", action);
      const res = await api.get<{ ok: boolean; audit: AuditRow[]; total: number }>(`/api/admin/audit?${params.toString()}`);
      setRows(res.audit);
      setTotal(res.total);
      setErr(false);
    } catch {
      setErr(true);
    } finally {
      setBusy(false);
    }
  }, [page, action]);

  useEffect(() => {
    const id = setTimeout(() => void load(), 0);
    return () => clearTimeout(id);
  }, [load]);

  const fmtDate = (iso: string) => {
    const d = new Date(iso);
    return lang === "fa" ? d.toLocaleString("fa-IR", { dateStyle: "short", timeStyle: "short" }) : d.toLocaleString("en-US", { dateStyle: "short", timeStyle: "short" });
  };

  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div>
      <AdminHeader kicker={t("admin.title")} title={t("admin.audit.title")} description={t("admin.audit.desc")} icon={ScrollText} />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <Select dir={dir} value={action} onValueChange={(v) => { setAction(v); setPage(1); }}>
          <SelectTrigger className="w-56" aria-label={t("admin.audit.filter")}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("admin.users.all")}</SelectItem>
            {ACTIONS.map((a) => (
              <SelectItem key={a} value={a}>
                <span className="tnum" dir="ltr">{a}</span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button variant="outline" size="sm" onClick={() => void load()} disabled={busy} aria-label={t("admin.audit.refresh")} className="gap-1.5 text-xs">
          <RefreshCcw className={cn("size-3.5", busy && "animate-spin")} /> {t("admin.audit.refresh")}
        </Button>
        <span className="text-xs text-muted-foreground tnum">{f.num(total)}</span>
      </div>

      {err ? (
        <p className="rounded-2xl border border-destructive/30 bg-destructive/10 p-4 text-sm font-bold text-destructive">{t("admin.audit.error")}</p>
      ) : rows === null ? (
        <div className="space-y-2">{Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-10 animate-pulse rounded-2xl border border-border bg-card" />)}</div>
      ) : rows.length === 0 ? (
        <p className="rounded-3xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">{t("admin.audit.empty")}</p>
      ) : (
        <div className={cn("space-y-2 rounded-3xl border border-border bg-card p-5", busy && "opacity-55 transition-opacity")} dir={dir}>
          {rows.map((r) => (
            <div key={r.id} className="flex flex-wrap items-center gap-x-2 gap-y-1 border-b border-border/50 py-2.5 text-xs leading-6 last:border-0">
              <span className={cn("font-black tnum", ACTION_TONE[r.action] ?? "text-foreground")} dir="ltr">{r.action}</span>
              <span className="min-w-0 truncate text-muted-foreground" dir="ltr">{r.target ? `→ ${r.target}` : ""}</span>
              {r.meta && <span className="min-w-0 truncate text-muted-foreground/70" dir="ltr">({r.meta})</span>}
              <span className="ms-auto shrink-0 text-muted-foreground/60 tnum" title={r.ip ?? undefined}>
                {fmtDate(r.createdAt)}
              </span>
            </div>
          ))}

          {pages > 1 && (
            <div className="flex items-center justify-center gap-3 pt-3">
              <Button size="icon" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)} aria-label={t("admin.prev")} className="size-8">
                <ChevronRight className="size-4 rtl:hidden" />
                <ChevronLeft className="size-4 ltr:hidden" />
              </Button>
              <span className="text-xs font-bold text-muted-foreground tnum">{t("admin.page", { n: f.num(page), total: f.num(pages) })}</span>
              <Button size="icon" variant="outline" disabled={page >= pages} onClick={() => setPage((p) => p + 1)} aria-label={t("admin.next")} className="size-8">
                <ChevronLeft className="size-4 rtl:hidden" />
                <ChevronRight className="size-4 ltr:hidden" />
              </Button>
            </div>
          )}
        </div>
      )}

      <p className="mt-3 flex items-center gap-1.5 text-[0.65rem] text-muted-foreground">
        <ShieldCheck className="size-3.5 text-deal" /> {t("admin.audit.note")}
      </p>
    </div>
  );
}

/** نسخه‌ی فشرده برای پایین زبانه‌ی مدیران — سازگار با API صفحه‌بندی‌شده */
export function AuditTrail() {
  const t = useT();
  const lang = useLang();
  const dir = useUiDir();
  const [rows, setRows] = useState<AuditRow[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(false);

  const fmtDate = (iso: string) => {
    const d = new Date(iso);
    return lang === "fa" ? d.toLocaleString("fa-IR", { dateStyle: "short", timeStyle: "short" }) : d.toLocaleString("en-US", { dateStyle: "short", timeStyle: "short" });
  };

  const load = useCallback(async () => {
    setBusy(true);
    setErr(false);
    try {
      const res = await api.get<{ ok: boolean; audit: AuditRow[] }>("/api/admin/audit?take=40");
      setRows(res.audit);
    } catch {
      setErr(true);
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <section className="rounded-2xl border border-border bg-card p-5" aria-label={t("admin.audit.title")}>
      <div className="mb-3 flex items-center justify-between gap-3">
        <div>
          <h3 className="flex items-center gap-2 text-sm font-black">
            <ScrollText className="size-4 text-ai" /> {t("admin.audit.title")}
          </h3>
          <p className="mt-1 text-xs text-muted-foreground">{t("admin.audit.desc")}</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => void load()} disabled={busy} aria-label={t("admin.audit.refresh")}>
          <RefreshCcw className={cn("size-3.5", busy && "animate-spin")} /> {t("admin.audit.refresh")}
        </Button>
      </div>

      {err && <p className="text-xs font-bold text-destructive">{t("admin.audit.error")}</p>}
      {rows && rows.length === 0 && <p className="text-xs text-muted-foreground">{t("admin.audit.empty")}</p>}

      {rows && rows.length > 0 && (
        <ul className="divide-y divide-border/60" dir={dir}>
          {rows.map((r) => (
            <li key={r.id} className="flex flex-wrap items-center gap-x-2 gap-y-1 py-2 text-xs leading-6">
              <span className={cn("font-black tnum", ACTION_TONE[r.action] ?? "text-foreground")}>{r.action}</span>
              <span className="text-muted-foreground">{r.target ? `→ ${r.target}` : ""}</span>
              {r.meta && <span className="text-muted-foreground/70">({r.meta})</span>}
              <span className="ms-auto text-muted-foreground/60 tnum" title={r.ip ?? undefined}>
                {fmtDate(r.createdAt)}
              </span>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
