"use client";

/* ————— مدیرت ناوبری — هدر/موبایل/فوتر/سفارشی — درخت دوزبانه ————— */

import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { ChevronDown, ChevronUp, Plus, Save, Trash2, Pencil, Compass } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { api } from "@/lib/auth";
import { useT } from "@/lib/i18n";
import { AdminHeader, AdminError } from "./ui";
import { reloadNavigation } from "@/lib/cms/nav-client";
import type { NavLocation, NavNode } from "@/lib/cms/types";

const LOCATIONS: { value: NavLocation; key: string }[] = [
  { value: "header", key: "admin.cms.locHeader" },
  { value: "mobile", key: "admin.cms.locMobile" },
  { value: "footer", key: "admin.cms.locFooter" },
  { value: "custom", key: "admin.cms.locCustom" },
];

interface FlatNav extends Omit<NavNode, "children"> {
  depth: number;
}

function flatten(tree: NavNode[], depth = 0): FlatNav[] {
  const out: FlatNav[] = [];
  for (const n of tree) {
    out.push({ ...n, depth });
    if (n.children.length) out.push(...flatten(n.children, depth + 1));
  }
  return out;
}

interface FormState {
  id: string | null;
  location: NavLocation;
  parentId: string | null;
  labelFa: string;
  labelEn: string;
  href: string;
  icon: string;
  descFa: string;
  descEn: string;
  newTab: boolean;
  enabled: boolean;
}

const emptyForm = (location: NavLocation): FormState => ({
  id: null, location, parentId: null, labelFa: "", labelEn: "", href: "", icon: "", descFa: "", descEn: "", newTab: false, enabled: true,
});

export function AdminNavigation() {
  const t = useT();
  const [byLocation, setByLocation] = useState<Record<string, NavNode[]> | null>(null);
  const [err, setErr] = useState(false);
  const [location, setLocation] = useState<NavLocation>("header");
  const [form, setForm] = useState<FormState>(emptyForm("header"));
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [deleting, setDeleting] = useState<FlatNav | null>(null);

  async function load() {
    try {
      const d = await api.get<{ ok: boolean; byLocation: Record<string, NavNode[]> }>("/api/admin/cms/nav");
      setByLocation(d.byLocation);
    } catch {
      setErr(true);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  const flat = useMemo(() => flatten(byLocation?.[location] ?? []), [byLocation, location]);

  function openAdd(parent: { id: string } | null) {
    setForm({ ...emptyForm(location), parentId: parent?.id ?? null });
    setOpen(true);
  }

  function openEdit(n: FlatNav) {
    setForm({
      id: n.id, location: n.location as NavLocation, parentId: n.parentId,
      labelFa: n.labelFa, labelEn: n.labelEn, href: n.href, icon: n.icon ?? "",
      descFa: n.descFa ?? "", descEn: n.descEn ?? "", newTab: n.newTab, enabled: n.enabled,
    });
    setOpen(true);
  }

  async function save() {
    if (!form.labelFa || !form.href) {
      toast.error(t("admin.cms.invalid"));
      return;
    }
    setBusy(true);
    try {
      const body = {
        location: form.location, parentId: form.parentId,
        labelFa: form.labelFa, labelEn: form.labelEn || form.labelFa, href: form.href,
        icon: form.icon || undefined, descFa: form.descFa || undefined, descEn: form.descEn || undefined,
        newTab: form.newTab, enabled: form.enabled,
      };
      if (form.id) await api.patch(`/api/admin/cms/nav/${form.id}`, body);
      else await api.post("/api/admin/cms/nav", body);
      toast.success(t("admin.cms.saved"));
      setOpen(false);
      await load();
      reloadNavigation();
    } catch (e) {
      const code = e instanceof Error ? e.message : "";
      toast.error(code === "CYCLE_FORBIDDEN" ? t("admin.cms.cycle") : t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function remove(n: FlatNav) {
    setBusy(true);
    try {
      await api.del(`/api/admin/cms/nav/${n.id}`);
      toast.success(t("admin.cms.deleted"));
      setDeleting(null);
      await load();
      reloadNavigation();
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function move(n: FlatNav, dir: -1 | 1) {
    const siblings = flat.filter((x) => x.parentId === n.parentId);
    const localIdx = siblings.findIndex((x) => x.id === n.id);
    const swapWith = siblings[localIdx + dir];
    if (!swapWith) return;
    try {
      await api.patch(`/api/admin/cms/nav/${swapWith.id}`, { order: n.order });
      await api.patch(`/api/admin/cms/nav/${n.id}`, { order: swapWith.order });
      await load();
      reloadNavigation();
    } catch {
      toast.error(t("admin.error"));
    }
  }

  if (err) return <AdminError />;

  return (
    <div>
      <AdminHeader
        kicker={t("admin.title")}
        title={t("admin.cms.navTitle")}
        description={t("admin.cms.navDesc")}
        icon={Compass}
        action={
          <Button onClick={() => openAdd(null)} className="gap-2 bg-ai text-white hover:bg-ai/90">
            <Plus className="size-4" /> {t("admin.cms.addItem")}
          </Button>
        }
      />

      {/* تب مکان‌ها */}
      <div className="mb-5 flex flex-wrap gap-2">
        {LOCATIONS.map((loc) => (
          <button
            key={loc.value}
            type="button"
            onClick={() => setLocation(loc.value)}
            className={`rounded-full px-4 py-2 text-xs font-extrabold transition-colors ${location === loc.value ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
          >
            {t(loc.key)}
            <span className="ms-1.5 tnum text-[0.62rem] opacity-70">{(byLocation?.[loc.value] ?? []).length}</span>
          </button>
        ))}
      </div>

      {!byLocation ? (
        <div className="flex min-h-40 items-center justify-center"><span className="size-8 animate-spin rounded-full border-2 border-border border-t-ai" /></div>
      ) : flat.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-secondary/20 p-8 text-center">
          <Compass className="mx-auto size-8 text-muted-foreground/50" />
          <p className="mt-3 text-sm font-bold">{t("admin.cms.navEmpty")}</p>
          <p className="mt-1 text-xs text-muted-foreground">{t("admin.cms.navEmptyDesc")}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {flat.map((n) => (
            <div
              key={n.id}
              className="flex flex-wrap items-center gap-3 rounded-2xl border border-border bg-card p-3"
              style={{ marginInlineStart: `${Math.min(n.depth, 3) * 1.5}rem` }}
            >
              <div className="min-w-40 flex-1">
                <p className="flex flex-wrap items-center gap-2 text-sm font-extrabold">
                  {n.labelFa}
                  <span className="rounded-full bg-secondary px-2 py-0.5 text-[0.62rem] text-muted-foreground" dir="ltr">{n.href}</span>
                  {n.newTab ? <span className="rounded-full bg-sky-500/15 px-2 py-0.5 text-[0.62rem] font-extrabold text-sky-500">↗</span> : null}
                  {!n.enabled ? <span className="rounded-full bg-zinc-500/20 px-2 py-0.5 text-[0.62rem] font-extrabold text-zinc-400">{t("admin.cms.disabled")}</span> : null}
                </p>
                {n.labelEn ? <p className="text-xs text-muted-foreground" dir="ltr">{n.labelEn}</p> : null}
              </div>
              <div className="flex items-center gap-1">
                <Button size="icon" variant="ghost" onClick={() => move(n, -1)} aria-label={t("admin.cms.moveUp")}><ChevronUp className="size-4" /></Button>
                <Button size="icon" variant="ghost" onClick={() => move(n, 1)} aria-label={t("admin.cms.moveDown")}><ChevronDown className="size-4" /></Button>
                <Button size="sm" variant="ghost" onClick={() => openAdd(n)} className="gap-1.5"><Plus className="size-3.5" /> {t("admin.cms.addChild")}</Button>
                <Button size="sm" variant="ghost" onClick={() => openEdit(n)} className="gap-1.5"><Pencil className="size-3.5" /> {t("admin.cms.edit")}</Button>
                <Button size="icon" variant="ghost" onClick={() => setDeleting(n)} className="text-destructive hover:text-destructive" aria-label={t("admin.cms.delete")}><Trash2 className="size-4" /></Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={(v) => !v && setOpen(false)}>
        <DialogContent className="max-h-[90svh] overflow-y-auto sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>{form.id ? t("admin.cms.editItem") : t("admin.cms.addItem")}</DialogTitle>
            <DialogDescription>{t("admin.cms.navFormDesc")}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fLocation")}</Label>
              <select
                value={form.location}
                onChange={(e) => setForm((s) => ({ ...s, location: e.target.value as NavLocation }))}
                className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm"
                disabled={Boolean(form.id)}
              >
                {LOCATIONS.map((l) => (
                  <option key={l.value} value={l.value}>{t(l.key)}</option>
                ))}
              </select>
            </div>
            <div>
              <Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fParent")}</Label>
              <select
                value={form.parentId ?? ""}
                onChange={(e) => setForm((s) => ({ ...s, parentId: e.target.value || null }))}
                className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm"
              >
                <option value="">{t("admin.cms.noParent")}</option>
                {flat.filter((x) => x.id !== form.id).map((x) => (
                  <option key={x.id} value={x.id}>{`${"　".repeat(x.depth)}${x.labelFa}`}</option>
                ))}
              </select>
            </div>
            <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fLabelFa")}</Label><Input value={form.labelFa} onChange={(e) => setForm((s) => ({ ...s, labelFa: e.target.value }))} /></div>
            <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fLabelEn")}</Label><Input value={form.labelEn} onChange={(e) => setForm((s) => ({ ...s, labelEn: e.target.value }))} dir="ltr" /></div>
            <div className="md:col-span-2"><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fHref")}</Label><Input value={form.href} onChange={(e) => setForm((s) => ({ ...s, href: e.target.value }))} dir="ltr" placeholder="/store یا https://…" /></div>
            <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fIcon")}</Label><Input value={form.icon} onChange={(e) => setForm((s) => ({ ...s, icon: e.target.value }))} dir="ltr" /></div>
            <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fDescFa")}</Label><Input value={form.descFa} onChange={(e) => setForm((s) => ({ ...s, descFa: e.target.value }))} /></div>
            <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fDescEn")}</Label><Input value={form.descEn} onChange={(e) => setForm((s) => ({ ...s, descEn: e.target.value }))} dir="ltr" /></div>
            <label className="flex items-center gap-2 text-xs font-bold"><Switch checked={form.newTab} onCheckedChange={(v) => setForm((s) => ({ ...s, newTab: v }))} /> {t("admin.cms.fNewTab")}</label>
            <label className="flex items-center gap-2 text-xs font-bold"><Switch checked={form.enabled} onCheckedChange={(v) => setForm((s) => ({ ...s, enabled: v }))} /> {t("admin.cms.enabled")}</label>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>{t("admin.cancel")}</Button>
            <Button onClick={save} disabled={busy || !form.labelFa || !form.href} className="gap-2"><Save className="size-4" /> {t("admin.save")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={Boolean(deleting)} onOpenChange={(v) => !v && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("admin.cms.deleteNavTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("admin.cms.deleteNavDesc", { name: deleting?.labelFa ?? "" })}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("admin.cancel")}</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleting && remove(deleting)} className="bg-destructive text-white hover:bg-destructive/90">{t("admin.cms.delete")}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
