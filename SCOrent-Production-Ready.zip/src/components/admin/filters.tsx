"use client";

/* ————— سازنده‌ی پویای فیلترها — تعریف فیلترهای فروشگاه بدون تغییر سورس ————— */

import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { ChevronDown, ChevronUp, Plus, Save, SlidersHorizontal, Trash2, Pencil, GripVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { api } from "@/lib/auth";
import { useT } from "@/lib/i18n";
import { AdminHeader, AdminError } from "./ui";
import { FILTER_TYPES } from "@/lib/cms/types";
import type { FilterDef, FilterOption, FilterType } from "@/lib/cms/types";

interface FormState {
  id: string | null;
  key: string;
  labelFa: string;
  labelEn: string;
  type: FilterType;
  optionsText: string; // هر خط: value|labelFa|labelEn
  field: string;
  min: string;
  max: string;
  step: string;
  unitFa: string;
  unitEn: string;
  enabled: boolean;
}

const emptyForm = (): FormState => ({
  id: null, key: "", labelFa: "", labelEn: "", type: "multiselect", optionsText: "",
  field: "", min: "", max: "", step: "", unitFa: "", unitEn: "", enabled: true,
});

function optionsFromText(text: string): FilterOption[] {
  return text
    .split("\n")
    .map((line) => line.split("|").map((p) => p.trim()))
    .filter((p) => p[0])
    .map((p) => ({ value: p[0], labelFa: p[1] || p[0], labelEn: p[2] || undefined }));
}

function textFromOptions(options: FilterOption[]): string {
  return options.map((o) => `${o.value}|${o.labelFa}|${o.labelEn ?? ""}`).join("\n");
}

const NEEDS_OPTIONS: FilterType[] = ["select", "multiselect"];

export function AdminFilters() {
  const t = useT();
  const [filters, setFilters] = useState<FilterDef[] | null>(null);
  const [err, setErr] = useState(false);
  const [form, setForm] = useState<FormState>(emptyForm());
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [deleting, setDeleting] = useState<FilterDef | null>(null);

  async function load() {
    try {
      const d = await api.get<{ ok: boolean; filters: FilterDef[] }>("/api/admin/cms/filters");
      setFilters(d.filters);
    } catch {
      setErr(true);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  const sorted = useMemo(() => [...(filters ?? [])].sort((a, b) => a.order - b.order), [filters]);

  function openAdd() {
    setForm(emptyForm());
    setOpen(true);
  }

  function openEdit(fd: FilterDef) {
    setForm({
      id: fd.id,
      key: fd.key,
      labelFa: fd.labelFa,
      labelEn: fd.labelEn,
      type: fd.type,
      optionsText: textFromOptions(fd.options),
      field: fd.meta.field ?? fd.key,
      min: String(fd.meta.min ?? ""),
      max: String(fd.meta.max ?? ""),
      step: String(fd.meta.step ?? ""),
      unitFa: fd.meta.unitFa ?? "",
      unitEn: fd.meta.unitEn ?? "",
      enabled: fd.enabled,
    });
    setOpen(true);
  }

  async function save() {
    if (!form.key || !form.labelFa) {
      toast.error(t("admin.cms.invalid"));
      return;
    }
    if (NEEDS_OPTIONS.includes(form.type) && optionsFromText(form.optionsText).length === 0) {
      toast.error(t("admin.cms.optionsRequired"));
      return;
    }
    setBusy(true);
    try {
      const options = NEEDS_OPTIONS.includes(form.type) ? optionsFromText(form.optionsText) : [];
      const meta: Record<string, unknown> = {};
      if (form.field) meta.field = form.field;
      if (form.min !== "") meta.min = Number(form.min);
      if (form.max !== "") meta.max = Number(form.max);
      if (form.step !== "") meta.step = Number(form.step);
      if (form.unitFa) meta.unitFa = form.unitFa;
      if (form.unitEn) meta.unitEn = form.unitEn;
      const body = {
        key: form.key, labelFa: form.labelFa, labelEn: form.labelEn || form.labelFa,
        type: form.type, options, meta,
        enabled: form.enabled,
      };
      if (form.id) await api.patch(`/api/admin/cms/filters/${form.id}`, body);
      else await api.post("/api/admin/cms/filters", body);
      toast.success(t("admin.cms.saved"));
      setOpen(false);
      await load();
    } catch (e) {
      const code = e instanceof Error ? e.message : "";
      toast.error(code === "KEY_TAKEN" ? t("admin.cms.keyTaken") : t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function remove(fd: FilterDef) {
    setBusy(true);
    try {
      await api.del(`/api/admin/cms/filters/${fd.id}`);
      toast.success(t("admin.cms.deleted"));
      setDeleting(null);
      await load();
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function toggleEnabled(fd: FilterDef, enabled: boolean) {
    try {
      await api.patch(`/api/admin/cms/filters/${fd.id}`, { enabled });
      await load();
    } catch {
      toast.error(t("admin.error"));
    }
  }

  async function move(fd: FilterDef, dir: -1 | 1) {
    const idx = sorted.findIndex((x) => x.id === fd.id);
    const swapWith = sorted[idx + dir];
    if (!swapWith) return;
    try {
      await api.patch(`/api/admin/cms/filters/${swapWith.id}`, { order: fd.order });
      await api.patch(`/api/admin/cms/filters/${fd.id}`, { order: swapWith.order });
      await load();
    } catch {
      toast.error(t("admin.error"));
    }
  }

  if (err) return <AdminError />;

  return (
    <div>
      <AdminHeader
        kicker={t("admin.title")}
        title={t("admin.cms.filtersTitle")}
        description={t("admin.cms.filtersDesc")}
        icon={SlidersHorizontal}
        action={
          <Button onClick={openAdd} className="gap-2 bg-ai text-white hover:bg-ai/90">
            <Plus className="size-4" /> {t("admin.cms.addFilter")}
          </Button>
        }
      />

      {!filters ? (
        <div className="flex min-h-40 items-center justify-center"><span className="size-8 animate-spin rounded-full border-2 border-border border-t-ai" /></div>
      ) : sorted.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-secondary/20 p-8 text-center">
          <SlidersHorizontal className="mx-auto size-8 text-muted-foreground/50" />
          <p className="mt-3 text-sm font-bold">{t("admin.cms.filtersEmpty")}</p>
          <p className="mt-1 text-xs text-muted-foreground">{t("admin.cms.filtersEmptyDesc")}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {sorted.map((fd) => (
            <div key={fd.id} className="flex flex-wrap items-center gap-3 rounded-2xl border border-border bg-card p-3">
              <GripVertical className="size-4 text-muted-foreground/50" />
              <div className="min-w-40 flex-1">
                <p className="flex flex-wrap items-center gap-2 text-sm font-extrabold">
                  {fd.labelFa}
                  <span className="rounded-full bg-secondary px-2 py-0.5 text-[0.62rem] text-muted-foreground" dir="ltr">{fd.key}</span>
                  <span className="rounded-full bg-ai/15 px-2 py-0.5 text-[0.62rem] font-extrabold text-ai" dir="ltr">{fd.type}</span>
                </p>
                <p className="text-xs text-muted-foreground" dir="ltr">{fd.labelEn} · field: {fd.meta.field ?? fd.key}</p>
              </div>
              <label className="flex items-center gap-2 text-xs font-bold text-muted-foreground">
                <Switch checked={fd.enabled} onCheckedChange={(v) => toggleEnabled(fd, v)} />
                {fd.enabled ? t("admin.cms.on") : t("admin.cms.off")}
              </label>
              <div className="flex items-center gap-1">
                <Button size="icon" variant="ghost" onClick={() => move(fd, -1)} aria-label={t("admin.cms.moveUp")}><ChevronUp className="size-4" /></Button>
                <Button size="icon" variant="ghost" onClick={() => move(fd, 1)} aria-label={t("admin.cms.moveDown")}><ChevronDown className="size-4" /></Button>
                <Button size="sm" variant="ghost" onClick={() => openEdit(fd)} className="gap-1.5"><Pencil className="size-3.5" /> {t("admin.cms.edit")}</Button>
                <Button size="icon" variant="ghost" onClick={() => setDeleting(fd)} className="text-destructive hover:text-destructive" aria-label={t("admin.cms.delete")}><Trash2 className="size-4" /></Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={(v) => !v && setOpen(false)}>
        <DialogContent className="max-h-[90svh] overflow-y-auto sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>{form.id ? t("admin.cms.editFilter") : t("admin.cms.addFilter")}</DialogTitle>
            <DialogDescription>{t("admin.cms.filterFormDesc")}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fKey")}</Label>
                <Input value={form.key} onChange={(e) => setForm((s) => ({ ...s, key: e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, "") }))} dir="ltr" disabled={Boolean(form.id)} placeholder="platform" />
              </div>
              <div>
                <Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fType")}</Label>
                <select
                  value={form.type}
                  onChange={(e) => setForm((s) => ({ ...s, type: e.target.value as FilterType }))}
                  className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm"
                  dir="ltr"
                >
                  {FILTER_TYPES.map((ft) => (
                    <option key={ft} value={ft}>{ft}</option>
                  ))}
                </select>
              </div>
              <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fLabelFa")}</Label><Input value={form.labelFa} onChange={(e) => setForm((s) => ({ ...s, labelFa: e.target.value }))} /></div>
              <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fLabelEn")}</Label><Input value={form.labelEn} onChange={(e) => setForm((s) => ({ ...s, labelEn: e.target.value }))} dir="ltr" /></div>
              <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fField")}</Label><Input value={form.field} onChange={(e) => setForm((s) => ({ ...s, field: e.target.value }))} dir="ltr" placeholder="platforms / year / price …" /></div>
              {NEEDS_OPTIONS.includes(form.type) ? (
                <div className="md:col-span-2">
                  <Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fOptions")}</Label>
                  <Textarea value={form.optionsText} onChange={(e) => setForm((s) => ({ ...s, optionsText: e.target.value }))} rows={5} dir="ltr" placeholder={"PC|کامپیوتر|PC\nPS5|پلی‌استیشن ۵|PlayStation 5"} />
                </div>
              ) : (
                <>
                  <div><Label className="mb-1.5 block text-xs font-bold">min</Label><Input value={form.min} onChange={(e) => setForm((s) => ({ ...s, min: e.target.value }))} dir="ltr" inputMode="numeric" /></div>
                  <div><Label className="mb-1.5 block text-xs font-bold">max</Label><Input value={form.max} onChange={(e) => setForm((s) => ({ ...s, max: e.target.value }))} dir="ltr" inputMode="numeric" /></div>
                  <div><Label className="mb-1.5 block text-xs font-bold">step</Label><Input value={form.step} onChange={(e) => setForm((s) => ({ ...s, step: e.target.value }))} dir="ltr" inputMode="decimal" /></div>
                  <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fUnitFa")}</Label><Input value={form.unitFa} onChange={(e) => setForm((s) => ({ ...s, unitFa: e.target.value }))} /></div>
                  <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fUnitEn")}</Label><Input value={form.unitEn} onChange={(e) => setForm((s) => ({ ...s, unitEn: e.target.value }))} dir="ltr" /></div>
                </>
              )}
            </div>
            <label className="flex items-center gap-2 text-xs font-bold">
              <Switch checked={form.enabled} onCheckedChange={(v) => setForm((s) => ({ ...s, enabled: v }))} />
              {t("admin.cms.enabled")}
            </label>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>{t("admin.cancel")}</Button>
            <Button onClick={save} disabled={busy || !form.key || !form.labelFa} className="gap-2"><Save className="size-4" /> {t("admin.save")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={Boolean(deleting)} onOpenChange={(v) => !v && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("admin.cms.deleteFilterTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("admin.cms.deleteFilterDesc", { key: deleting?.key ?? "" })}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("admin.cancel")}</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleting && remove(deleting)} className="bg-destructive text-white hover:bg-destructive/90">{t("admin.cms.delete")}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
