"use client";

/* ————— مدیریت بازی‌ها — افزودن بازی جدید + اورراید دیتاست —————
 * بخش ۱: بازی‌های سفارشی (CRUD کامل با فرم حرفه‌ای + پیش‌نمایش زنده‌ی کاور)
 * بخش ۲: اورراید روی دیتاست اصلی (نمایش/پنهان، ویژه، تخفیف، متن‌ها)
 * پس از هر ذخیره، refreshCatalog کاتالوگ زنده‌ی کل سایت را به‌روز می‌کند.
 */

import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Gamepad2, Pencil, Plus, RotateCcw, Save, Search, EyeOff, Trash2, Store, Archive, ArchiveRestore, Copy, Layers, Globe, FileEdit } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GAMES } from "@/lib/data/games";
import { api, useAuth } from "@/lib/auth";
import { useFmt, useT } from "@/lib/i18n";
import { refreshCatalog, datasetHas, useCatalog } from "@/lib/catalog";
import type { GameOverrideData } from "@/lib/catalog";
import { MOTIFS, STRUCTURES, TRIAL_KINDS, autoPalette, lenientGame, sanitizeGameInput, slugify, slugOk } from "@/lib/game-schema";
import { ALL_GENRES, ALL_MODES, ALL_PLAYSTYLES } from "@/lib/types";
import type { CoverMotif, Game, Genre, GameMode, Playstyle, Structure, TrialKind } from "@/lib/types";
import { GameCover } from "@/components/scorent/game-cover";
import { AdminHeader, AdminError } from "./ui";
import { cn } from "@/lib/utils";

interface OverrideRow {
  gameId: string;
  data: string;
  updatedAt: string;
}

interface CustomGameRow {
  id: string;
  game: Game;
  updatedAt: string;
  createdBy?: string | null;
}

/* ————— فرم کامل بازی — حالت‌های افزودن و ویرایش ————— */

interface GameForm {
  id: string;
  title: string;
  developer: string;
  year: string;
  tagline: string;
  taglineEn: string;
  description: string;
  descriptionEn: string;
  highlights: string;
  genres: Genre[];
  playstyles: Playstyle[];
  structure: Structure;
  modes: GameMode[];
  sessionMin: string;
  sessionMax: string;
  hasCampaign: boolean;
  campaignMin: string;
  campaignMax: string;
  rating: number;
  popularity: number;
  price: string;
  originalPrice: string;
  rentalAvailable: boolean;
  d1: string;
  d3: string;
  d7: string;
  indie: boolean;
  featured: boolean;
  available: boolean;
  trialKind: TrialKind;
  trialNote: string;
  palette: [string, string, string];
  motif: CoverMotif;
  /* ————— فیلدهای CMS ————— */
  coverUrl: string;
  gallery: string;
  trailerUrl: string;
  publisher: string;
  platforms: string;
  languages: string;
  ageRating: string;
  seoTitleFa: string;
  seoTitleEn: string;
  seoDescFa: string;
  seoDescEn: string;
  categories: string[];
  tags: string;
}

const emptyForm = (): GameForm => ({
  id: "",
  title: "",
  developer: "",
  year: String(new Date().getFullYear()),
  tagline: "",
  taglineEn: "",
  description: "",
  descriptionEn: "",
  highlights: "",
  genres: [],
  playstyles: [],
  structure: "خطی",
  modes: ["تک‌نفره"],
  sessionMin: "60",
  sessionMax: "180",
  hasCampaign: false,
  campaignMin: "10",
  campaignMax: "30",
  rating: 4,
  popularity: 50,
  price: "",
  originalPrice: "",
  rentalAvailable: false,
  d1: "",
  d3: "",
  d7: "",
  indie: false,
  featured: false,
  available: true,
  trialKind: "none",
  trialNote: "",
  palette: autoPalette("scorent"),
  motif: "orb",
  coverUrl: "",
  gallery: "",
  trailerUrl: "",
  publisher: "",
  platforms: "",
  languages: "",
  ageRating: "",
  seoTitleFa: "",
  seoTitleEn: "",
  seoDescFa: "",
  seoDescEn: "",
  categories: [],
  tags: "",
});

function formFromGame(g: Game): GameForm {
  const nums = (pair: [number, number] | null | undefined, fb: [number, number]): [string, string] =>
    pair ? [String(pair[0]), String(pair[1])] : [String(fb[0]), String(fb[1])];
  const [smin, smax] = nums(g.sessionMinutes, [60, 180]);
  const [cmin, cmax] = nums(g.campaignHours, [10, 30]);
  return {
    id: g.id,
    title: g.title,
    developer: g.developer,
    year: String(g.year),
    tagline: g.tagline,
    taglineEn: g.taglineEn ?? "",
    description: g.description,
    descriptionEn: g.descriptionEn ?? "",
    highlights: (g.highlights ?? []).join("\n"),
    genres: g.genres,
    playstyles: g.playstyles,
    structure: g.structure,
    modes: g.modes,
    sessionMin: smin,
    sessionMax: smax,
    hasCampaign: g.campaignHours !== null,
    campaignMin: cmin,
    campaignMax: cmax,
    rating: g.rating,
    popularity: g.popularity,
    price: String(g.price),
    originalPrice: String(g.originalPrice || g.price),
    rentalAvailable: g.rentalAvailable,
    d1: g.rental ? String(g.rental.d1) : "",
    d3: g.rental ? String(g.rental.d3) : "",
    d7: g.rental ? String(g.rental.d7) : "",
    indie: g.indie,
    featured: g.featured,
    available: g.available,
    trialKind: g.trial.kind,
    trialNote: g.trial.note,
    palette: [...g.palette] as [string, string, string],
    motif: g.motif,
    coverUrl: g.coverUrl ?? "",
    gallery: (g.gallery ?? []).join("\n"),
    trailerUrl: g.trailerUrl ?? "",
    publisher: g.publisher ?? "",
    platforms: (g.platforms ?? []).join(", "),
    languages: (g.languages ?? []).join(", "),
    ageRating: g.ageRating ?? "",
    seoTitleFa: g.seoTitleFa ?? "",
    seoTitleEn: g.seoTitleEn ?? "",
    seoDescFa: g.seoDescFa ?? "",
    seoDescEn: g.seoDescEn ?? "",
    categories: g.categories ?? [],
    tags: (g.tags ?? []).join(", "),
  };
}

/** تبدیل فرم → ورودی خام پالایه (سرور همان را می‌بیند) */
function formToRaw(f: GameForm): Record<string, unknown> {
  return {
    id: f.id,
    title: f.title,
    developer: f.developer,
    year: Number(f.year) || 0,
    tagline: f.tagline,
    taglineEn: f.taglineEn || undefined,
    description: f.description,
    descriptionEn: f.descriptionEn || undefined,
    highlights: f.highlights.split("\n").map((s) => s.trim()).filter(Boolean),
    genres: f.genres,
    playstyles: f.playstyles,
    structure: f.structure,
    modes: f.modes,
    sessionMinutes: [Number(f.sessionMin) || 0, Number(f.sessionMax) || 0],
    campaignHours: f.hasCampaign ? [Number(f.campaignMin) || 0, Number(f.campaignMax) || 0] : null,
    rating: f.rating,
    popularity: f.popularity,
    price: Number(f.price) || 0,
    originalPrice: f.originalPrice === "" ? undefined : Number(f.originalPrice),
    rentalAvailable: f.rentalAvailable,
    rental: { d1: Number(f.d1) || 0, d3: Number(f.d3) || 0, d7: Number(f.d7) || 0 },
    indie: f.indie,
    featured: f.featured,
    available: f.available,
    trial: { kind: f.trialKind, note: f.trialNote },
    palette: f.palette,
    motif: f.motif,
    coverUrl: f.coverUrl || undefined,
    gallery: f.gallery.split("\n").map((s) => s.trim()).filter(Boolean),
    trailerUrl: f.trailerUrl || undefined,
    publisher: f.publisher || undefined,
    platforms: f.platforms.split(",").map((s) => s.trim()).filter(Boolean),
    languages: f.languages.split(",").map((s) => s.trim()).filter(Boolean),
    ageRating: f.ageRating || undefined,
    seoTitleFa: f.seoTitleFa || undefined,
    seoTitleEn: f.seoTitleEn || undefined,
    seoDescFa: f.seoDescFa || undefined,
    seoDescEn: f.seoDescEn || undefined,
    categories: f.categories,
    tags: f.tags.split(",").map((s) => s.trim()).filter(Boolean),
  };
}

const ERROR_KEYS: Record<string, string> = {
  ERR_ID: "admin.games.errId",
  ERR_TITLE: "admin.games.errTitle",
  ERR_TAGLINE: "admin.games.errTagline",
  ERR_DESCRIPTION: "admin.games.errDescription",
  ERR_DEVELOPER: "admin.games.errDeveloper",
  ERR_YEAR: "admin.games.errYear",
  ERR_GENRES: "admin.games.errGenres",
  ERR_PLAYSTYLES: "admin.games.errPlaystyles",
  ERR_MODES: "admin.games.errModes",
  ERR_STRUCTURE: "admin.games.errStructure",
  ERR_SESSION: "admin.games.errSession",
  ERR_PRICE: "admin.games.errPrice",
  ERR_ORIGINAL_PRICE: "admin.games.errOriginalPrice",
  ERR_RENTAL: "admin.games.errRental",
  ERR_HIGHLIGHTS: "admin.games.errHighlights",
  ERR_ID_MISMATCH: "admin.games.errId",
};

/* ————— چیپ انتخابی چندگانه ————— */
function Chip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "rounded-full border px-3 py-1.5 text-xs font-bold transition-colors",
        active ? "border-ai bg-ai/15 text-ai" : "border-border bg-secondary/40 text-muted-foreground hover:border-ai/40 hover:text-foreground"
      )}
    >
      {label}
    </button>
  );
}

function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-bold text-muted-foreground">{label}</Label>
      {children}
      {hint ? <p className="text-[0.6rem] text-muted-foreground">{hint}</p> : null}
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return <h3 className="mb-3 flex items-center gap-2 border-b border-border pb-2 text-xs font-black text-ai">{children}</h3>;
}

interface GameRecordRow {
  id: string;
  game: Game;
  status: "PUBLISHED" | "DRAFT" | "ARCHIVED";
  source: "DATASET" | "CUSTOM";
  deletedAt: string | null;
  scheduledAt: string | null;
  updatedAt: string;
  updatedBy: string | null;
}

const STATUS_BADGE: Record<GameRecordRow["status"], { cls: string; key: string }> = {
  PUBLISHED: { cls: "bg-emerald-500/15 text-emerald-500", key: "admin.games.statusPublished" },
  DRAFT: { cls: "bg-amber-500/15 text-amber-500", key: "admin.games.statusDraft" },
  ARCHIVED: { cls: "bg-zinc-500/20 text-zinc-400", key: "admin.games.statusArchived" },
};

export function AdminGames() {
  const t = useT();
  const f = useFmt();
  const me = useAuth((s) => s.user);
  const catalogVersion = useCatalog((s) => s.version);

  const [rows, setRows] = useState<GameRecordRow[] | null>(null);
  const [err, setErr] = useState(false);
  const [q, setQ] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [sourceFilter, setSourceFilter] = useState<string>("all");
  const [trashView, setTrashView] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const [editorOpen, setEditorOpen] = useState(false);
  const [editorId, setEditorId] = useState<string | null>(null);
  const [editorStatus, setEditorStatus] = useState<GameRecordRow["status"]>("PUBLISHED");
  const [draft, setDraft] = useState<GameForm>(emptyForm());
  const [busy, setBusy] = useState(false);
  const [deleting, setDeleting] = useState<GameRecordRow | null>(null);
  const [cmsOpen, setCmsOpen] = useState(false);

  const set = <K extends keyof GameForm>(k: K, v: GameForm[K]) => setDraft((s) => ({ ...s, [k]: v }));

  async function load() {
    try {
      const d = await api.get<{ ok: boolean; games: GameRecordRow[] }>("/api/admin/games");
      setRows(d.games);
    } catch {
      setErr(true);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  const list = useMemo(() => {
    const qq = q.trim().toLowerCase();
    return (rows ?? []).filter((r) => {
      if (trashView ? !r.deletedAt : r.deletedAt) return false;
      if (statusFilter !== "all" && r.status !== statusFilter) return false;
      if (sourceFilter !== "all" && r.source !== sourceFilter) return false;
      if (!qq) return true;
      return (
        r.game.title.toLowerCase().includes(qq) ||
        r.id.includes(qq) ||
        r.game.tagline.includes(qq) ||
        r.game.developer.toLowerCase().includes(qq)
      );
    });
  }, [rows, q, statusFilter, sourceFilter, trashView, catalogVersion]);

  /* اعتبارسنجی زنده‌ی فرم */
  const validation = useMemo(() => sanitizeGameInput(formToRaw(draft)), [draft]);
  const preview = useMemo(() => lenientGame(formToRaw(draft)), [draft]);
  const validationErrors = validation.ok ? [] : validation.errors;

  const idTaken = useMemo(() => {
    if (!slugOk(draft.id)) return false;
    if (editorId === draft.id) return false;
    return (rows ?? []).some((r) => r.id === draft.id);
  }, [draft.id, editorId, rows]);

  const discountPreview = useMemo(() => {
    const price = Number(draft.price) || 0;
    const original = draft.originalPrice === "" ? price : Number(draft.originalPrice) || price;
    if (original > price && price > 0) return Math.max(0, Math.min(90, Math.round((1 - price / original) * 100)));
    return 0;
  }, [draft.price, draft.originalPrice]);

  function openAdd() {
    const fresh = emptyForm();
    fresh.palette = autoPalette(`scorent-${Date.now()}`);
    setDraft(fresh);
    setEditorId(null);
    setEditorStatus("PUBLISHED");
    setEditorOpen(true);
  }

  function openEdit(row: GameRecordRow) {
    setDraft(formFromGame(row.game));
    setEditorId(row.id);
    setEditorStatus(row.status);
    setEditorOpen(true);
  }

  async function saveGame() {
    if (!validation.ok || idTaken) {
      toast.error(t("admin.games.formInvalid"));
      return;
    }
    setBusy(true);
    try {
      const raw = formToRaw(draft);
      if (editorId) {
        await api.patch(`/api/admin/games/${editorId}`, { game: raw, status: editorStatus });
        toast.success(t("admin.games.saved"));
      } else {
        await api.post("/api/admin/games", { id: draft.id, game: raw, status: editorStatus });
        toast.success(t("admin.games.created"));
      }
      setEditorOpen(false);
      await load();
      await refreshCatalog();
    } catch (e) {
      const code = e instanceof Error ? e.message : "";
      toast.error(code === "GAME_ID_TAKEN" ? t("admin.games.idTaken") : t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function softDelete(row: GameRecordRow) {
    setBusy(true);
    try {
      await api.del(`/api/admin/games/${row.id}`);
      toast.success(t("admin.games.trashed"));
      setDeleting(null);
      await load();
      await refreshCatalog();
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function restoreGame(row: GameRecordRow) {
    setBusy(true);
    try {
      await api.post(`/api/admin/games/${row.id}/restore`, {});
      toast.success(t("admin.games.restored"));
      await load();
      await refreshCatalog();
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function duplicateGame(row: GameRecordRow) {
    setBusy(true);
    try {
      await api.post(`/api/admin/games/${row.id}/duplicate`, {});
      toast.success(t("admin.games.duplicated"));
      await load();
      await refreshCatalog();
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function bulkAction(action: "publish" | "draft" | "archive" | "delete") {
    const ids = [...selected];
    if (ids.length === 0) return;
    setBusy(true);
    try {
      await api.post("/api/admin/games/bulk", { action, ids });
      toast.success(t("admin.games.bulkDone", { n: f.num(ids.length) }));
      setSelected(new Set());
      await load();
      await refreshCatalog();
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  function toggleSelect(id: string) {
    setSelected((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  if (err) return <AdminError />;
  const canGames = Boolean(me && ["SUPER_ADMIN", "ADMIN", "CONTENT_EDITOR"].includes(me.role));

  return (
    <div>
      <AdminHeader
        kicker={t("admin.title")}
        title={t("admin.games.title")}
        description={t("admin.games.descNew")}
        icon={Gamepad2}
        action={
          canGames && !trashView ? (
            <Button onClick={openAdd} className="gap-2 bg-ai text-white hover:bg-ai/90">
              <Plus className="size-4" /> {t("admin.games.add")}
            </Button>
          ) : null
        }
      />

      {/* فیلترها */}
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <div className="relative min-w-56 flex-1">
          <Search className="absolute inset-y-0 start-3 my-auto size-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("admin.search")} className="ps-9" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-36" aria-label={t("admin.games.statusFilter")}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("admin.games.statusAll")}</SelectItem>
            <SelectItem value="PUBLISHED">{t("admin.games.statusPublished")}</SelectItem>
            <SelectItem value="DRAFT">{t("admin.games.statusDraft")}</SelectItem>
            <SelectItem value="ARCHIVED">{t("admin.games.statusArchived")}</SelectItem>
          </SelectContent>
        </Select>
        <Select value={sourceFilter} onValueChange={setSourceFilter}>
          <SelectTrigger className="w-36" aria-label={t("admin.games.sourceFilter")}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("admin.games.sourceAll")}</SelectItem>
            <SelectItem value="DATASET">{t("admin.games.sourceDataset")}</SelectItem>
            <SelectItem value="CUSTOM">{t("admin.games.sourceCustom")}</SelectItem>
          </SelectContent>
        </Select>
        <Button variant={trashView ? "default" : "outline"} onClick={() => setTrashView((v) => !v)} className="gap-2">
          <Trash2 className="size-4" />
          {trashView ? t("admin.games.backToCatalog") : t("admin.games.trash")}
          {trashView ? null : <span className="rounded-full bg-secondary px-1.5 text-[0.62rem] tnum">{f.num((rows ?? []).filter((r) => r.deletedAt).length)}</span>}
        </Button>
        <span className="text-xs text-muted-foreground tnum">
          {f.num(list.length)} {t("admin.games.totalCount")}
        </span>
      </div>

      {/* عملیات گروهی */}
      {selected.size > 0 && !trashView ? (
        <div className="mb-4 flex flex-wrap items-center gap-2 rounded-2xl border border-ai/30 bg-ai/5 p-3">
          <Layers className="size-4 text-ai" />
          <span className="text-xs font-extrabold tnum">{f.num(selected.size)}</span>
          <Button size="sm" variant="outline" onClick={() => bulkAction("publish")} disabled={busy}>{t("admin.games.bulkPublish")}</Button>
          <Button size="sm" variant="outline" onClick={() => bulkAction("draft")} disabled={busy}>{t("admin.games.bulkDraft")}</Button>
          <Button size="sm" variant="outline" onClick={() => bulkAction("archive")} disabled={busy}>{t("admin.games.bulkArchive")}</Button>
          <Button size="sm" variant="outline" onClick={() => bulkAction("delete")} disabled={busy}>{t("admin.games.bulkDelete")}</Button>
          <Button size="sm" variant="ghost" onClick={() => setSelected(new Set())}>{t("admin.games.clearSelection")}</Button>
        </div>
      ) : null}

      {/* لیست */}
      {list.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-secondary/20 p-8 text-center">
          <Gamepad2 className="mx-auto size-8 text-muted-foreground/50" />
          <p className="mt-3 text-sm font-bold">{trashView ? t("admin.games.trashEmpty") : t("admin.games.empty")}</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {list.map((row) => {
            const badge = STATUS_BADGE[row.status];
            const isSelected = selected.has(row.id);
            return (
              <div
                key={row.id}
                className={cn(
                  "flex flex-wrap items-center gap-3 rounded-2xl border bg-card p-3 transition-colors",
                  isSelected ? "border-ai/50 bg-ai/5" : "border-border"
                )}
              >
                <input
                  type="checkbox"
                  checked={isSelected}
                  onChange={() => toggleSelect(row.id)}
                  className="size-4 rounded border-border"
                  aria-label={row.game.title}
                />
                <GameCover game={row.game} showTitle={false} className="h-16 w-12 shrink-0 rounded-lg" />
                <div className="min-w-40 flex-1">
                  <p className="flex flex-wrap items-center gap-2 text-sm font-extrabold">
                    {row.game.title}
                    <span dir="ltr" className="text-[0.62rem] font-medium text-muted-foreground">{row.id}</span>
                    {row.source === "CUSTOM" ? (
                      <span className="rounded-full bg-ai/15 px-2 py-0.5 text-[0.62rem] font-extrabold text-ai">{t("admin.games.sourceCustom")}</span>
                    ) : null}
                    <span className={cn("rounded-full px-2 py-0.5 text-[0.62rem] font-extrabold", badge.cls)}>{t(badge.key)}</span>
                    {row.scheduledAt && new Date(row.scheduledAt).getTime() > Date.now() ? (
                      <span className="rounded-full bg-sky-500/15 px-2 py-0.5 text-[0.62rem] font-extrabold text-sky-500">{t("admin.games.scheduled")}</span>
                    ) : null}
                  </p>
                  <p className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">
                    {row.game.tagline} — {row.game.developer} · {f.toman(row.game.price)}
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  {trashView ? (
                    <Button size="sm" variant="outline" onClick={() => restoreGame(row)} disabled={busy} className="gap-1.5">
                      <ArchiveRestore className="size-3.5" /> {t("admin.games.restore")}
                    </Button>
                  ) : (
                    <>
                      <Button size="sm" variant="ghost" onClick={() => openEdit(row)} className="gap-1.5" disabled={!canGames}>
                        <Pencil className="size-3.5" /> {t("admin.games.edit")}
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => duplicateGame(row)} className="gap-1.5" disabled={!canGames || busy} title={t("admin.games.duplicate")}>
                        <Copy className="size-3.5" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => setDeleting(row)} className="gap-1.5 text-destructive hover:text-destructive" disabled={!canGames || busy} title={t("admin.games.delete")}>
                        <Trash2 className="size-3.5" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* حذف */}
      <AlertDialog open={Boolean(deleting)} onOpenChange={(v) => !v && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("admin.games.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("admin.games.deleteDesc", { title: deleting?.game.title ?? "" })}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("admin.cancel")}</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleting && softDelete(deleting)} className="bg-destructive text-white hover:bg-destructive/90">
              {t("admin.games.delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {editorOpen ? (
        <GameEditorDialog
          draft={draft}
          set={set}
          editorId={editorId}
          editorStatus={editorStatus}
          setEditorStatus={setEditorStatus}
          validationErrors={validationErrors}
          idTaken={idTaken}
          discountPreview={discountPreview}
          preview={preview}
          busy={busy}
          cmsOpen={cmsOpen}
          setCmsOpen={setCmsOpen}
          onClose={() => setEditorOpen(false)}
          onSave={saveGame}
        />
      ) : null}
    </div>
  );
}

/* ————— دیالوگ ویرایشگر — فرم کامل + بخش CMS تاشو ————— */

function GameEditorDialog({
  draft,
  set,
  editorId,
  editorStatus,
  setEditorStatus,
  validationErrors,
  idTaken,
  discountPreview,
  preview,
  busy,
  cmsOpen,
  setCmsOpen,
  onClose,
  onSave,
}: {
  draft: GameForm;
  set: <K extends keyof GameForm>(k: K, v: GameForm[K]) => void;
  editorId: string | null;
  editorStatus: GameRecordRow["status"];
  setEditorStatus: (s: GameRecordRow["status"]) => void;
  validationErrors: string[];
  idTaken: boolean;
  discountPreview: number;
  preview: Game;
  busy: boolean;
  cmsOpen: boolean;
  setCmsOpen: (v: boolean) => void;
  onClose: () => void;
  onSave: () => void;
}) {
  const t = useT();
  const err = (code: string) => (validationErrors.includes(code) ? "border-destructive" : "");
  const idHint = useMemo(() => (draft.id ? "" : slugify(draft.title)), [draft.id, draft.title]);

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-h-[92svh] overflow-y-auto sm:max-w-3xl" dir="rtl">
        <DialogHeader>
          <DialogTitle>{editorId ? t("admin.games.editTitle", { title: draft.title || draft.id }) : t("admin.games.addTitle")}</DialogTitle>
          <DialogDescription>{t("admin.games.formDesc")}</DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 md:grid-cols-2">
          {/* شناسه و عنوان */}
          <div className="md:col-span-2">
            <SectionTitle>{t("admin.games.secBasic")}</SectionTitle>
          </div>
          <Field label={t("admin.games.fTitle")} hint={t("admin.games.fTitleHint")}>
            <Input value={draft.title} onChange={(e) => set("title", e.target.value)} className={err("ERR_TITLE")} dir="ltr" />
          </Field>
          <Field label={t("admin.games.fId")} hint={idHint ? `${t("admin.games.fIdSuggest")}: ${idHint}` : undefined}>
            <div className="flex items-center gap-2">
              <Input value={draft.id} onChange={(e) => set("id", e.target.value.toLowerCase())} dir="ltr" className={cn(err("ERR_ID"), idTaken && "border-destructive")} disabled={Boolean(editorId)} />
              {!editorId && idHint ? (
                <Button type="button" variant="outline" size="sm" onClick={() => set("id", slugify(draft.title))}>
                  {t("admin.games.useSuggest")}
                </Button>
              ) : null}
            </div>
            {idTaken ? <p className="mt-1 text-xs font-bold text-destructive">{t("admin.games.idTaken")}</p> : null}
          </Field>
          <Field label={t("admin.games.fDeveloper")}>
            <Input value={draft.developer} onChange={(e) => set("developer", e.target.value)} className={err("ERR_DEVELOPER")} />
          </Field>
          <Field label={t("admin.games.fPublisher")}>
            <Input value={draft.publisher} onChange={(e) => set("publisher", e.target.value)} />
          </Field>
          <Field label={t("admin.games.fYear")}>
            <Input value={draft.year} onChange={(e) => set("year", e.target.value.replace(/\D/g, ""))} inputMode="numeric" className={err("ERR_YEAR")} dir="ltr" />
          </Field>
          <Field label={t("admin.games.fTagline")} hint={t("admin.games.fTaglineHint")}>
            <Input value={draft.tagline} onChange={(e) => set("tagline", e.target.value)} className={err("ERR_TAGLINE")} />
          </Field>
          <Field label={t("admin.games.fTaglineEn")}>
            <Input value={draft.taglineEn} onChange={(e) => set("taglineEn", e.target.value)} dir="ltr" />
          </Field>
          <Field label={t("admin.games.fDescription")} hint={`${draft.description.length}/4000`}>
            <Textarea value={draft.description} onChange={(e) => set("description", e.target.value)} rows={4} className={err("ERR_DESCRIPTION")} />
          </Field>
          <Field label={t("admin.games.fDescriptionEn")}>
            <Textarea value={draft.descriptionEn} onChange={(e) => set("descriptionEn", e.target.value)} rows={4} dir="ltr" />
          </Field>
          <Field label={t("admin.games.fHighlights")} hint={t("admin.games.fHighlightsHint")}>
            <Textarea value={draft.highlights} onChange={(e) => set("highlights", e.target.value)} rows={3} className={err("ERR_HIGHLIGHTS")} />
          </Field>

          {/* دسته‌بندی‌ها */}
          <div className="md:col-span-2">
            <SectionTitle>{t("admin.games.secTaxonomy")}</SectionTitle>
          </div>
          <Field label={t("admin.games.fGenres")} hint={t("admin.games.fGenresHint")}>
            <div className="flex flex-wrap gap-1.5">
              {ALL_GENRES.map((g) => (
                <Chip key={g} label={g} active={draft.genres.includes(g)} onClick={() => set("genres", draft.genres.includes(g) ? draft.genres.filter((x) => x !== g) : [...draft.genres, g])} />
              ))}
            </div>
          </Field>
          <Field label={t("admin.games.fPlaystyles")}>
            <div className="flex flex-wrap gap-1.5">
              {ALL_PLAYSTYLES.map((p) => (
                <Chip key={p} label={p} active={draft.playstyles.includes(p)} onClick={() => set("playstyles", draft.playstyles.includes(p) ? draft.playstyles.filter((x) => x !== p) : [...draft.playstyles, p])} />
              ))}
            </div>
          </Field>
          <Field label={t("admin.games.fModes")}>
            <div className="flex flex-wrap gap-1.5">
              {ALL_MODES.map((m) => (
                <Chip key={m} label={m} active={draft.modes.includes(m)} onClick={() => set("modes", draft.modes.includes(m) ? draft.modes.filter((x) => x !== m) : [...draft.modes, m])} />
              ))}
            </div>
          </Field>
          <Field label={t("admin.games.fStructure")}>
            <Select value={draft.structure} onValueChange={(v) => set("structure", v as Structure)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {STRUCTURES.map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label={t("admin.games.fTags")} hint={t("admin.games.fTagsHint")}>
            <Input value={draft.tags} onChange={(e) => set("tags", e.target.value)} dir="ltr" />
          </Field>

          {/* قیمت و اجاره */}
          <div className="md:col-span-2">
            <SectionTitle>{t("admin.games.secPricing")}</SectionTitle>
          </div>
          <Field label={t("admin.games.fPrice")}>
            <Input value={draft.price} onChange={(e) => set("price", e.target.value.replace(/\D/g, ""))} inputMode="numeric" className={cn("tnum", err("ERR_PRICE"))} dir="ltr" />
          </Field>
          <Field label={t("admin.games.fOriginalPrice")} hint={discountPreview > 0 ? `${t("admin.games.fDiscount")}: ${discountPreview}%` : undefined}>
            <Input value={draft.originalPrice} onChange={(e) => set("originalPrice", e.target.value.replace(/\D/g, ""))} inputMode="numeric" className={cn("tnum", err("ERR_ORIGINAL_PRICE"))} dir="ltr" />
          </Field>
          <div className="flex items-center justify-between rounded-xl border border-border bg-card/60 px-3 py-2.5">
            <Label className="text-xs font-bold">{t("admin.games.fRentalAvailable")}</Label>
            <Switch checked={draft.rentalAvailable} onCheckedChange={(v) => set("rentalAvailable", v)} />
          </div>
          {draft.rentalAvailable ? (
            <div className="grid grid-cols-3 gap-2">
              <Field label="۱ روز"><Input value={draft.d1} onChange={(e) => set("d1", e.target.value.replace(/\D/g, ""))} className="tnum" dir="ltr" /></Field>
              <Field label="۳ روز"><Input value={draft.d3} onChange={(e) => set("d3", e.target.value.replace(/\D/g, ""))} className="tnum" dir="ltr" /></Field>
              <Field label="۷ روز"><Input value={draft.d7} onChange={(e) => set("d7", e.target.value.replace(/\D/g, ""))} className="tnum" dir="ltr" /></Field>
            </div>
          ) : null}

          {/* امتیاز و کیفیت */}
          <div className="md:col-span-2">
            <SectionTitle>{t("admin.games.secQuality")}</SectionTitle>
          </div>
          <Field label={`${t("admin.games.fRating")}: ${draft.rating}`}>
            <Slider value={[draft.rating]} min={0} max={5} step={0.1} onValueChange={([v]) => set("rating", v)} />
          </Field>
          <Field label={`${t("admin.games.fPopularity")}: ${draft.popularity}`}>
            <Slider value={[draft.popularity]} min={0} max={100} step={1} onValueChange={([v]) => set("popularity", v)} />
          </Field>
          <div className="flex flex-wrap items-center gap-4">
            <label className="flex items-center gap-2 text-xs font-bold"><Switch checked={draft.indie} onCheckedChange={(v) => set("indie", v)} /> {t("admin.games.fIndie")}</label>
            <label className="flex items-center gap-2 text-xs font-bold"><Switch checked={draft.featured} onCheckedChange={(v) => set("featured", v)} /> {t("admin.games.fFeatured")}</label>
            <label className="flex items-center gap-2 text-xs font-bold"><Switch checked={draft.available} onCheckedChange={(v) => set("available", v)} /> {t("admin.games.fAvailable")}</label>
          </div>

          {/* بخش CMS تاشو */}
          <div className="md:col-span-2">
            <button type="button" onClick={() => setCmsOpen(!cmsOpen)} className="flex w-full items-center justify-between rounded-xl border border-border bg-secondary/30 px-4 py-3 text-start">
              <span className="flex items-center gap-2 text-sm font-extrabold"><EyeOff className="size-4 text-ai" /> {t("admin.games.secCms")}</span>
              <span className="text-xs text-muted-foreground">{cmsOpen ? "−" : "+"}</span>
            </button>
            {cmsOpen ? (
              <div className="mt-4 grid gap-4 rounded-xl border border-border bg-card/40 p-4 md:grid-cols-2">
                <Field label={t("admin.games.fCover")} hint={t("admin.games.fCoverHint")}>
                  <Input value={draft.coverUrl} onChange={(e) => set("coverUrl", e.target.value)} dir="ltr" placeholder="https://… یا /api/media/…" />
                </Field>
                <Field label={t("admin.games.fGallery")} hint={t("admin.games.fGalleryHint")}>
                  <Textarea value={draft.gallery} onChange={(e) => set("gallery", e.target.value)} rows={2} dir="ltr" />
                </Field>
                <Field label={t("admin.games.fTrailer")}>
                  <Input value={draft.trailerUrl} onChange={(e) => set("trailerUrl", e.target.value)} dir="ltr" />
                </Field>
                <Field label={t("admin.games.fAgeRating")}>
                  <Input value={draft.ageRating} onChange={(e) => set("ageRating", e.target.value)} dir="ltr" placeholder="PEGI 18" />
                </Field>
                <Field label={t("admin.games.fPlatforms")} hint={t("admin.games.fCommaHint")}>
                  <Input value={draft.platforms} onChange={(e) => set("platforms", e.target.value)} dir="ltr" placeholder="PC, PS5, Xbox" />
                </Field>
                <Field label={t("admin.games.fLanguages")}>
                  <Input value={draft.languages} onChange={(e) => set("languages", e.target.value)} dir="ltr" />
                </Field>
                <Field label={t("admin.games.fSeoTitleFa")}>
                  <Input value={draft.seoTitleFa} onChange={(e) => set("seoTitleFa", e.target.value)} />
                </Field>
                <Field label={t("admin.games.fSeoTitleEn")}>
                  <Input value={draft.seoTitleEn} onChange={(e) => set("seoTitleEn", e.target.value)} dir="ltr" />
                </Field>
                <Field label={t("admin.games.fSeoDescFa")}>
                  <Textarea value={draft.seoDescFa} onChange={(e) => set("seoDescFa", e.target.value)} rows={2} />
                </Field>
                <Field label={t("admin.games.fSeoDescEn")}>
                  <Textarea value={draft.seoDescEn} onChange={(e) => set("seoDescEn", e.target.value)} rows={2} dir="ltr" />
                </Field>
              </div>
            ) : null}
          </div>

          {/* پیش‌نمایش کاور */}
          <div className="md:col-span-2">
            <SectionTitle>{t("admin.games.secPreview")}</SectionTitle>
            <div className="flex items-start gap-4">
              <GameCover game={preview} className="h-44 w-32 shrink-0 rounded-xl" />
              <div className="text-sm leading-7">
                <p className="font-extrabold">{preview.title}</p>
                <p className="text-xs text-muted-foreground">{preview.tagline}</p>
                <p className="mt-2 text-xs text-muted-foreground">{preview.developer} · {preview.year}</p>
                {discountPreview > 0 ? (
                  <p className="mt-1 text-xs font-bold text-deal">{t("admin.games.discountLive", { pct: discountPreview })}</p>
                ) : null}
              </div>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <div className="me-auto flex items-center gap-2">
            <Globe className="size-4 text-muted-foreground" />
            <Select value={editorStatus} onValueChange={(v) => setEditorStatus(v as GameRecordRow["status"])}>
              <SelectTrigger className="w-40" aria-label={t("admin.games.statusFilter")}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="PUBLISHED"><span className="flex items-center gap-2"><Globe className="size-3.5" /> {t("admin.games.statusPublished")}</span></SelectItem>
                <SelectItem value="DRAFT"><span className="flex items-center gap-2"><FileEdit className="size-3.5" /> {t("admin.games.statusDraft")}</span></SelectItem>
                <SelectItem value="ARCHIVED"><span className="flex items-center gap-2"><Archive className="size-3.5" /> {t("admin.games.statusArchived")}</span></SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button variant="ghost" onClick={onClose}>{t("admin.cancel")}</Button>
          <Button onClick={onSave} disabled={busy || validationErrors.length > 0 || idTaken} className="gap-2">
            <Save className="size-4" /> {t("admin.save")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
