"use client";

/* ————— مدیرت رده‌ها و تاکسونومی — درخت دوزبانه با ترتیب ————— */

import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { ChevronDown, ChevronUp, Plus, Shapes, Trash2, Pencil, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { api } from "@/lib/auth";
import { useT } from "@/lib/i18n";
import { AdminHeader, AdminError } from "./ui";
import type { CategoryNode } from "@/lib/cms/types";

interface FlatCat extends Omit<CategoryNode, "children"> {
  depth: number;
}

function flatten(tree: CategoryNode[], depth = 0): FlatCat[] {
  const out: FlatCat[] = [];
  for (const n of tree) {
    const { children: _children, ...rest } = n;
    void _children;
    out.push({ ...rest, depth });
    if (n.children.length) out.push(...flatten(n.children, depth + 1));
  }
  return out;
}

interface FormState {
  id: string | null;
  slug: string;
  nameFa: string;
  nameEn: string;
  descFa: string;
  descEn: string;
  icon: string;
  image: string;
  seoFa: string;
  seoEn: string;
  parentId: string | null;
  enabled: boolean;
}

const emptyForm = (): FormState => ({
  id: null, slug: "", nameFa: "", nameEn: "", descFa: "", descEn: "", icon: "", image: "", seoFa: "", seoEn: "", parentId: null, enabled: true,
});

export function AdminCategories() {
  const t = useT();
  const [tree, setTree] = useState<CategoryNode[] | null>(null);
  const [err, setErr] = useState(false);
  const [form, setForm] = useState<FormState>(emptyForm());
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [deleting, setDeleting] = useState<FlatCat | null>(null);

  const flat = useMemo(() => (tree ? flatten(tree) : []), [tree]);

  async function load() {
    try {
      const d = await api.get<{ ok: boolean; tree: CategoryNode[] }>("/api/admin/cms/categories");
      setTree(d.tree);
    } catch {
      setErr(true);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  function openAdd(parent: { id: string } | null) {
    setForm({ ...emptyForm(), parentId: parent?.id ?? null });
    setOpen(true);
  }

  function openEdit(c: FlatCat) {
    setForm({
      id: c.id, slug: c.slug, nameFa: c.nameFa, nameEn: c.nameEn, descFa: c.descFa ?? "", descEn: c.descEn ?? "",
      icon: c.icon ?? "", image: c.image ?? "", seoFa: c.seoFa ?? "", seoEn: c.seoEn ?? "", parentId: c.parentId, enabled: c.enabled,
    });
    setOpen(true);
  }

  async function save() {
    if (!form.slug || !form.nameFa) {
      toast.error(t("admin.cms.invalid"));
      return;
    }
    setBusy(true);
    try {
      const body = {
        slug: form.slug, nameFa: form.nameFa, nameEn: form.nameEn || form.nameFa,
        descFa: form.descFa || undefined, descEn: form.descEn || undefined,
        icon: form.icon || undefined, image: form.image || undefined,
        seoFa: form.seoFa || undefined, seoEn: form.seoEn || undefined,
        parentId: form.parentId, enabled: form.enabled,
      };
      if (form.id) await api.patch(`/api/admin/cms/categories/${form.id}`, body);
      else await api.post("/api/admin/cms/categories", body);
      toast.success(t("admin.cms.saved"));
      setOpen(false);
      await load();
    } catch (e) {
      const code = e instanceof Error ? e.message : "";
      toast.error(code === "SLUG_TAKEN" ? t("admin.cms.slugTaken") : code === "CYCLE_FORBIDDEN" ? t("admin.cms.cycle") : t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function remove(c: FlatCat) {
    setBusy(true);
    try {
      await api.del(`/api/admin/cms/categories/${c.id}`);
      toast.success(t("admin.cms.deleted"));
      setDeleting(null);
      await load();
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function move(c: FlatCat, dir: -1 | 1) {
    const idx = flat.findIndex((x) => x.id === c.id);
    const siblings = flat.filter((x) => x.parentId === c.parentId);
    const localIdx = siblings.findIndex((x) => x.id === c.id);
    const swapWith = siblings[localIdx + dir];
    if (!swapWith) return;
    // تبادل ترتیب با همسایه
    try {
      await api.patch(`/api/admin/cms/categories/${swapWith.id}`, { order: c.order });
      await api.patch(`/api/admin/cms/categories/${c.id}`, { order: swapWith.order });
      await load();
    } catch {
      toast.error(t("admin.error"));
    }
  }

  if (err) return <AdminError />;

  return (
    <div>
      <AdminHeader
        kicker={t("admin.title")}
        title={t("admin.cms.categoriesTitle")}
        description={t("admin.cms.categoriesDesc")}
        icon={Shapes}
        action={
          <Button onClick={() => openAdd(null)} className="gap-2 bg-ai text-white hover:bg-ai/90">
            <Plus className="size-4" /> {t("admin.cms.addCategory")}
          </Button>
        }
      />

      {!tree ? (
        <div className="flex min-h-40 items-center justify-center"><span className="size-8 animate-spin rounded-full border-2 border-border border-t-ai" /></div>
      ) : flat.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-secondary/20 p-8 text-center">
          <Shapes className="mx-auto size-8 text-muted-foreground/50" />
          <p className="mt-3 text-sm font-bold">{t("admin.cms.categoriesEmpty")}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {flat.map((c) => (
            <div
              key={c.id}
              className="flex flex-wrap items-center gap-3 rounded-2xl border border-border bg-card p-3"
              style={{ marginInlineStart: `${Math.min(c.depth, 4) * 1.5}rem` }}
            >
              <div className="min-w-40 flex-1">
                <p className="flex flex-wrap items-center gap-2 text-sm font-extrabold">
                  {c.nameFa}
                  <span className="rounded-full bg-secondary px-2 py-0.5 text-[0.62rem] text-muted-foreground" dir="ltr">{c.slug}</span>
                  {!c.enabled ? <span className="rounded-full bg-zinc-500/20 px-2 py-0.5 text-[0.62rem] font-extrabold text-zinc-400">{t("admin.cms.disabled")}</span> : null}
                </p>
                {c.nameEn ? <p className="text-xs text-muted-foreground" dir="ltr">{c.nameEn}</p> : null}
              </div>
              <div className="flex items-center gap-1">
                <Button size="icon" variant="ghost" onClick={() => move(c, -1)} aria-label={t("admin.cms.moveUp")}><ChevronUp className="size-4" /></Button>
                <Button size="icon" variant="ghost" onClick={() => move(c, 1)} aria-label={t("admin.cms.moveDown")}><ChevronDown className="size-4" /></Button>
                <Button size="sm" variant="ghost" onClick={() => openAdd(c)} className="gap-1.5"><Plus className="size-3.5" /> {t("admin.cms.addChild")}</Button>
                <Button size="sm" variant="ghost" onClick={() => openEdit(c)} className="gap-1.5"><Pencil className="size-3.5" /> {t("admin.cms.edit")}</Button>
                <Button size="icon" variant="ghost" onClick={() => setDeleting(c)} className="text-destructive hover:text-destructive" aria-label={t("admin.cms.delete")}><Trash2 className="size-4" /></Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={(v) => !v && setOpen(false)}>
        <DialogContent className="max-h-[90svh] overflow-y-auto sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>{form.id ? t("admin.cms.editCategory") : t("admin.cms.addCategory")}</DialogTitle>
            <DialogDescription>{t("admin.cms.categoryFormDesc")}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fSlug")}</Label><Input value={form.slug} onChange={(e) => setForm((s) => ({ ...s, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "-") }))} dir="ltr" disabled={Boolean(form.id)} /></div>
              <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fParent")}</Label>
                <select
                  value={form.parentId ?? ""}
                  onChange={(e) => setForm((s) => ({ ...s, parentId: e.target.value || null }))}
                  className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm"
                >
                  <option value="">{t("admin.cms.noParent")}</option>
                  {flat.filter((x) => x.id !== form.id).map((x) => (
                    <option key={x.id} value={x.id}>{`${"　".repeat(x.depth)}${x.nameFa}`}</option>
                  ))}
                </select>
              </div>
              <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fNameFa")}</Label><Input value={form.nameFa} onChange={(e) => setForm((s) => ({ ...s, nameFa: e.target.value }))} /></div>
              <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fNameEn")}</Label><Input value={form.nameEn} onChange={(e) => setForm((s) => ({ ...s, nameEn: e.target.value }))} dir="ltr" /></div>
              <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fDescFa")}</Label><Textarea value={form.descFa} onChange={(e) => setForm((s) => ({ ...s, descFa: e.target.value }))} rows={2} /></div>
              <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fDescEn")}</Label><Textarea value={form.descEn} onChange={(e) => setForm((s) => ({ ...s, descEn: e.target.value }))} rows={2} dir="ltr" /></div>
              <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fIcon")}</Label><Input value={form.icon} onChange={(e) => setForm((s) => ({ ...s, icon: e.target.value }))} dir="ltr" /></div>
              <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fImage")}</Label><Input value={form.image} onChange={(e) => setForm((s) => ({ ...s, image: e.target.value }))} dir="ltr" placeholder="https://… یا /api/media/…" /></div>
              <div><Label className="mb-1.5 block text-xs font-bold">SEO (fa)</Label><Input value={form.seoFa} onChange={(e) => setForm((s) => ({ ...s, seoFa: e.target.value }))} /></div>
              <div><Label className="mb-1.5 block text-xs font-bold">SEO (en)</Label><Input value={form.seoEn} onChange={(e) => setForm((s) => ({ ...s, seoEn: e.target.value }))} dir="ltr" /></div>
            </div>
            <label className="flex items-center gap-2 text-xs font-bold">
              <Switch checked={form.enabled} onCheckedChange={(v) => setForm((s) => ({ ...s, enabled: v }))} />
              {t("admin.cms.enabled")}
            </label>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>{t("admin.cancel")}</Button>
            <Button onClick={save} disabled={busy || !form.slug || !form.nameFa} className="gap-2"><Save className="size-4" /> {t("admin.save")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={Boolean(deleting)} onOpenChange={(v) => !v && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("admin.cms.deleteCategoryTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("admin.cms.deleteCategoryDesc", { name: deleting?.nameFa ?? "" })}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("admin.cancel")}</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleting && remove(deleting)} className="bg-destructive text-white hover:bg-destructive/90">{t("admin.cms.delete")}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
