"use client";

/* ————— داشبورد مدیریت — آمار زنده، روند ۱۴ روزه و تفکیک‌ها ————— */

import { useEffect, useState } from "react";
import { Bell, Gamepad2, Inbox, LayoutDashboard, LifeBuoy, Mail, MessageSquare, Sparkles, Store, UserCheck, UserPlus, Users, UserX, EyeOff } from "lucide-react";
import { api } from "@/lib/auth";
import { useFmt, useT } from "@/lib/i18n";
import { Link } from "@/components/scorent/router";
import { AdminHeader, AdminError, RolePill, StatusPill } from "./ui";
import { cn } from "@/lib/utils";

interface Stats {
  users: number;
  usersSuspended: number;
  usersVerified: number;
  usersNew7d: number;
  usersNewToday: number;
  ticketsOpen: number;
  ticketsTotal: number;
  ticketsPending: number;
  ticketsClosed: number;
  notifs: number;
  notifsEmail: number;
  notifsSms: number;
  announcements: number;
  overrides: number;
  content: number;
  gamesTotal: number;
  gamesCustom: number;
  gamesHidden: number;
  gamesFeatured: number;
  trendLabels: string[];
  trendUsers: number[];
  trendTickets: number[];
}
interface LatestUser {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  role: string;
  status: string;
  createdAt: string;
}
interface LatestTicket {
  id: string;
  subject: string;
  status: string;
  priority: string;
  category: string;
  createdAt: string;
}

/* نمودار میله‌ای روند — دو سری (ثبت‌نام / تیکت) در ۱۴ روز گذشته */
function TrendChart({ labels, users, tickets }: { labels: string[]; users: number[]; tickets: number[] }) {
  const t = useT();
  const f = useFmt();
  const max = Math.max(1, ...users, ...tickets);
  return (
    <section className="rounded-3xl border border-border bg-card p-5" aria-label={t("admin.trend.title")}>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-sm font-extrabold">{t("admin.trend.title")}</h2>
        <div className="flex items-center gap-4 text-[0.65rem] font-bold text-muted-foreground">
          <span className="flex items-center gap-1.5"><span className="size-2.5 rounded-sm bg-ai" /> {t("admin.trend.users")}</span>
          <span className="flex items-center gap-1.5"><span className="size-2.5 rounded-sm bg-deal" /> {t("admin.trend.tickets")}</span>
        </div>
      </div>
      <div dir="ltr" className="flex h-36 items-end gap-1.5">
        {labels.map((d, i) => (
          <div key={d} className="group flex h-full min-w-0 flex-1 flex-col justify-end gap-0.5" title={`${d} — ${t("admin.trend.users")}: ${f.num(users[i])} · ${t("admin.trend.tickets")}: ${f.num(tickets[i])}`}>
            <div className="flex h-full items-end gap-0.5">
              <div className="flex-1 rounded-t-sm bg-ai/85 transition-all group-hover:bg-ai" style={{ height: `${Math.max(3, (users[i] / max) * 100)}%` }} />
              <div className="flex-1 rounded-t-sm bg-deal/85 transition-all group-hover:bg-deal" style={{ height: `${Math.max(3, (tickets[i] / max) * 100)}%` }} />
            </div>
            <span className="truncate text-center text-[0.5rem] leading-none text-muted-foreground tnum">{labels[i].slice(3)}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

/* تفکیک با نوار افقی */
function BreakBar({ label, value, total, tone }: { label: React.ReactNode; value: number; total: number; tone: string }) {
  const f = useFmt();
  const pct = total > 0 ? Math.round((value / total) * 100) : 0;
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-xs font-bold">
        <span>{label}</span>
        <span className="tnum text-muted-foreground">{f.num(value)} · {f.num(pct)}٪</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-secondary">
        <div className={cn("h-full rounded-full transition-all", tone)} style={{ width: `${Math.max(2, pct)}%` }} />
      </div>
    </div>
  );
}

export function AdminDashboard() {
  const t = useT();
  const f = useFmt();
  const [stats, setStats] = useState<Stats | null>(null);
  const [users, setUsers] = useState<LatestUser[]>([]);
  const [tickets, setTickets] = useState<LatestTicket[]>([]);
  const [err, setErr] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const res = await api.get<{ ok: boolean; stats: Stats; latestUsers: LatestUser[]; latestTickets: LatestTicket[] }>("/api/admin/stats");
        setStats(res.stats);
        setUsers(res.latestUsers);
        setTickets(res.latestTickets);
      } catch {
        setErr(true);
      }
    })();
  }, []);

  if (err) return <AdminError />;

  const cards = stats
    ? [
        { icon: Users, label: t("admin.stat.users"), value: stats.users, tone: "text-ai" },
        { icon: UserPlus, label: t("admin.stat.new7d"), value: stats.usersNew7d, tone: "text-rent" },
        { icon: UserCheck, label: t("admin.stat.verified"), value: stats.usersVerified, tone: "text-rent" },
        { icon: UserX, label: t("admin.stat.suspended"), value: stats.usersSuspended, tone: "text-destructive" },
        { icon: LifeBuoy, label: t("admin.stat.ticketsOpen"), value: stats.ticketsOpen, tone: "text-deal" },
        { icon: Inbox, label: t("admin.stat.notifs"), value: stats.notifs, tone: "text-rent" },
        { icon: Bell, label: t("admin.stat.announcements"), value: stats.announcements, tone: "text-ai" },
        { icon: Gamepad2, label: t("admin.stat.overrides"), value: stats.overrides, tone: "text-foreground" },
      ]
    : [];

  return (
    <div>
      <AdminHeader kicker={t("admin.title")} title={t("admin.tab.dashboard")} description={t("admin.desc")} icon={LayoutDashboard} />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {cards.length === 0
          ? Array.from({ length: 8 }).map((_, i) => <div key={i} className="h-28 animate-pulse rounded-2xl border border-border bg-card" />)
          : cards.map((c) => (
              <div key={c.label} className="rounded-2xl border border-border bg-card p-4">
                <c.icon className={`size-5 ${c.tone}`} />
                <p className="mt-2 text-2xl font-black tnum">{f.num(c.value)}</p>
                <p className="mt-0.5 text-[0.65rem] font-bold text-muted-foreground">{c.label}</p>
              </div>
            ))}
      </div>

      {/* کاتالوگ بازی‌ها — شمارش زنده شامل بازی‌های سفارشی */}
      {stats && (
        <section className="mt-6" aria-label={t("admin.stats.catalog")}>
          <h2 className="mb-3 flex items-center gap-2 text-sm font-extrabold">
            <Store className="size-4 text-ai" /> {t("admin.stats.catalog")}
          </h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {[
              { icon: Gamepad2, label: t("admin.stats.gamesTotal"), value: stats.gamesTotal, tone: "text-ai" },
              { icon: Sparkles, label: t("admin.stats.gamesCustom"), value: stats.gamesCustom, tone: "text-deal" },
              { icon: EyeOff, label: t("admin.stats.gamesHidden"), value: stats.gamesHidden, tone: "text-destructive" },
              { icon: Bell, label: t("admin.stats.gamesFeatured"), value: stats.gamesFeatured, tone: "text-rent" },
            ].map((c) => (
              <div key={c.label} className="rounded-2xl border border-border bg-card p-4">
                <c.icon className={`size-5 ${c.tone}`} />
                <p className="mt-2 text-2xl font-black tnum">{f.num(c.value)}</p>
                <p className="mt-0.5 text-[0.65rem] font-bold text-muted-foreground">{c.label}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {stats && (
        <div className="mt-6 grid gap-4 lg:grid-cols-2">
          <TrendChart labels={stats.trendLabels} users={stats.trendUsers} tickets={stats.trendTickets} />

          <div className="grid gap-4">
            <section className="rounded-3xl border border-border bg-card p-5" aria-label={t("admin.breakdown.tickets")}>
              <h2 className="mb-3 text-sm font-extrabold">{t("admin.breakdown.tickets")}</h2>
              <div className="space-y-3">
                <BreakBar label={t("support.status.OPEN")} value={stats.ticketsOpen} total={stats.ticketsTotal} tone="bg-rent" />
                <BreakBar label={t("support.status.PENDING")} value={stats.ticketsPending} total={stats.ticketsTotal} tone="bg-deal" />
                <BreakBar label={t("support.status.CLOSED")} value={stats.ticketsClosed} total={stats.ticketsTotal} tone="bg-muted-foreground/50" />
              </div>
            </section>

            <section className="rounded-3xl border border-border bg-card p-5" aria-label={t("admin.breakdown.notifs")}>
              <h2 className="mb-3 text-sm font-extrabold">{t("admin.breakdown.notifs")}</h2>
              <div className="space-y-3">
                <BreakBar label={<span className="flex items-center gap-1.5"><Mail className="size-3.5 text-ai" />{t("admin.announce.channel.EMAIL")}</span>} value={stats.notifsEmail} total={stats.notifs} tone="bg-ai" />
                <BreakBar label={<span className="flex items-center gap-1.5"><MessageSquare className="size-3.5 text-rent" />{t("admin.announce.channel.SMS")}</span>} value={stats.notifsSms} total={stats.notifs} tone="bg-rent" />
              </div>
            </section>
          </div>
        </div>
      )}

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <section className="rounded-3xl border border-border bg-card p-5" aria-label={t("admin.latestUsers")}>
          <h2 className="mb-3 text-sm font-extrabold">{t("admin.latestUsers")}</h2>
          <ul className="space-y-2.5">
            {users.map((u) => (
              <li key={u.id} className="flex items-center justify-between gap-3 rounded-2xl border border-border bg-secondary/30 px-3.5 py-2.5">
                <div className="min-w-0">
                  <p className="truncate text-xs font-extrabold">{u.name}</p>
                  <p dir="ltr" className="truncate text-start text-[0.62rem] text-muted-foreground tnum">{u.email ?? u.phone ?? "—"}</p>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <RolePill role={u.role} />
                  <StatusPill status={u.status} />
                </div>
              </li>
            ))}
            {users.length === 0 && <li className="py-6 text-center text-xs text-muted-foreground">…</li>}
          </ul>
          <Link to="/admin/users" className="mt-3 inline-block text-xs font-extrabold text-ai hover:underline">
            {t("admin.tab.users")} →
          </Link>
        </section>

        <section className="rounded-3xl border border-border bg-card p-5" aria-label={t("admin.latestTickets")}>
          <h2 className="mb-3 text-sm font-extrabold">{t("admin.latestTickets")}</h2>
          <ul className="space-y-2.5">
            {tickets.map((tk) => (
              <li key={tk.id} className="flex items-center justify-between gap-3 rounded-2xl border border-border bg-secondary/30 px-3.5 py-2.5">
                <div className="min-w-0">
                  <p className="truncate text-xs font-extrabold">{tk.subject}</p>
                  <p className="text-[0.62rem] text-muted-foreground">
                    {t(`support.cat.${tk.category}`)} · {f.dateTime(new Date(tk.createdAt).getTime())}
                  </p>
                </div>
                <StatusPill status={tk.status} />
              </li>
            ))}
            {tickets.length === 0 && <li className="py-6 text-center text-xs text-muted-foreground">…</li>}
          </ul>
          <Link to="/admin/tickets" className="mt-3 inline-block text-xs font-extrabold text-ai hover:underline">
            {t("admin.tab.tickets")} →
          </Link>
        </section>
      </div>
    </div>
  );
}
