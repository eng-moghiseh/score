"use client";

/* ————— تنظیمات سراسری سایت — نگه‌داری، دمو، سئو، تماس، فروشگاه و اجاره ————— */

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Save, Settings2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/lib/auth";
import { useT } from "@/lib/i18n";
import { AdminError, AdminHeader } from "./ui";
import { DEFAULT_SETTINGS } from "@/lib/cms/settings";
import type { SiteSettings } from "@/lib/cms/settings";

export function AdminSettings() {
  const t = useT();
  const [settings, setSettings] = useState<SiteSettings>({ ...DEFAULT_SETTINGS });
  const [loaded, setLoaded] = useState(false);
  const [err, setErr] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void (async () => {
      try {
        const d = await api.get<{ ok: boolean; values: Partial<SiteSettings> }>("/api/admin/cms/settings");
        setSettings({ ...DEFAULT_SETTINGS, ...d.values });
        setLoaded(true);
      } catch {
        setErr(true);
      }
    })();
  }, []);

  async function save() {
    setBusy(true);
    try {
      await api.patch("/api/admin/cms/settings", settings);
      toast.success(t("admin.cms.saved"));
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  if (err) return <AdminError />;
  if (!loaded) {
    return <div className="flex min-h-40 items-center justify-center"><span className="size-8 animate-spin rounded-full border-2 border-border border-t-ai" /></div>;
  }

  const set = <K extends keyof SiteSettings>(k: K, v: SiteSettings[K]) => setSettings((s) => ({ ...s, [k]: v }));

  const toggleRow = (key: keyof SiteSettings, label: string, desc?: string) => (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card/60 px-4 py-3">
      <div>
        <p className="text-xs font-bold">{label}</p>
        {desc ? <p className="mt-0.5 text-[0.65rem] text-muted-foreground">{desc}</p> : null}
      </div>
      <Switch checked={settings[key] === true} onCheckedChange={(v) => set(key, v as SiteSettings[typeof key])} />
    </div>
  );

  const textRow = (key: keyof SiteSettings, label: string, ltr = false) => (
    <div>
      <Label className="mb-1.5 block text-xs font-bold">{label}</Label>
      <Input value={String(settings[key] ?? "")} onChange={(e) => set(key, e.target.value as SiteSettings[typeof key])} dir={ltr ? "ltr" : undefined} />
    </div>
  );

  return (
    <div>
      <AdminHeader
        kicker={t("admin.title")}
        title={t("admin.cms.settingsTitle")}
        description={t("admin.cms.settingsDesc")}
        icon={Settings2}
        action={
          <Button onClick={save} disabled={busy} className="gap-2 bg-ai text-white hover:bg-ai/90">
            <Save className="size-4" /> {t("admin.save")}
          </Button>
        }
      />

      <div className="grid gap-5 md:grid-cols-2">
        {/* حالت‌ها */}
        <section className="space-y-3 rounded-2xl border border-border bg-card p-4">
          <h2 className="text-sm font-extrabold">{t("admin.cms.secModes")}</h2>
          {toggleRow("maintenanceMode", t("admin.cms.maintenance"), t("admin.cms.maintenanceDesc"))}
          {settings.maintenanceMode ? (
            <div className="grid gap-3">
              {textRow("maintenanceFa", t("admin.cms.maintenanceFa"))}
              {textRow("maintenanceEn", t("admin.cms.maintenanceEn"), true)}
            </div>
          ) : null}
          {toggleRow("demoMode", t("admin.cms.demoMode"), t("admin.cms.demoModeDesc"))}
        </section>

        {/* زبان و ارز */}
        <section className="space-y-3 rounded-2xl border border-border bg-card p-4">
          <h2 className="text-sm font-extrabold">{t("admin.cms.secLocale")}</h2>
          <div>
            <Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.defaultLang")}</Label>
            <select
              value={settings.defaultLang}
              onChange={(e) => set("defaultLang", e.target.value as "fa" | "en")}
              className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm"
            >
              <option value="fa">فارسی (fa)</option>
              <option value="en">English (en)</option>
            </select>
          </div>
          {textRow("currencyFa", t("admin.cms.currencyFa"))}
          {textRow("currencyEn", t("admin.cms.currencyEn"), true)}
        </section>

        {/* تماس و شبکه‌ها */}
        <section className="space-y-3 rounded-2xl border border-border bg-card p-4">
          <h2 className="text-sm font-extrabold">{t("admin.cms.secContact")}</h2>
          {textRow("contactEmail", t("admin.cms.contactEmail"), true)}
          {textRow("contactPhone", t("admin.cms.contactPhone"), true)}
          {textRow("socialInstagram", "Instagram", true)}
          {textRow("socialTelegram", "Telegram", true)}
          {textRow("socialX", "X / Twitter", true)}
          {textRow("socialDiscord", "Discord", true)}
        </section>

        {/* سئو */}
        <section className="space-y-3 rounded-2xl border border-border bg-card p-4">
          <h2 className="text-sm font-extrabold">{t("admin.cms.secSeo")}</h2>
          {textRow("seoTitleFa", t("admin.cms.seoTitleFa"))}
          {textRow("seoTitleEn", t("admin.cms.seoTitleEn"), true)}
          <div>
            <Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.seoDescFa")}</Label>
            <Textarea value={settings.seoDescFa} onChange={(e) => set("seoDescFa", e.target.value)} rows={2} />
          </div>
          <div>
            <Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.seoDescEn")}</Label>
            <Textarea value={settings.seoDescEn} onChange={(e) => set("seoDescEn", e.target.value)} rows={2} dir="ltr" />
          </div>
          {textRow("seoKeywords", t("admin.cms.seoKeywords"), true)}
          {textRow("ogImage", "OG Image URL", true)}
        </section>

        {/* فروشگاه و اجاره */}
        <section className="space-y-3 rounded-2xl border border-border bg-card p-4 md:col-span-2">
          <h2 className="text-sm font-extrabold">{t("admin.cms.secCommerce")}</h2>
          <div className="grid gap-3 md:grid-cols-2">
            {toggleRow("storeEnabled", t("admin.cms.storeEnabled"))}
            {toggleRow("rentalEnabled", t("admin.cms.rentalEnabled"))}
          </div>
          <div className="grid gap-3 md:grid-cols-3">
            <div>
              <Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.commissionPct")}</Label>
              <Input
                value={String(settings.rentalCommissionPct)}
                onChange={(e) => set("rentalCommissionPct", Math.max(0, Math.min(50, Number(e.target.value.replace(/\D/g, "")) || 0)))}
                inputMode="numeric"
                className="tnum"
                dir="ltr"
              />
            </div>
            {textRow("minPrice", t("admin.cms.minPrice"), true)}
            {textRow("maxPrice", t("admin.cms.maxPrice"), true)}
          </div>
        </section>
      </div>
    </div>
  );
}
