"use client";

/* ————— صفحه‌ساز بصری — بلوک‌ها، ترتیب، پیش‌نمایش، پیش‌نویس، انتشار، نسخه‌ها ————— */

import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors, type DragEndEvent } from "@dnd-kit/core";
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy, useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import {
  ArrowUp, ArrowDown, Copy, Eye, EyeOff, FileText, Layers, Monitor, Pencil, Plus, Save,
  Send, Smartphone, Tablet, Trash2, Undo2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { api } from "@/lib/auth";
import { useT, useLang } from "@/lib/i18n";
import { AdminHeader, AdminError } from "./ui";
import { BlocksRenderer } from "@/components/cms/blocks-render";
import { BLOCK_REGISTRY, blockConfig } from "@/lib/cms/blocks";
import type { Block } from "@/lib/cms/blocks";

interface PageRow {
  id: string;
  slug: string;
  titleFa: string;
  titleEn: string;
  status: string;
  publishedAt: string | null;
  updatedAt: string;
}

interface Revision {
  id: string;
  titleFa: string;
  titleEn: string;
  note: string | null;
  createdAt: string;
}

const uid = () => `${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-4)}`;

/* ————— لیست صفحات ————— */

export function AdminPages() {
  const t = useT();
  const [pages, setPages] = useState<PageRow[] | null>(null);
  const [err, setErr] = useState(false);
  const [editorPage, setEditorPage] = useState<PageRow | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [newSlug, setNewSlug] = useState("");
  const [newTitleFa, setNewTitleFa] = useState("");
  const [newTitleEn, setNewTitleEn] = useState("");
  const [busy, setBusy] = useState(false);
  const [deleting, setDeleting] = useState<PageRow | null>(null);

  async function load() {
    try {
      const d = await api.get<{ ok: boolean; pages: PageRow[] }>("/api/admin/cms/pages");
      setPages(d.pages);
    } catch {
      setErr(true);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  async function createPage() {
    if (!newSlug || !newTitleFa) {
      toast.error(t("admin.cms.invalid"));
      return;
    }
    setBusy(true);
    try {
      await api.post("/api/admin/cms/pages", { slug: newSlug, titleFa: newTitleFa, titleEn: newTitleEn || newTitleFa, blocks: [] });
      toast.success(t("admin.cms.saved"));
      setCreateOpen(false);
      setNewSlug("");
      setNewTitleFa("");
      setNewTitleEn("");
      await load();
    } catch (e) {
      const code = e instanceof Error ? e.message : "";
      toast.error(code === "SLUG_TAKEN" ? t("admin.cms.slugTaken") : t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function publishPage(p: PageRow) {
    setBusy(true);
    try {
      await api.post(`/api/admin/cms/pages/${p.id}/publish`, {});
      toast.success(t("admin.cms.published"));
      await load();
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function unpublishPage(p: PageRow) {
    setBusy(true);
    try {
      await api.post(`/api/admin/cms/pages/${p.id}/unpublish`, {});
      toast.success(t("admin.cms.unpublished"));
      await load();
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function removePage(p: PageRow) {
    setBusy(true);
    try {
      await api.del(`/api/admin/cms/pages/${p.id}`);
      toast.success(t("admin.cms.deleted"));
      setDeleting(null);
      await load();
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  if (err) return <AdminError />;

  return (
    <div>
      <AdminHeader
        kicker={t("admin.title")}
        title={t("admin.cms.pagesTitle")}
        description={t("admin.cms.pagesDesc")}
        icon={Layers}
        action={
          <Button onClick={() => setCreateOpen(true)} className="gap-2 bg-ai text-white hover:bg-ai/90">
            <Plus className="size-4" /> {t("admin.cms.newPage")}
          </Button>
        }
      />

      {!pages ? (
        <div className="flex min-h-40 items-center justify-center"><span className="size-8 animate-spin rounded-full border-2 border-border border-t-ai" /></div>
      ) : pages.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-secondary/20 p-8 text-center">
          <Layers className="mx-auto size-8 text-muted-foreground/50" />
          <p className="mt-3 text-sm font-bold">{t("admin.cms.pagesEmpty")}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {pages.map((p) => (
            <div key={p.id} className="flex flex-wrap items-center gap-3 rounded-2xl border border-border bg-card p-3">
              <div className="min-w-40 flex-1">
                <p className="flex flex-wrap items-center gap-2 text-sm font-extrabold">
                  {p.titleFa}
                  <span className="rounded-full bg-secondary px-2 py-0.5 text-[0.62rem] text-muted-foreground" dir="ltr">/{p.slug}</span>
                  <span className={`rounded-full px-2 py-0.5 text-[0.62rem] font-extrabold ${p.status === "PUBLISHED" ? "bg-emerald-500/15 text-emerald-500" : "bg-amber-500/15 text-amber-500"}`}>
                    {p.status === "PUBLISHED" ? t("admin.cms.statusPublished") : t("admin.cms.statusDraft")}
                  </span>
                </p>
                <p className="text-xs text-muted-foreground" dir="ltr">{p.titleEn} · {new Date(p.updatedAt).toLocaleString()}</p>
              </div>
              <div className="flex items-center gap-1.5">
                {p.status === "PUBLISHED" ? (
                  <>
                    <Button size="sm" variant="outline" onClick={() => unpublishPage(p)} disabled={busy} className="gap-1.5"><EyeOff className="size-3.5" /> {t("admin.cms.unpublish")}</Button>
                    <a href={`#/p/${p.slug}`} target="_blank" rel="noreferrer">
                      <Button size="sm" variant="ghost" className="gap-1.5"><Eye className="size-3.5" /> {t("admin.cms.view")}</Button>
                    </a>
                  </>
                ) : (
                  <Button size="sm" variant="outline" onClick={() => publishPage(p)} disabled={busy} className="gap-1.5"><Send className="size-3.5" /> {t("admin.cms.publish")}</Button>
                )}
                <Button size="sm" variant="ghost" onClick={() => setEditorPage(p)} className="gap-1.5"><Pencil className="size-3.5" /> {t("admin.cms.edit")}</Button>
                <Button size="icon" variant="ghost" onClick={() => setDeleting(p)} className="text-destructive hover:text-destructive" aria-label={t("admin.cms.delete")}><Trash2 className="size-4" /></Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={createOpen} onOpenChange={(v) => !v && setCreateOpen(false)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t("admin.cms.newPage")}</DialogTitle>
            <DialogDescription>{t("admin.cms.newPageDesc")}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fSlug")}</Label><Input value={newSlug} onChange={(e) => setNewSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "-"))} dir="ltr" placeholder="about-us" /></div>
            <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fTitleFa")}</Label><Input value={newTitleFa} onChange={(e) => setNewTitleFa(e.target.value)} /></div>
            <div><Label className="mb-1.5 block text-xs font-bold">{t("admin.cms.fTitleEn")}</Label><Input value={newTitleEn} onChange={(e) => setNewTitleEn(e.target.value)} dir="ltr" /></div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setCreateOpen(false)}>{t("admin.cancel")}</Button>
            <Button onClick={createPage} disabled={busy || !newSlug || !newTitleFa} className="gap-2"><Save className="size-4" /> {t("admin.cms.createAndEdit")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={Boolean(deleting)} onOpenChange={(v) => !v && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("admin.cms.deletePageTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("admin.cms.deletePageDesc", { title: deleting?.titleFa ?? "" })}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("admin.cancel")}</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleting && removePage(deleting)} className="bg-destructive text-white hover:bg-destructive/90">{t("admin.cms.delete")}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {editorPage ? <PageEditor page={editorPage} onClose={() => { setEditorPage(null); void load(); }} /> : null}
    </div>
  );
}

/* ————— ویرایشگر صفحه — لیست بلوک + فرم props + پیش‌نمایش + نسخه‌ها ————— */

function PageEditor({ page, onClose }: { page: PageRow; onClose: () => void }) {
  const t = useT();
  const lang = useLang();
  const [titleFa, setTitleFa] = useState(page.titleFa);
  const [titleEn, setTitleEn] = useState(page.titleEn);
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [busy, setBusy] = useState(false);
  const [activeBlock, setActiveBlock] = useState<string | null>(null);
  const [device, setDevice] = useState<"desktop" | "tablet" | "mobile">("desktop");
  const [showPreview, setShowPreview] = useState(true);
  const [revisionsOpen, setRevisionsOpen] = useState(false);
  const [revisions, setRevisions] = useState<Revision[] | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  useEffect(() => {
    void (async () => {
      try {
        const d = await api.get<{ ok: boolean; page: { titleFa: string; titleEn: string; blocks: Block[] } }>(`/api/admin/cms/pages/${page.id}`);
        setTitleFa(d.page.titleFa);
        setTitleEn(d.page.titleEn);
        setBlocks(d.page.blocks ?? []);
        setLoaded(true);
      } catch {
        toast.error(t("admin.error"));
      }
    })();
  }, [page.id, t]);

  async function save() {
    setBusy(true);
    try {
      await api.patch(`/api/admin/cms/pages/${page.id}`, { titleFa, titleEn, blocks });
      toast.success(t("admin.cms.saved"));
    } catch (e) {
      const code = e instanceof Error ? e.message : "";
      toast.error(code.includes("INVALID_BLOCKS") ? t("admin.cms.invalidBlocks") : t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function publish() {
    setBusy(true);
    try {
      await api.patch(`/api/admin/cms/pages/${page.id}`, { titleFa, titleEn, blocks });
      await api.post(`/api/admin/cms/pages/${page.id}/publish`, {});
      toast.success(t("admin.cms.published"));
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  async function loadRevisions() {
    setRevisionsOpen(true);
    try {
      const d = await api.get<{ ok: boolean; revisions: Revision[] }>(`/api/admin/cms/pages/${page.id}/revisions`);
      setRevisions(d.revisions);
    } catch {
      setRevisions([]);
    }
  }

  async function revert(revId: string) {
    setBusy(true);
    try {
      await api.post(`/api/admin/cms/pages/${page.id}/revert`, { revisionId: revId });
      const d = await api.get<{ ok: boolean; page: { titleFa: string; titleEn: string; blocks: Block[] } }>(`/api/admin/cms/pages/${page.id}`);
      setTitleFa(d.page.titleFa);
      setTitleEn(d.page.titleEn);
      setBlocks(d.page.blocks ?? []);
      toast.success(t("admin.cms.reverted"));
      setRevisionsOpen(false);
    } catch {
      toast.error(t("admin.error"));
    } finally {
      setBusy(false);
    }
  }

  function addBlock(type: string) {
    const cfg = blockConfig(type);
    if (!cfg) return;
    const block: Block = { id: `${type}-${uid()}`, type, props: { ...cfg.defaults } };
    setBlocks((b) => [...b, block]);
    setActiveBlock(block.id);
  }

  function updateProps(blockId: string, key: string, value: unknown) {
    setBlocks((list) => list.map((b) => (b.id === blockId ? { ...b, props: { ...b.props, [key]: value } } : b)));
  }

  function duplicateBlock(blockId: string) {
    setBlocks((list) => {
      const idx = list.findIndex((b) => b.id === blockId);
      if (idx === -1) return list;
      const copy: Block = { ...list[idx], id: `${list[idx].type}-${uid()}`, props: { ...list[idx].props } };
      return [...list.slice(0, idx + 1), copy, ...list.slice(idx + 1)];
    });
  }

  function removeBlock(blockId: string) {
    setBlocks((list) => list.filter((b) => b.id !== blockId));
    if (activeBlock === blockId) setActiveBlock(null);
  }

  function toggleHidden(blockId: string) {
    setBlocks((list) => list.map((b) => (b.id === blockId ? { ...b, hidden: !b.hidden ? true : undefined } : b)));
  }

  function onDragEnd(e: DragEndEvent) {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    setBlocks((list) => {
      const from = list.findIndex((b) => b.id === active.id);
      const to = list.findIndex((b) => b.id === over.id);
      return arrayMove(list, from, to);
    });
  }

  const activeCfg = useMemo(() => blocks.find((b) => b.id === activeBlock) ?? null, [blocks, activeBlock]);
  const activeForm = activeCfg ? blockConfig(activeCfg.type) : null;

  if (!loaded) {
    return (
      <div className="flex min-h-40 items-center justify-center"><span className="size-8 animate-spin rounded-full border-2 border-border border-t-ai" /></div>
    );
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-h-[95svh] overflow-hidden sm:max-w-[95vw] lg:max-w-7xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Layers className="size-4 text-ai" />
            {t("admin.cms.editPage")}: {titleFa}
            <span className="rounded-full bg-secondary px-2 py-0.5 text-[0.62rem] text-muted-foreground" dir="ltr">/{page.slug}</span>
          </DialogTitle>
          <DialogDescription>{t("admin.cms.editorDesc")}</DialogDescription>
        </DialogHeader>

        <div className="grid max-h-[68svh] gap-4 overflow-y-auto rounded-2xl border border-border p-3 md:grid-cols-[300px_1fr]">
          {/* پنل بلوک‌ها */}
          <div className="space-y-3">
            <div className="flex flex-wrap gap-2">
              {Object.values(BLOCK_REGISTRY).map((cfg) => (
                <button
                  key={cfg.type}
                  type="button"
                  onClick={() => addBlock(cfg.type)}
                  className="rounded-full border border-border bg-card px-3 py-1.5 text-xs font-bold transition-colors hover:border-ai/40 hover:bg-ai/10"
                  title={lang === "en" ? cfg.labelEn : cfg.labelFa}
                >
                  + {lang === "en" ? cfg.labelEn : cfg.labelFa}
                </button>
              ))}
            </div>

            <div className="grid gap-2">
              <Label className="text-xs font-bold">{t("admin.cms.fTitleFa")}</Label>
              <Input value={titleFa} onChange={(e) => setTitleFa(e.target.value)} />
              <Label className="text-xs font-bold">{t("admin.cms.fTitleEn")}</Label>
              <Input value={titleEn} onChange={(e) => setTitleEn(e.target.value)} dir="ltr" />
            </div>

            <SortableContext items={blocks.map((b) => b.id)} strategy={verticalListSortingStrategy}>
              <div className="space-y-1.5">
                {blocks.map((b, i) => (
                  <SortableBlock
                    key={b.id}
                    block={b}
                    index={i}
                    onDragEnd={onDragEnd}
                    sensors={sensors}
                    active={activeBlock === b.id}
                    onSelect={() => setActiveBlock(b.id)}
                    onToggle={() => toggleHidden(b.id)}
                    onDuplicate={() => duplicateBlock(b.id)}
                    onRemove={() => removeBlock(b.id)}
                  />
                ))}
                {blocks.length === 0 ? (
                  <p className="rounded-xl border border-dashed border-border p-4 text-center text-xs text-muted-foreground">{t("admin.cms.noBlocks")}</p>
                ) : null}
              </div>
            </SortableContext>
          </div>

          {/* فرم props بلوک فعال یا پیش‌نمایش */}
          <div className="space-y-3">
            {activeCfg && activeForm ? (
              <div className="rounded-2xl border border-ai/30 bg-ai/5 p-4">
                <p className="mb-3 flex items-center gap-2 text-sm font-extrabold">
                  <FileText className="size-4 text-ai" />
                  {lang === "en" ? activeForm.labelEn : activeForm.labelFa}
                </p>
                <div className="grid gap-3 md:grid-cols-2">
                  {activeForm.fields.map((field) => (
                    <BlockFieldInput
                      key={field.key}
                      field={field}
                      value={activeCfg.props[field.key]}
                      lang={lang}
                      onChange={(v) => updateProps(activeCfg.id, field.key, v)}
                    />
                  ))}
                </div>
              </div>
            ) : null}

            {/* پیش‌نمایش */}
            <div>
              <div className="mb-2 flex items-center justify-between">
                <p className="text-sm font-extrabold">{t("admin.cms.preview")}</p>
                <div className="flex items-center gap-1">
                  <Button size="icon" variant={device === "desktop" ? "secondary" : "ghost"} onClick={() => setDevice("desktop")} aria-label="Desktop"><Monitor className="size-4" /></Button>
                  <Button size="icon" variant={device === "tablet" ? "secondary" : "ghost"} onClick={() => setDevice("tablet")} aria-label="Tablet"><Tablet className="size-4" /></Button>
                  <Button size="icon" variant={device === "mobile" ? "secondary" : "ghost"} onClick={() => setDevice("mobile")} aria-label="Mobile"><Smartphone className="size-4" /></Button>
                  <Button size="sm" variant="ghost" onClick={() => setShowPreview((v) => !v)} className="gap-1.5">
                    {showPreview ? <EyeOff className="size-3.5" /> : <Eye className="size-3.5" />}
                  </Button>
                </div>
              </div>
              {showPreview ? (
                <div
                  className="mx-auto overflow-y-auto rounded-2xl border border-border bg-background transition-all"
                  style={{ maxWidth: device === "desktop" ? "100%" : device === "tablet" ? 720 : 380 }}
                >
                  <BlocksRenderer blocks={blocks} />
                </div>
              ) : null}
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="ghost" onClick={loadRevisions} className="gap-2"><Undo2 className="size-4" /> {t("admin.cms.revisions")}</Button>
          <Button variant="ghost" onClick={onClose}>{t("admin.close")}</Button>
          <Button variant="outline" onClick={save} disabled={busy} className="gap-2"><Save className="size-4" /> {t("admin.cms.saveDraft")}</Button>
          <Button onClick={publish} disabled={busy} className="gap-2"><Send className="size-4" /> {t("admin.cms.publish")}</Button>
        </DialogFooter>
      </DialogContent>

      {/* نسخه‌ها */}
      <Dialog open={revisionsOpen} onOpenChange={(v) => !v && setRevisionsOpen(false)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t("admin.cms.revisions")}</DialogTitle>
            <DialogDescription>{t("admin.cms.revisionsDesc")}</DialogDescription>
          </DialogHeader>
          <div className="max-h-72 space-y-2 overflow-y-auto">
            {(revisions ?? []).map((r) => (
              <div key={r.id} className="flex items-center justify-between gap-2 rounded-xl border border-border p-3">
                <div className="text-xs">
                  <p className="font-bold">{r.titleFa}</p>
                  <p className="text-muted-foreground">{new Date(r.createdAt).toLocaleString()} · {r.note}</p>
                </div>
                <Button size="sm" variant="outline" onClick={() => revert(r.id)} disabled={busy}>{t("admin.cms.restore")}</Button>
              </div>
            ))}
            {revisions && revisions.length === 0 ? <p className="p-4 text-center text-xs text-muted-foreground">{t("admin.cms.noRevisions")}</p> : null}
          </div>
        </DialogContent>
      </Dialog>
    </Dialog>
  );
}

/* ————— بلوک مرتب‌شدنی ————— */

function SortableBlock({
  block,
  index,
  active,
  onDragEnd: _onDragEnd,
  sensors: _sensors,
  onSelect,
  onToggle,
  onDuplicate,
  onRemove,
}: {
  block: Block;
  index: number;
  active: boolean;
  onDragEnd: (e: DragEndEvent) => void;
  sensors: ReturnType<typeof useSensors>;
  onSelect: () => void;
  onToggle: () => void;
  onDuplicate: () => void;
  onRemove: () => void;
}) {
  const t = useT();
  const lang = useLang();
  const cfg = blockConfig(block.type);
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: block.id });
  void _onDragEnd;
  void _sensors;
  void index;
  return (
    <div
      ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition }}
      className={`flex items-center gap-1.5 rounded-xl border p-2 transition-colors ${active ? "border-ai/50 bg-ai/5" : "border-border bg-card"} ${isDragging ? "opacity-50" : ""} ${block.hidden ? "opacity-60" : ""}`}
    >
      <button type="button" className="cursor-grab touch-none px-1 text-muted-foreground" {...attributes} {...listeners} aria-label="drag">
        <ArrowUp className="size-3.5 rotate-45" />
      </button>
      <button type="button" onClick={onSelect} className="flex-1 truncate text-start text-xs font-bold">
        {lang === "en" ? cfg?.labelEn ?? block.type : cfg?.labelFa ?? block.type}
      </button>
      <Button size="icon" variant="ghost" onClick={onToggle} aria-label={t("admin.cms.toggleVisibility")}><EyeOff className="size-3.5" /></Button>
      <Button size="icon" variant="ghost" onClick={onDuplicate} aria-label={t("admin.cms.duplicate")}><Copy className="size-3.5" /></Button>
      <Button size="icon" variant="ghost" onClick={onRemove} aria-label={t("admin.cms.delete")}><Trash2 className="size-3.5 text-destructive" /></Button>
    </div>
  );
}

/* ————— ورودی فیلد بلوک ————— */

function BlockFieldInput({
  field,
  value,
  lang,
  onChange,
}: {
  field: import("@/lib/cms/blocks").BlockField;
  value: unknown;
  lang: "fa" | "en";
  onChange: (v: unknown) => void;
}) {
  const label = lang === "en" ? field.labelEn || field.labelFa : field.labelFa;
  switch (field.type) {
    case "textarea":
      return (
        <div className="md:col-span-2">
          <Label className="mb-1.5 block text-xs font-bold">{label}</Label>
          <Textarea value={typeof value === "string" ? value : ""} onChange={(e) => onChange(e.target.value)} rows={3} />
        </div>
      );
    case "boolean":
      return (
        <label className="flex items-center gap-2 text-xs font-bold">
          <Switch checked={value === true} onCheckedChange={(v) => onChange(v)} />
          {label}
        </label>
      );
    case "number":
      return (
        <div>
          <Label className="mb-1.5 block text-xs font-bold">{label}</Label>
          <Input
            type="number"
            value={typeof value === "number" ? value : ""}
            min={field.min}
            max={field.max}
            step={field.step}
            onChange={(e) => onChange(e.target.value === "" ? "" : Number(e.target.value))}
            className="tnum"
            dir="ltr"
          />
        </div>
      );
    case "range":
      return (
        <div className="md:col-span-2">
          <Label className="mb-1.5 block text-xs font-bold">{label}: {typeof value === "number" ? value : ""}</Label>
          <Slider
            value={[typeof value === "number" ? value : (field.min ?? 0)]}
            min={field.min ?? 0}
            max={field.max ?? 100}
            step={field.step ?? 1}
            onValueChange={([v]) => onChange(v)}
          />
        </div>
      );
    case "select":
      return (
        <div>
          <Label className="mb-1.5 block text-xs font-bold">{label}</Label>
          <select
            value={typeof value === "string" ? value : ""}
            onChange={(e) => onChange(e.target.value)}
            className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm"
          >
            {(field.options ?? []).map((o) => (
              <option key={o.value} value={o.value}>{lang === "en" ? o.labelEn || o.labelFa : o.labelFa}</option>
            ))}
          </select>
        </div>
      );
    default:
      return (
        <div className={field.type === "list" || field.type === "stat" || field.type === "faq" ? "md:col-span-2" : ""}>
          <Label className="mb-1.5 block text-xs font-bold">{label}</Label>
          {field.type === "stat" || field.type === "faq" ? (
            <Textarea value={typeof value === "string" ? value : ""} onChange={(e) => onChange(e.target.value)} rows={3} dir="ltr" placeholder={field.hintFa} />
          ) : (
            <Input value={typeof value === "string" ? value : ""} onChange={(e) => onChange(e.target.value)} dir="ltr" placeholder={field.placeholder} />
          )}
          {field.hintFa ? <p className="mt-1 text-[0.65rem] text-muted-foreground">{field.hintFa}</p> : null}
        </div>
      );
  }
}
