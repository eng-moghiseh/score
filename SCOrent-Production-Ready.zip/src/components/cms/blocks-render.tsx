"use client";

/* ————— رندرکننده‌ی بلوک‌های صفحه‌ساز — فقط کامپوننت‌های ثبت‌شده —————
 * props هر بلوک در سرور با sanitizeBlocks پالایش شده؛ اینجا فقط رندر امن است.
 * بلوک‌ها از زبان فعلی UI و کاتالوگ زنده استفاده می‌کنند.
 */

import { motion } from "framer-motion";
import { ChevronDown, PlayCircle } from "lucide-react";
import { useEffect, useState } from "react";
import { GameCard } from "@/components/scorent/commerce";
import { GameCover } from "@/components/scorent/game-cover";
import { Button } from "@/components/ui/button";
import { Link } from "@/components/scorent/router";
import { GAMES } from "@/lib/data/games";
import { useLang, useT, useTx } from "@/lib/i18n";
import { finalPrice } from "@/lib/pricing";
import { sortGames } from "@/lib/cms/filter-engine";
import { parseBlocks } from "@/lib/cms/blocks";
import type { Block } from "@/lib/cms/blocks";
import { safeImageUrl, safeLinkHref } from "@/lib/cms/types";

const S = (v: unknown, fallback = ""): string => (typeof v === "string" ? v : fallback);
const N = (v: unknown, fallback: number): number => (typeof v === "number" ? v : fallback);
const B = (v: unknown): boolean => v === true;

function pick(props: Record<string, unknown>, base: string): string {
  return S(props[`${base}Fa`], "") || S(props[`${base}En`], "");
}

/* ————— بلوک هیرو — مشابه سکشن هیرو صفحه اصلی ————— */
function HeroBlock({ props }: { props: Record<string, unknown> }) {
  const t = useT();
  const lang = useLang();
  const title = pick(props, "title") || t("home.heading");
  const desc = pick(props, "desc");
  const cta1 = pick(props, "cta1");
  const cta2 = pick(props, "cta2");
  const cta1Href = safeLinkHref(props.cta1Href) ?? "/store";
  const cta2Href = safeLinkHref(props.cta2Href) ?? "/ai-chat";
  const coverIds = S(props.coverGameIds, "").split(",").map((s) => s.trim()).filter(Boolean).slice(0, 6);
  const covers = coverIds.map((id) => GAMES.find((g) => g.id === id)).filter((g): g is (typeof GAMES)[number] => Boolean(g));
  const fallbackCovers = covers.length > 0 ? covers : sortGames(GAMES.filter((g) => g.featured || g.popularity > 80), "popular").slice(0, 4);
  const positions = [
    "top-2 end-6 rotate-[6deg]",
    "top-24 end-40 -rotate-[5deg]",
    "top-48 end-2 rotate-[4deg]",
    "top-8 end-72 -rotate-[3deg]",
  ];

  return (
    <section className="relative overflow-hidden" aria-label={title}>
      <div className="mx-auto grid w-full max-w-7xl gap-10 px-4 py-14 md:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:py-20">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full border border-deal/30 bg-deal/10 px-4 py-1.5 text-xs font-extrabold text-deal">
            {pick(props, "kicker")}
          </span>
          <h1 className="mt-5 text-4xl font-black leading-[1.25] md:text-5xl lg:text-[3.4rem] lg:leading-[1.2]">{title}</h1>
          {desc ? <p className="mt-5 max-w-xl text-base leading-8 text-muted-foreground md:text-lg md:leading-9">{desc}</p> : null}
          <div className="mt-8 flex flex-wrap items-center gap-3">
            {cta1 ? (
              <Link to={cta1Href}>
                <Button size="lg" className="glow-brand gap-2 text-base">{cta1}</Button>
              </Link>
            ) : null}
            {cta2 ? (
              <Link to={cta2Href}>
                <Button size="lg" variant="outline" className="gap-2 border-ai/40 text-base text-ai hover:bg-ai/10">{cta2}</Button>
              </Link>
            ) : null}
          </div>
        </div>
        <div className="relative hidden min-h-[420px] lg:block" aria-hidden>
          <div className="aurora-orb absolute start-1/2 top-1/2 size-[400px] -translate-x-1/2 -translate-y-1/2 rounded-full" />
          {fallbackCovers.slice(0, 4).map((game, i) => (
            <motion.div
              key={game.id}
              initial={{ opacity: 0, y: 30, rotate: 0 }}
              whileInView={{ opacity: 1, y: 0, rotate: [4, -4, 5, -5][i % 4] }}
              viewport={{ once: true }}
              transition={{ delay: 0.12 * i, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              className={`absolute w-56 ${positions[i % positions.length].split(" ").slice(0, 2).join(" ")}`}
              style={{ transform: `rotate(${[6, -5, 4, -3][i % 4]}deg)` }}
            >
              <GameCover game={game} showTitle={false} className="aspect-[3/4] w-full rounded-3xl shadow-2xl shadow-black/40" />
            </motion.div>
          ))}
        </div>
      </div>
      {lang === "fa" ? null : null}
    </section>
  );
}

/* ————— متن غنی ————— */
function RichTextBlock({ props }: { props: Record<string, unknown> }) {
  const lang = useLang();
  const title = pick(props, "title");
  const body = (lang === "en" ? S(props.bodyEn, "") || S(props.bodyFa, "") : S(props.bodyFa, "")) || "";
  return (
    <section className="mx-auto w-full max-w-4xl px-4 py-10 md:px-6">
      {title ? <h2 className="mb-4 text-2xl font-black md:text-3xl">{title}</h2> : null}
      <div className="space-y-3 leading-8 text-muted-foreground">
        {body.split(/\n+/).map((p, i) => (
          <p key={i}>{p}</p>
        ))}
      </div>
    </section>
  );
}

/* ————— تصویر تنها ————— */
function ImageBlock({ props }: { props: Record<string, unknown> }) {
  const src = safeImageUrl(props.src);
  if (!src) return null;
  const alt = pick(props, "alt");
  const href = safeLinkHref(props.href);
  const img = (
    <img src={src} alt={alt} loading="lazy" className={B(props.rounded) ? "mx-auto max-h-[560px] w-auto max-w-full rounded-3xl" : "mx-auto max-h-[560px] w-auto max-w-full"} />
  );
  return (
    <section className="mx-auto w-full max-w-6xl px-4 py-8 md:px-6">
      {href ? (
        <a href={href.startsWith("/") ? `#${href}` : href} target={!href.startsWith("/") ? "_blank" : undefined} rel="noopener noreferrer">
          {img}
        </a>
      ) : (
        img
      )}
    </section>
  );
}

/* ————— تصویر + متن ————— */
function ImageTextBlock({ props }: { props: Record<string, unknown> }) {
  const src = safeImageUrl(props.src);
  const title = pick(props, "title");
  const lang = useLang();
  const body = (lang === "en" ? S(props.bodyEn, "") || S(props.bodyFa, "") : S(props.bodyFa, "")) || "";
  const cta = pick(props, "cta");
  const href = safeLinkHref(props.href);
  const reverse = B(props.reverse);
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-10 md:px-6">
      <div className={`grid items-center gap-8 rounded-3xl border border-border bg-card p-6 md:grid-cols-2 md:p-10 ${reverse ? "md:[direction:rtl]" : ""}`}>
        <div>
          {title ? <h2 className="text-2xl font-black md:text-3xl">{title}</h2> : null}
          {body ? <p className="mt-4 leading-8 text-muted-foreground">{body}</p> : null}
          {cta && href ? (
            <Link to={href} className="mt-5 inline-flex">
              <Button className="gap-2">{cta}</Button>
            </Link>
          ) : null}
        </div>
        <div className={reverse ? "md:[direction:ltr]" : ""}>
          {src ? (
            <img src={src} alt={title} loading="lazy" className="max-h-96 w-full rounded-2xl object-cover" />
          ) : null}
        </div>
      </div>
    </section>
  );
}

/* ————— کاروسل بازی‌ها ————— */
function GameCarouselBlock({ props }: { props: Record<string, unknown> }) {
  const title = pick(props, "title");
  const lang = useLang();
  const ids = S(props.gameIds, "").split(",").map((s) => s.trim()).filter(Boolean);
  const limit = Math.max(2, Math.min(20, N(props.limit, 8)));
  const games = ids.length > 0 ? ids.map((id) => GAMES.find((g) => g.id === id)).filter((g): g is (typeof GAMES)[number] => Boolean(g)).slice(0, limit) : sortGames(GAMES, "popular").slice(0, limit);
  if (games.length === 0) return null;
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-10 md:px-6">
      {title ? (
        <div className="mb-6 flex items-end justify-between">
          <h2 className="text-2xl font-black md:text-3xl">{title}</h2>
          <Link to="/store" className="text-sm font-bold text-deal hover:underline">
            {lang === "en" ? "View all" : "مشاهده همه"}
          </Link>
        </div>
      ) : null}
      <div className="flex gap-4 overflow-x-auto pb-4 [scrollbar-width:thin]">
        {games.map((g, i) => (
          <div key={g.id} className="w-44 shrink-0 md:w-52">
            <GameCard game={g} index={i} />
          </div>
        ))}
      </div>
    </section>
  );
}

/* ————— شبکه محصولات ————— */
function ProductGridBlock({ props }: { props: Record<string, unknown> }) {
  const title = pick(props, "title");
  const genre = S(props.filterGenre, "");
  const sort = S(props.sort, "popular") as "popular" | "rating" | "discount" | "newest";
  const limit = Math.max(2, Math.min(16, N(props.limit, 8)));
  let games = GAMES.filter((g) => g.available);
  if (genre) games = games.filter((g) => g.genres.includes(genre as (typeof GAMES)[number]["genres"][number]));
  games = sortGames(games, sort).slice(0, limit);
  if (games.length === 0) return null;
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-10 md:px-6">
      {title ? <h2 className="mb-6 text-2xl font-black md:text-3xl">{title}</h2> : null}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
        {games.map((g, i) => (
          <GameCard key={g.id} game={g} index={i} />
        ))}
      </div>
    </section>
  );
}

/* ————— شبکه رده‌ها (از CMS) ————— */
function CategoryGridBlock({ props }: { props: Record<string, unknown> }) {
  const [cats, setCats] = useState<{ slug: string; name: string; desc: string }[]>([]);
  const title = pick(props, "title");
  const lang = useLang();
  const limit = Math.max(2, Math.min(24, N(props.limit, 12)));

  useEffect(() => {
    let alive = true;
    fetch("/api/categories", { cache: "no-cache" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d: { ok?: boolean; categories?: { slug: string; nameFa: string; nameEn: string; descFa: string | null; descEn: string | null }[] } | null) => {
        if (alive && d?.ok && Array.isArray(d.categories)) {
          setCats(
            d.categories.slice(0, limit).map((c) => ({
              slug: c.slug,
              name: lang === "en" ? c.nameEn || c.nameFa : c.nameFa,
              desc: (lang === "en" ? c.descEn || c.descFa : c.descFa) ?? "",
            }))
          );
        }
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [lang, limit]);

  if (cats.length === 0) return null;
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-10 md:px-6">
      {title ? <h2 className="mb-6 text-2xl font-black md:text-3xl">{title}</h2> : null}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {cats.slice(0, limit).map((c) => (
          <Link
            key={c.slug}
            to={c.slug === "all" ? "/store" : `/store?category=${c.slug}`}
            className="group rounded-2xl border border-border bg-card p-5 text-center transition-colors hover:border-deal/40 hover:bg-deal/5"
          >
            <p className="font-extrabold">{c.name}</p>
            {c.desc ? <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{c.desc}</p> : null}
          </Link>
        ))}
      </div>
    </section>
  );
}

/* ————— بنر تبلیغاتی ————— */
function PromoBannerBlock({ props }: { props: Record<string, unknown> }) {
  const title = pick(props, "title");
  const lang = useLang();
  const body = (lang === "en" ? S(props.bodyEn, "") || S(props.bodyFa, "") : S(props.bodyFa, "")) || "";
  const cta = pick(props, "cta");
  const href = safeLinkHref(props.href) ?? "/deals";
  const tone = S(props.tone, "brand");
  const toneClass =
    tone === "ai" ? "border-ai/40 bg-ai/10" : tone === "rent" ? "border-rent/40 bg-rent/10" : "border-deal/40 bg-deal/10";
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-8 md:px-6">
      <div className={`flex flex-col items-start gap-4 rounded-3xl border p-8 md:flex-row md:items-center md:justify-between ${toneClass}`}>
        <div>
          <h2 className="text-xl font-black md:text-2xl">{title}</h2>
          {body ? <p className="mt-2 max-w-xl leading-7 text-muted-foreground">{body}</p> : null}
        </div>
        {cta ? (
          <Link to={href}>
            <Button size="lg" className="gap-2">{cta}</Button>
          </Link>
        ) : null}
      </div>
    </section>
  );
}

/* ————— آمار ————— */
function StatsBlock({ props }: { props: Record<string, unknown> }) {
  const lang = useLang();
  const mode = S(props.mode, "live");
  const items: { label: string; value: number }[] =
    mode === "live"
      ? [
          { label: lang === "en" ? "Games in catalog" : "بازی در کاتالوگ", value: GAMES.length },
          { label: lang === "en" ? "Distinct genres" : "ژانر متفاوت", value: new Set(GAMES.flatMap((g) => g.genres)).size },
          { label: lang === "en" ? "Rental windows" : "بازه اجاره (۱/۳/۷ روز)", value: 3 },
        ]
      : S(props.items, "")
          .split("\n")
          .map((line) => line.split("|").map((p) => p.trim()))
          .filter((p) => p.length >= 3 && p[2] !== "")
          .map((p) => ({ label: lang === "en" ? p[1] || p[0] : p[0], value: Number(p[2]) || 0 }));
  if (items.length === 0) return null;
  return (
    <section className="mx-auto w-full max-w-5xl px-4 py-10 md:px-6">
      <dl className="grid grid-cols-3 gap-4">
        {items.map((it) => (
          <div key={it.label} className="rounded-2xl border border-border bg-card/60 p-3.5 text-center backdrop-blur">
            <dd className="text-2xl font-black text-deal tnum">{it.value}</dd>
            <dt className="mt-1 text-[0.7rem] leading-5 text-muted-foreground">{it.label}</dt>
          </div>
        ))}
      </dl>
    </section>
  );
}

/* ————— سوالات متداول ————— */
function FaqBlock({ props }: { props: Record<string, unknown> }) {
  const title = pick(props, "title");
  const lang = useLang();
  const [openIdx, setOpenIdx] = useState<number | null>(null);
  // هر خط: سوال|جواب (یا سوال|جواب|سوال انگلیسی|جواب انگلیسی)
  const qa = S(props.items, "")
    .split("\n")
    .map((line) => line.split("|").map((p) => p.trim()))
    .filter((p) => p.length >= 2 && p[0] && p[1])
    .map((p) => ({
      q: lang === "en" && p[2] ? p[2] : p[0],
      a: lang === "en" && p[3] ? p[3] : p[1],
    }));
  if (qa.length === 0) return null;
  return (
    <section className="mx-auto w-full max-w-3xl px-4 py-10 md:px-6">
      {title ? <h2 className="mb-6 text-2xl font-black md:text-3xl">{title}</h2> : null}
      <div className="space-y-2.5">
        {qa.map((item, i) => (
          <div key={i} className="overflow-hidden rounded-2xl border border-border bg-card">
            <button
              type="button"
              onClick={() => setOpenIdx(openIdx === i ? null : i)}
              className="flex w-full items-center justify-between gap-3 p-4 text-start font-bold"
              aria-expanded={openIdx === i}
            >
              {item.q}
              <ChevronDown className={`size-4 shrink-0 text-muted-foreground transition-transform ${openIdx === i ? "rotate-180" : ""}`} />
            </button>
            {openIdx === i ? <p className="border-t border-border p-4 text-sm leading-7 text-muted-foreground">{item.a}</p> : null}
          </div>
        ))}
      </div>
    </section>
  );
}

/* ————— ویدیو ————— */
function VideoBlock({ props }: { props: Record<string, unknown> }) {
  const url = safeImageUrl(props.url);
  const title = pick(props, "title");
  if (!url) return null;
  const yt = /^https?:\/\/(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{6,20})/i.exec(url);
  return (
    <section className="mx-auto w-full max-w-5xl px-4 py-10 md:px-6">
      {title ? <h2 className="mb-5 text-2xl font-black md:text-3xl">{title}</h2> : null}
      {yt ? (
        <div className="aspect-video overflow-hidden rounded-3xl border border-border">
          <iframe
            src={`https://www.youtube.com/embed/${yt[3]}`}
            title={title || "video"}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            className="size-full"
          />
        </div>
      ) : url.endsWith(".mp4") ? (
        <video src={url} controls className="w-full rounded-3xl border border-border" preload="metadata" />
      ) : (
        <div className="flex items-center justify-center rounded-3xl border border-border bg-card p-10 text-muted-foreground">
          <PlayCircle className="size-8" />
          <a href={url} target="_blank" rel="noopener noreferrer" className="ms-3 font-bold hover:underline">
            {url}
          </a>
        </div>
      )}
    </section>
  );
}

/* ————— دعوت به اقدام ————— */
function CtaBlock({ props }: { props: Record<string, unknown> }) {
  const title = pick(props, "title");
  const lang = useLang();
  const body = (lang === "en" ? S(props.bodyEn, "") || S(props.bodyFa, "") : S(props.bodyFa, "")) || "";
  const cta = pick(props, "cta");
  const href = safeLinkHref(props.href) ?? "/ai";
  return (
    <section className="mx-auto w-full max-w-7xl px-4 py-10 md:px-6">
      <div className="rounded-3xl border border-ai/35 bg-gradient-to-br from-ai/15 via-card to-card p-10 text-center">
        <h2 className="text-2xl font-black md:text-3xl">{title}</h2>
        {body ? <p className="mx-auto mt-3 max-w-xl leading-7 text-muted-foreground">{body}</p> : null}
        {cta ? (
          <Link to={href} className="mt-6 inline-flex">
            <Button size="lg" className="gap-2 bg-ai text-white hover:bg-ai/90">{cta}</Button>
          </Link>
        ) : null}
      </div>
    </section>
  );
}

/* ————— فاصله‌ساز ————— */
function SpacerBlock({ props }: { props: Record<string, unknown> }) {
  return <div style={{ height: Math.max(8, Math.min(200, N(props.size, 48))) }} aria-hidden />;
}

/* ————— رندر اصلی ————— */
function BlockView({ block }: { block: Block }) {
  const p = block.props ?? {};
  switch (block.type) {
    case "hero":
      return <HeroBlock props={p} />;
    case "richText":
      return <RichTextBlock props={p} />;
    case "image":
      return <ImageBlock props={p} />;
    case "imageText":
      return <ImageTextBlock props={p} />;
    case "gameCarousel":
      return <GameCarouselBlock props={p} />;
    case "productGrid":
      return <ProductGridBlock props={p} />;
    case "categoryGrid":
      return <CategoryGridBlock props={p} />;
    case "promoBanner":
      return <PromoBannerBlock props={p} />;
    case "stats":
      return <StatsBlock props={p} />;
    case "faq":
      return <FaqBlock props={p} />;
    case "video":
      return <VideoBlock props={p} />;
    case "cta":
      return <CtaBlock props={p} />;
    case "spacer":
      return <SpacerBlock props={p} />;
    default:
      return null;
  }
}

export function BlocksRenderer({ blocks, className }: { blocks: Block[]; className?: string }) {
  const visible = blocks.filter((b) => !b.hidden);
  if (visible.length === 0) return null;
  return (
    <div className={className}>
      {visible.map((b) => (
        <BlockView key={b.id} block={b} />
      ))}
    </div>
  );
}

export function BlocksFromJson(json: string | null | undefined, className?: string): React.ReactNode {
  const blocks = parseBlocks(json);
  return <BlocksRenderer blocks={blocks} className={className} />;
}
